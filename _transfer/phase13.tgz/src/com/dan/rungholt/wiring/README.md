# com.dan.rungholt.wiring – die Verdrahtung

Hier reden die Packages miteinander, und nur hier. Kein Element-Package kennt ein anderes oder die App. Jedes bietet Eingänge an und meldet Ereignisse; die App verbindet sie in `Wiring`.

Stand Phase 13: die Zeitreise und die Spuren: die Spurenkarte aus dem Land von 1362 an Gelände und Kamera, die Grabung (`figure`) nach Tide, Sonne und Wind und als Störer mit Stiefelabdrücken, die Wege der Stadt aus `road`, die Überblendung an Häuser (`timber.moveSpecial`), Gras, Vieh, Leute, Rauch und Kamera, die Glocken nach Wind, Sonne und Wasser über der Kirchwarft. 68 Verbindungen. Davor Phase 12: die Grote Mandränke: Windstau nach Drehbuch an die Tide, Orkan aus der Regie, der Deichbruch mit `fracture` (Wasserdruck, Strömung, Grund), die Bresche im Gelände, der Dammbruch mit `wave` (gehaltene See), die Marsch als Becken in der Überflutung, Häuser und Leute in der Flut. 62 Verbindungen. Davor Phase 11: die Stadt von 1362: Häuser und Kirche (`timber`) auf dem Gelände von 1362, die Kogge (`buoyancy.Cog`) auf dem Wasser der Überflutung von 1362 mit dem Pegel als Fahrplan, Herdrauch (`smoke`) im Wind, die Leute (`figure`). 55 Verbindungen. Davor Phase 10: das Land von 1362 (`scene.Land1362`: Marsch, Warften, Seedeich, Siel) als zweites Gelände; die Ära blendet es über und schaltet Überflutung, Watt, Halme und Bodendecke auf 1362; die Tide hat eine eigene Überflutung vor dem Seedeich. 50 Verbindungen. Davor Phase 9: das Jahr (`Wiring.Jahreszeit` mit `com.dan.season`, Klima Nordfriesland) an Gelände (Schnee, Reif, Salzwiese), Halme, Bodendecke, Häuser, Schneefall und Regie; die Wattwanderung (`com.dan.figure`) mit Weg, Wasser, Schlick, Spuren und als Störer für Seehunde und Vögel. 46 Verbindungen. Davor Phase 8: die Wattvögel (`com.dan.flock.Waders`) bekommen Grund, Wasser und Schlick am Ort, die Hochwasserrastplätze auf dem Vorland, den Wattwanderer als Störer, Monat, Sonne, Wind und die Stunden seit Hochwasser. 40 Verbindungen. Davor Phase 7: die Seehunde an Bank, Grund, Wasser, Wanderer, Spuren, Licht und Uhr, 36 Verbindungen. Phase 6: die Strömung der Tide an Meer (Kräuselung, Schaum, Trübung) und Rippel, die Feinform des Watts an Gelände und Kamera, das Auge unter Wasser an `ocean`, der Blitz im Wasserfilm. 30 Verbindungen. Davor Phase 5: das Watt aus `com.dan.mudflat` hängt an der Überflutung (Wasser, Trockenzeit, Strömung für die Rippel) und am Wetter (Sonne am Boden, Wind, Lufttemperatur, Regen); `Wiring.WattNaesse` gibt die Nässe als `Wetness` weiter. 26 Verbindungen. Davor Phase 4: die Tide aus `com.dan.tide` (`Wiring.TidePegel`: Pegel am Rand mit Windstau, Wasser je Zelle und Strömung aus der Überflutung) ersetzt den Platzhalter. 21 Verbindungen. Davor Phase 3: alle Schnittstellen stehen; verbunden sind die Uhr, der Platzhalter-Pegel (M2 + M4), die Zeitreise, das Gelände (Phase 2) und die Wetterregie mit dem Klima Nordfriesland: Wind und Böe an Meer, Gras, Bodendecke, Wolken, Regen und Nebel; Bedeckung, Art, Regen, Sicht, Seenebel und Gewitter an Himmel, Wolken, Regen, Nebel und Blitz; das Licht des Himmels (`Lighting`, vorbelichtet) an alles, was gezeichnet wird. 16 Verbindungen. `Wiring.planned()` nennt die Verbindungen aus dem Phasenplan.

## Die Schnittstellen

| Schnittstelle | Inhalt | Gibt | Nimmt | ab Phase |
|---|---|---|---|---|
| `Clock` | Laufzeit, Schritt, Uhrzeit, Ort | App (`SceneClock`) | alle | 1 |
| `Wind` | Geschwindigkeit, Richtung, Böigkeit, Bft | weather (Phase 3; vorher von Hand) | ocean, cloud, rain, fog, spray, reed, flock, soundscape, tide (Stau) | 1 |
| `Era` **neu** | Heute · 1362, Überblendung 0–1 | App (Taste Z) | Gelände, mudflat, ground, timber, muster, flock, soundscape, Kamera | 1 |
| `Level` **neu** | Pegel über NHN, Windstau, Flut oder Ebbe | Platzhalter, ab Phase 4 tide | ocean, buoyancy, Kamera, HUD | 1 / 4 |
| `Terrain` | Höhe über NHN, Wassertiefe, Normale | Gelände heute (EasyGSH/BAW), 1362 modelliert | tide, mudflat, ground, reed, forest, road, timber, Kamera | 2 |
| `Lighting`, `Flash` | Sonne, Mond, Himmel, Dunst; Blitz | sky, lightning | ocean, cloud, mudflat, Szene | 3 |
| `Water` **neu** | Wasser je Zelle, Spiegel, verbunden oder Pfütze | tide | ocean, mudflat, seal, flock, muster, weathering | 4 |
| `Wetness` **neu** | Nässe, Trockenzeit, Sediment | mudflat (`Wiring.WattNaesse`) | HUD, Bedienfeld, flock (Schlick, Phase 8); ab Phase 9 ground, weathering, soundscape | 5 |
| `Current` **neu** | Strömung an der Oberfläche | tide | ocean, buoyancy, mudflat | 6 |
| `Haulout`, `Disturber` **neu** | Bänke der Seehunde, Rastplätze der Vögel; Störer | App, muster, buoyancy | seal (7), flock (8) | 7 |
| `Season` | Laub, Schnee, Temperatur, Zeit der Jungen | season (`Wiring.Jahreszeit`) | Gelände, reed, ground, timber, weather, rain (Schnee); später forest | 9 |
| `Collider`, `SurfaceHit` | fester Körper als Abstandsfeld; Einschlag auf einer Fläche | timber, App (Deich, Kirche, Warften) | rain, spray, weathering | 10 |
| `Sea` | Höhe als Summe: Pegel + Welle | App | ocean, buoyancy, spray, fracture | 12 |
| `Impact`, `Crack`, `Runup` | Einschlag, Riss, Auflaufen | fracture, wave | spray, soundscape, weathering, mudflat | 12 |
| `SoundEvent` | Klangereignis, darunter die Glocken im Watt | tide, seal, flock, fracture, wave, lightning, Regie | soundscape | 14 |

`Beaufort` gibt die gemeinsame Sprache für alle Presets: Grenzen nach WMO und die deutschen Bezeichnungen.

## Regeln

- Jede Schnittstelle besteht nur aus Zahlen, Aufzählungen und Funktionen. Keine Klassen aus anderen Packages.
- Braucht ein Package dieselbe Form, bringt es eine eigene Kopie mit gleichem Namen mit. `Wiring` übersetzt mit einer Zeile.
- Jede neue Verbindung wird mit `link(von, an, über, Phase)` eingetragen. Das Bedienfeld zeigt die Liste.
