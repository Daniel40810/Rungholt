package com.dan.rungholt.ui;

import com.dan.fbutton.FButton;
import com.dan.rungholt.gl.Renderer;
import com.dan.rungholt.scene.SceneClock;
import com.dan.rungholt.scene.Site;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;

/**
 * Das Startbild vor der Szene (aus Glacier, Phase 1 ohne Datenbank): Titel, Ort, Stand der Phase, die Bänder des
 * Werkbuchs (Schaum, Nordsee, Priel, Tiefe, Watt, Reet, Backstein, Abendgold). Nach 3 s geht es von selbst weiter; jede
 * Eingabe hält an. Ab Phase 16 zeigt es wie in Glacier den Stand der Datenbank (Schema RUNGHOLT) mit „Einrichten“,
 * „Weiter wie zuletzt“ und „Ohne Datenbank“. Ohne Startbild: {@code -Drungholt.splash=false}.
 */
public final class Startbild extends JDialog {
    private static final int SEKUNDEN = 3;
    private final JLabel countLine = new JLabel(" ");
    private final FButton los = new FButton("Los");
    private Timer timer;
    private int rest = SEKUNDEN;
    private boolean angehalten;
    private AWTEventListener aufmerken;

    /** Zeigt das Startbild und kehrt zurück, wenn es zu ist (modal). */
    public static void zeigen() {
        Startbild s = new Startbild();
        s.setVisible(true);
    }

    /** Statuszeile unten rechts im Fenster: wohin gespeichert wird (bis Phase 16: nirgends). */
    public static String statuszeile() { return "Daten: noch keine (Schema RUNGHOLT folgt in Phase 16)"; }

    private Startbild() {
        super((java.awt.Frame) null, "Rungholt", true);
        setUndecorated(true);
        JPanel root = new JPanel(new BorderLayout(18, 14)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setPaint(new GradientPaint(0, 0, new Color(24, 34, 38), 0, getHeight(), new Color(10, 14, 16)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(Theme.PRIEL);
                g2.fillRect(0, 0, getWidth(), 3);
                int y = getHeight() - 6, w = getWidth();
                Color[] c = {Theme.SCHAUM, Theme.SEE, Theme.PRIEL, Theme.TIEFE, Theme.WATT, Theme.REET, Theme.ZIEGEL, Theme.GOLD};
                double[] at = {0, 0.10, 0.30, 0.42, 0.52, 0.72, 0.84, 0.94, 1};
                for (int i = 0; i < c.length; i++) {
                    g2.setColor(c[i]);
                    g2.fillRect((int) (w * at[i]), y, (int) Math.ceil(w * (at[i + 1] - at[i])) + 1, 6);
                }
            }
        };
        root.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(48, 64, 70)), BorderFactory.createEmptyBorder(22, 26, 24, 28)));
        JLabel il = new JLabel(new javax.swing.ImageIcon(AppIcon.load(128)));
        il.setVerticalAlignment(JLabel.TOP);
        root.add(il, BorderLayout.WEST);
        JPanel mid = new JPanel();
        mid.setOpaque(false);
        mid.setLayout(new BoxLayout(mid, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("RUNGHOLT");
        title.setFont(new Font("Serif", Font.PLAIN, 34));
        title.setForeground(Theme.SCHAUM);
        JLabel sub = new JLabel("Zweimal am Tag Land · das Watt zwischen Pellworm, Südfall und Nordstrand, " + Site.dms(Site.LAT, Site.LON).replace(" · ", " "));
        sub.setFont(new Font("SansSerif", Font.PLAIN, 14));
        sub.setForeground(Theme.PRIEL);
        SceneClock start = new SceneClock();
        JLabel info = new JLabel("<html><body style='width:470px'>" + Renderer.VERSION + ": das Grundgerüst. Die flache Bühne mit dem Watt, "
                + "der Norderhever, Südfall und seiner Warft, Pellworm und Nordstrand hinter ihren Deichen, dem Meer auf einem Platzhalter-Pegel "
                + "(Hub " + String.format(java.util.Locale.GERMAN, "%.1f", Site.TIDAL_RANGE) + " m) und dem Platzhalter-Himmel, beginnend am "
                + start.label() + ". Gelände, Himmel, Tide, Watt und Seehunde folgen in den Phasen 2 bis 7, Rungholt 1362 ab Phase 10.</body></html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 12));
        info.setForeground(new Color(160, 178, 190));
        info.setBorder(BorderFactory.createEmptyBorder(10, 0, 8, 0));
        JLabel dbLine = new JLabel(statuszeile());
        dbLine.setFont(new Font("SansSerif", Font.PLAIN, 12));
        dbLine.setForeground(new Color(224, 190, 120));
        countLine.setFont(new Font("SansSerif", Font.PLAIN, 12));
        countLine.setForeground(Theme.SEE);
        countLine.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        for (JLabel l : new JLabel[]{title, sub, info, dbLine, countLine}) l.setAlignmentX(Component.LEFT_ALIGNMENT);
        mid.add(title);
        mid.add(sub);
        mid.add(info);
        mid.add(dbLine);
        mid.add(countLine);
        root.add(mid, BorderLayout.CENTER);
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        south.setOpaque(false);
        los.addActionListener(e -> schliessen());
        south.add(los);
        root.add(south, BorderLayout.SOUTH);
        setContentPane(root);
        pack();
        setSize(Math.max(getWidth(), 760), Math.max(getHeight(), 300));
        setLocationRelativeTo(null);
        AppIcon.install(this);
        getRootPane().setDefaultButton(los);
        aufmerken = ev -> {
            if (ev.getSource() instanceof Component c && SwingUtilities.getWindowAncestor(c) == this && !angehalten
                    && ev.getID() == java.awt.event.MouseEvent.MOUSE_PRESSED && !(c instanceof FButton)) anhalten();
        };
        Toolkit.getDefaultToolkit().addAWTEventListener(aufmerken, AWTEvent.MOUSE_EVENT_MASK);
        countLine.setText("Startet in " + rest + " s …");
        timer = new Timer(1000, e -> {
            if (--rest <= 0) schliessen();
            else countLine.setText("Startet in " + rest + " s …");
        });
        timer.start();
    }

    private void anhalten() {
        angehalten = true;
        if (timer != null) timer.stop();
        countLine.setText("Angehalten. „Los“ startet die Szene.");
    }

    private void schliessen() {
        if (timer != null) timer.stop();
        Toolkit.getDefaultToolkit().removeAWTEventListener(aufmerken);
        dispose();
    }
}
