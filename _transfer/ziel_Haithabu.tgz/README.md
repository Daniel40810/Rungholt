# Haithabu – Rauch über dem Noor

Die Wikingersiedlung Haithabu um das Jahr 950 als 3D-Echtzeitszene: am Haddebyer Noor, im Halbkreiswall, mit Hafen, Landebrücken und Schiffen, mit Herdfeuern, Rauch über den Reetdächern, Nebel, Gewitter, einem ganzen Jahr von Schnee bis Ernte, Tieren und Klang. Das Gelände kommt aus dem DGM1 von Schleswig-Holstein, die Siedlung aus dem, was belegt ist, und dort, wo nichts belegt ist (rund 95 % sind nie ausgegraben), aus Regeln. Jede Aussage trägt eine Marke: belegt, gemessen oder gestaltet ([docs/QUELLEN.md](docs/QUELLEN.md)).

![Die Nacht von 1050](docs/bilder/brand.jpg)

*Die Nacht von 1050: Ein Brander ist in den Hafen getrieben, mit dem Ostwind frisst sich der Brand in die Siedlung. Gemessen auf einer Radeon 680M mit 58 Bildern/s.*

Wasser, Himmel, Wetter und Leben kommen als eigenständige Packages aus den Vorgängern Lighthouse und Geyser; neu für Haithabu sind Holzbau, Reet, Rauch, Feuer, Schiffe, das Jahr, Haustiere und die Datenseite. Jedes Package folgt demselben Vertrag: Der Kern braucht nur Java 21 (`java.*`), der Ordner `gl/` dazu JOGL, der Ordner `demo/` dazu FStyle. `check-packages` übersetzt jedes Package einzeln und läuft nach jedem Übersetzen.

## Die Packages

| Package | Inhalt | README |
|---|---|---|
| `com.dan.timber` | Holzbau der Wikingerzeit: sechs Haustypen aus Pfosten, Spaltbohlen, Flechtwerk mit Lehm und Reet, Zäune, Bohlenwege, Palisaden, Landebrücken; Hunderte Häuser in drei Stufen, Nässe, Schnee, Verkohlung und Einsturz | [timber](src/com/dan/timber/README.md) |
| `com.dan.reed` | Schilf, Binsen und Gras im Wind, mit dem Jahr | [reed](src/com/dan/reed/README.md) |
| `com.dan.smoke` | Rauchfahnen nach Briggs, Abendinversion, Rauch im Haus als Schicht unter dem Dach | [smoke](src/com/dan/smoke/README.md) |
| `com.dan.hearth` | Herdfeuer, Fackeln, Essen, Lampen mit Licht und Flackern; der Brand von Häusern mit Wärmestrahlung, Flugfeuer und Einsturz | [hearth](src/com/dan/hearth/README.md) |
| `com.dan.longship` | Langschiff, Knorr und Faering aus Planken und Spanten, unter Segel und Riemen, Anlegen am Liegeplatz | [longship](src/com/dan/longship/README.md) |
| `com.dan.season` | Das Jahr: Schnee auf Boden, Dächern und Bäumen, Eis auf dem Noor, Reif, Laub und Felder | [season](src/com/dan/season/README.md) |
| `com.dan.herd` | Hühner, Ziegen, Schweine und Hunde in Gehegen und Höfen | [herd](src/com/dan/herd/README.md) |
| `com.dan.store` | Datenseite: Einrichter für Oracle-Skripte, Felder als Presets und Zustand, Sitzung, Protokoll, Ablage ohne Datenbank | [store](src/com/dan/store/README.md) |
| `com.dan.ocean` | Das Noor: Windsee aus einem Spektrum, Brandungsring an den Pfählen, Kielwasser und Ringwellen | [ocean](src/com/dan/ocean/README.md) |
| `com.dan.sky` | Sonne, Mond, Planeten und Sterne für 950, Streuung, Dämmerung, Augenanpassung | [sky](src/com/dan/sky/README.md) |
| `com.dan.cloud` | Volumetrische Wolken, Schatten auf Land und Wasser | [cloud](src/com/dan/cloud/README.md) |
| `com.dan.weather` | Die Wetterregie mit acht Lagen (dazu der Föhnsturm aus Glacier, den Haithabu nicht nutzt) und Regiebüchern als Text, mit der Jahreszeit | [weather](src/com/dan/weather/README.md) |
| `com.dan.rain` | Regen: Streifen, Vorhänge, Ringe auf dem Noor | [rain](src/com/dan/rain/README.md) |
| `com.dan.fog` | Nebel in Bänken über dem Wasser | [fog](src/com/dan/fog/README.md) |
| `com.dan.lightning` | Blitze mit Leitblitz, Hauptschlägen und Donner | [lightning](src/com/dan/lightning/README.md) |
| `com.dan.weathering` | Nässe nach Regen, Trocknung mit Wind und Sonne, Moos und Ruß | [weathering](src/com/dan/weathering/README.md) |
| `com.dan.buoyancy` | Schwimmen, Tauchen, Stampfen und Rollen auf beliebigem Wasser | [buoyancy](src/com/dan/buoyancy/README.md) |
| `com.dan.spray` | Spritzer der Riemen und an den Pfählen | [spray](src/com/dan/spray/README.md) |
| `com.dan.flock` | Möwen, Kormorane, Enten, Schwäne, Krähen und Schwalben | [flock](src/com/dan/flock/README.md) |
| `com.dan.soundscape` | Erzeugter Klang ohne Aufnahmen: Wind, Wasser, Tiere, Werkstätten, Markt, Feuer, Donner | [soundscape](src/com/dan/soundscape/README.md) |
| `com.dan.forest` | Eichen, Buchen und Erlen, Laub nach dem Datum (aus Geyser) | [forest](src/com/dan/forest/README.md) |
| `com.dan.ground` | Bodendecke um das Auge: Gras, Farn, Steine (aus Geyser) | [ground](src/com/dan/ground/README.md) |
| `com.dan.kino` | Kinomodus aus Glacier: Regiebücher mit Balken, Vor- und Abspann, Untertiteln, Überblendung, Schwenk und Filmkorn | [kino](src/com/dan/kino/README.md) |
| `com.dan.muster` | Die Vorlage für ein Element-Package | [muster](src/com/dan/muster/README.md) |
| `com.dan.haithabu` | Die App: Gelände, Siedlung, Wall, Hafen, Feuer, Regie, Renderer, Bedienfeld, Datenbank | [haithabu](src/com/dan/haithabu/README.md) |

Dazu liegen `river` und `road` aus Geyser im Projekt; die App nutzt sie nicht.

## Kino und Rückfluss aus Glacier

Ein Regiebuch lässt sich wie im Kino zeigen. Starten geht auf zwei Wegen:

- im Startbild: Regiebuch wählen, „Im Kino“;
- im Block ZEIT unter „Regiebücher“: Haken „Im Kino zeigen“, dann „Starten“.

Bedienfeld, Statuszeile und Titelleiste verschwinden. Die Szene füllt den Bildschirm mit Balken auf 2,39 : 1, und es gibt:

- einen Vorspann mit Titel und Beschreibung,
- Untertitel aus den Stichworten,
- eine Überblendung bei jedem Wechsel der Ansicht,
- einen langsamen Schwenk in stehenden Einstellungen,
- Filmkorn,
- einen Abspann.

Der Ton blendet mit dem Bild. **Esc** beendet das Kino (das Regiebuch läuft weiter), die **Leertaste** hält an, **F12** fotografiert mit Balken. Die Fotos des Blatts bleiben ohne Balken.

Mit dem Kino kamen die Erweiterungen der gemeinsamen Packages aus Glacier zurück:

- `sky`: der Südhimmel.
- `weather`: der Föhnsturm, eigenes Klima je App, Sommer auf der Südhalbkugel.
- `cloud`: die Lentikularis.
- `ocean`: Gletschersee (`Ocean.lago`) mit dem Türkis des Gletschermehls.
- `buoyancy`: Eisberge, Treibeis, Katamaran.
- `flock`: der Andenkondor.
- `forest`: Lenga, Ñire, Guindo.
- `reed`: Horstgras der Steppe (Coirón).
- `season`: Klima El Calafate, das Jahr auf der Südhalbkugel.
- `soundscape`: Gletscher, Wildwasser.
- `spray`: Einschlag ohne Körper (die Kalbung).

Alle Erweiterungen sind abwärtsgleich, ihre Vorgaben bleiben wie zuvor. Haithabu verhält sich darum wie bisher, nur zwei Fallunterscheidungen kennen die neuen Arten (`Vegetation`, `Klang`). Neue Packages wie `ice`, `fracture` und `wave` sind nicht mitgekommen; sie stehen als Idee im Glacier-Werkbuch (Eisgang im Noor).

## Bilder

| | |
|---|---|
| ![Hafen](docs/bilder/hafen.jpg) Der Hafen am Vormittag: Landebrücken, Langschiff und Knorr, Möwen und Schwäne | ![Knorr](docs/bilder/knorr.jpg) Mitfahrt auf der Knorr, die durch die Palisade einläuft (Taste 9) |
| ![Versammlungshaus](docs/bilder/versammlungshaus.jpg) Im Versammlungshaus: Langfeuer, Rauchschicht unter dem Dach | ![Wall](docs/bilder/wall.jpg) Die Fahrt „Über den Wall“ als Bildfolge |
| ![Tiere](docs/bilder/tiere.jpg) Bildfolge „Tiere“: Hafen, Wall, Bach und Gegenufer um 10 Uhr | ![Klang](docs/bilder/klang.jpg) Bildfolge „Klang“ mit den Pegeln am Ohr |
| ![Nacht](docs/bilder/nacht1050.jpg) Das Blatt des Regiebuchs „Die Nacht von 1050“ | ![Jahr](docs/bilder/jahr.jpg) Das Jahr 950 am Noor: Temperatur, Schnee und Eis |
| ![Lageplan](docs/bilder/lageplan.jpg) Der Lageplan aus der Datenbank: 540 Häuser, Wege, Wall, Hafen | ![Spatial Studio](docs/bilder/lageplan_spatialstudio.jpg) Derselbe Plan in Oracle Spatial Studio über der heutigen Karte |
| ![Daten](docs/bilder/daten.jpg) Der Einrichter meldet „alles in Ordnung“; der Block DATEN | ![Symbol](docs/bilder/symbol.png) Das Programmsymbol |

Die Statusbilder jeder Phase liegen in `docs/status/`, das Werkbuch mit Plan und Fortschritt als Artefakt „Haithabu Werkbuch“.

## Bauen und starten

- NetBeans-Projekt mit Ant, JDK 21. In `lib/`: JOGL mit Windows-Natives, `FStyle.jar`, `ojdbc11.jar`, `sdoapi.jar`.
- **Clean and Build** erzeugt `dist/Haithabu.jar` mit `dist/lib`. Danach startet [Haithabu.bat](Haithabu.bat) die App ohne NetBeans, und [Verknuepfung.bat](Verknuepfung.bat) legt eine Verknüpfung mit dem Programmsymbol ([icon/haithabu.ico](icon/haithabu.ico)) auf den Desktop.
- Voraussetzung: OpenGL 4.3 mit Compute-Shadern. Ziel: AMD Radeon 680M (2 GB); dort hält „Mittel“ 60 Bilder/s, auch in der Nacht von 1050. Die Auflösung regelt sich bei Bedarf von selbst.
- Das Gelände liegt in `daten/gelaende/` (48 MB, aus dem DGM1 mit `tools/GelaendeImport`).
- Tasten: F1 zeigt die Übersicht. 1–7 setzen die Ansichten, 8 und 0 starten Fahrten, 9 die Mitfahrt auf der Knorr, V merkt eine Ansicht, P setzt bei einer Aufnahme einen Stützpunkt, F11 zeigt nur die Szene, F12 macht ein Foto. Ein Klick auf ein Haus öffnet die Hauskarte.

## Datenbank

Oracle 21c, Schema `HAITHABU` auf PDBORCL, Präfix `HB_`, Spatial mit SRID 8307. Zugang in `db/db.properties` (Vorlage [db/db.properties.example](db/db.properties.example)); fehlt die Datei, legt die App sie an und fragt im Startbild nach dem Passwort. Der Einrichter legt 22 Tabellen, 8 Sichten, 7 räumliche Indizes und die Startdaten an ([db/sql](db/sql/01_tabellen.sql)); `test/…/DbPruefung` prüft alles und endet mit „Alles in Ordnung.“ Ohne Datenbank läuft die App genauso und speichert in `daten/`. Mehr in [db/README.md](db/README.md).

## Prüfen

- `Pruefung` (Ant-Target `pruefung`): über 200 Prüfungen ohne Grafikkarte und Datenbank, Ende „ERGEBNIS: alles in Ordnung“.
- `check-packages` ([tools/PaketPruefung.java](tools/PaketPruefung.java)): jedes Package für sich übersetzt.
- `tools.Dauerlauf` ([Dauerlauf](src/com/dan/haithabu/tools/Dauerlauf.java)): eine halbe Stunde ohne Fenster durch Regiebücher, Brand, Stufen, Monate und neue Siedlungen; Protokoll in `docs/status/Dauerlauf.txt`, letzte Zeile „Dauerlauf bestanden“.
- `tools.Tempo`: Tempo-Probe und Standbild.

## Quellen

Alle Quellen und Befunde: [docs/QUELLEN.md](docs/QUELLEN.md). Die Befunde stehen auch in der Datenbank (`HB_BEFUND_V`) und in der App unter „Was ist belegt?“.
