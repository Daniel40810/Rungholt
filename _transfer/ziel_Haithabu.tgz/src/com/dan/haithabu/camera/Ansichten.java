package com.dan.haithabu.camera;

import com.dan.haithabu.scene.Terrain;

import java.util.List;
import java.util.Locale;

/**
 * Die Ansichten auf den Tasten 1 bis 7 (F15 A). Phase 2 setzt die, deren Orte schon stehen: „Vom Noor“ (die
 * Grundansicht), „Am Bach“, „Vom Wall“, „Hochburg“ und „Gegenufer“; „Hafen“ steht vorerst am leeren Ufer mit dem
 * Schilf (die Landebrücken baut Phase 8 hier), „Im Haus“ steht seit Phase 11 im Versammlungshaus. Die Augenhöhe wird aus dem Gelände genommen (1,7 m über dem Boden
 * für Standpunkte zu Fuß), darum passen die Ansichten auch nach einem neuen Import der Höhendaten. Phase 7: „Vom Wall“
 * steht auf dem Wehrgang am Westwall (die Bohlen 1 m über dem Kamm, das Auge 1,7 m darüber). Phase 8: „Hafen“ steht auf
 * der Plattform an der Wurzel der dritten Landebrücke und blickt an den Brücken entlang zur Durchfahrt.
 */
public final class Ansichten {
    /** Eine Ansicht: Taste, Name, Lage (x, z), Blickrichtung (Grad von Nord), Neigung (Grad nach unten), Art. */
    public record Ansicht(int key, String name, double x, double z, double heading, double pitch, double eyeAboveGround, boolean orbit, double dist) {
        @Override public String toString() { return key + " " + name; }
    }

    public static final List<Ansicht> ALLE = List.of(
            new Ansicht(1, "Vom Noor", 0, 0, 268, 7, 0, true, 420),
            new Ansicht(2, "Hafen", 6, -80.5, 65, 4, 2.6, false, 0),
            new Ansicht(3, "Am Bach", -166, -16, 92, 3, 1.7, false, 0),
            new Ansicht(4, "Vom Wall", -560.5, -102.8, 95, 4, 2.7, false, 0),
            new Ansicht(5, "Hochburg", -200, -700, 160, 4, 1.7, false, 0),
            new Ansicht(6, "Gegenufer", 700, 60, 272, 5, 1.7, false, 0),
            new Ansicht(7, "Im Haus", 0, 0, 0, 0, 0, false, 0));

    /**
     * Phase 11: „Im Haus“ steht im Versammlungshaus, das mit der Siedlung wechselt: {x, Augenhöhe (absolut), z,
     * Blickrichtung, Neigung}, gesetzt von der App ({@code Versammlungshaus#imHaus}); null = kein Haus.
     */
    public static volatile double[] imHaus;

    /** Ob die Ansicht schon einen Ort hat. */
    public static boolean ready(Ansicht a) { return !a.name().equals("Im Haus") || imHaus != null; }

    public static Ansicht byName(String name) {
        for (Ansicht a : ALLE) if (a.name().equalsIgnoreCase(name) || a.name().replace(" ", "").equalsIgnoreCase(name)) return a;
        return null;
    }

    /** Stellt die Kamera auf die Ansicht; false, wenn sie noch keinen Ort hat. */
    public static boolean apply(Ansicht a, Camera c, Terrain t) {
        if (!ready(a)) return false;
        if (a.name().equals("Im Haus")) {
            double[] p = imHaus;
            c.place(p[0], p[1], p[2], p[3], p[4]);
            return true;
        }
        if (a.orbit()) {
            c.home();
            c.snap();
            return true;
        }
        double ground = Math.max(t.height(a.x(), a.z()), 0);
        c.place(a.x(), ground + a.eyeAboveGround(), a.z(), a.heading(), a.pitch());
        return true;
    }

    /** „5 Hochburg (27 m über dem Noor)“ */
    public static String describe(Ansicht a, Terrain t) {
        if (!ready(a)) return a + " (folgt)";
        if (a.name().equals("Im Haus")) return a + " (Versammlungshaus, Südende)";
        return String.format(Locale.GERMAN, "%s (%.0f m über dem Noor)", a, a.orbit() ? 0 : t.height(a.x(), a.z()));
    }

    private Ansichten() { }
}
