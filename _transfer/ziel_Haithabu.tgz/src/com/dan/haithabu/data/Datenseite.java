package com.dan.haithabu.data;

import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.store.Ablage;
import com.dan.store.Db;
import com.dan.store.Dienst;
import com.dan.store.Protokoll;
import com.dan.timber.House;
import com.dan.timber.HouseType;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Die Datenseite der App (Phase 16): welcher {@link Speicher} gilt, wie die Siedlung daraus geladen und gespeichert
 * wird, und die Brücke zu {@link Dienst} (Sitzung, Protokoll) aus {@code com.dan.store}. Ohne Datenbank gilt
 * {@link DateiSpeicher}; beides kann dasselbe (F36 A).
 */
public final class Datenseite {
    private Datenseite() { }

    private static volatile Speicher speicher;
    /** Das Ergebnis des letzten Einrichtens („alles in Ordnung“ oder der erste Befund), für Startbild und DATEN. */
    public static volatile String einrichterStand = "";
    /** Der Name der Siedlung in der Szene, wie sie im Speicher steht; null, wenn sie neu gewürfelt und nicht gespeichert ist. */
    public static volatile String siedlungName;

    static {
        Protokoll.app = "Haithabu";
        Dienst.faden = "Haithabu-Daten";
        Dienst.ersatz = () -> new DateiSpeicher(DateiSpeicher.ordner());
    }

    /** Der gültige Speicher (ohne Datenbank die Dateien in daten/). */
    public static Speicher speicher() {
        Speicher s = speicher;
        if (s == null) { s = new DateiSpeicher(DateiSpeicher.ordner()); speicher = s; Dienst.setzen(s); }
        return s;
    }

    /** Den Speicher wechseln (nach Verbinden, Einrichten oder „Ohne Datenbank“); die Sitzung zieht mit um. */
    public static void setzen(Speicher s) {
        speicher = s;
        Dienst.setzen(s);
        Protokoll.info("Daten", "Speicher: " + s.wo());
    }

    /** Für DateiSpeicher: woher der Lageplan kommt, sobald die Szene steht. */
    public static void szene(Supplier<Startdaten.Szene> sz) {
        Speicher s = speicher();
        if (s instanceof DateiSpeicher d) d.szene = sz;
    }

    /** Verbinden, wenn db/db.properties ein Passwort hat; sonst null (und warum in grund[0]). */
    public static DbSpeicher verbinden(Db.Konfig k, String[] grund) {
        try {
            if (!k.hatPasswort()) { if (grund != null) grund[0] = "kein Passwort"; return null; }
            return new DbSpeicher(k);
        } catch (Ablage.Fehler e) {
            if (grund != null) grund[0] = e.getMessage();
            return null;
        }
    }

    // ------------------------------------------------------------------ Siedlung

    /** Daten.Haus → Siedlung.Haus. */
    public static Siedlung.Haus haus(Daten.Haus h) {
        House o = new House(HouseType.valueOf(h.haustyp()), h.x(), Double.isNaN(h.y()) ? 0 : h.y(), h.z(), h.richtungGrad(), h.laengeFaktor(), h.breiteFaktor(), h.zustand(), h.zufall());
        return new Siedlung.Haus(h.name(), h.rolle(), o, h.museum());
    }

    /**
     * Die aktive Siedlung aus dem Speicher: Häuser aus der Tabelle oder Datei, Wege und Karten aus dem Startwert. Geht
     * das nicht, die Siedlung aus dem Startwert 950 (und eine Warnung ins Protokoll).
     */
    public static Siedlung laden(Terrain t) {
        try {
            Speicher s = speicher();
            Daten.Siedlung a = s.aktiveSiedlung();
            if (a == null) { siedlungName = null; return Siedlung.haithabu(t); }
            List<Daten.Haus> hs = s.haeuser(a.name());
            siedlungName = a.name();
            if (hs.isEmpty()) return Siedlung.haithabu(t, a.startwert());
            List<Siedlung.Haus> l = new ArrayList<>();
            for (Daten.Haus h : hs) l.add(haus(h));
            Siedlung si = Siedlung.mitHaeusern(t, a.startwert(), l, a.name());
            Protokoll.info("Siedlung", "Siedlung „" + a.name() + "“ geladen: " + l.size() + " Häuser aus " + s.wo());
            return si;
        } catch (Ablage.Fehler | RuntimeException e) {
            Protokoll.warnung("Siedlung", "Siedlung nicht geladen, Startwert 950: " + e.getMessage());
            siedlungName = null;
            return Siedlung.haithabu(t);
        }
    }

    /** Die Häuser einer laufenden Siedlung als Zeilen; die Markierung „von Hand“ übernimmt sie aus alt (gleiche Nummer). */
    public static List<Daten.Haus> zeilen(Siedlung s, List<Daten.Haus> alt) {
        List<Daten.Haus> l = Startdaten.haeuser(s);
        if (alt == null) return l;
        List<Daten.Haus> r = new ArrayList<>();
        for (Daten.Haus h : l) {
            Daten.Haus a = null;
            for (Daten.Haus x : alt) if (x.nr() == h.nr()) a = x;
            r.add(a == null ? h : new Daten.Haus(h.nr(), h.name(), h.haustyp(), h.rolle(), h.x(), h.y(), h.z(), h.richtungGrad(), h.laengeFaktor(), h.breiteFaktor(),
                    h.zustand(), h.zufall(), h.museum(), a.vonHand(), a.bemerkung()));
        }
        return r;
    }

    /** Die laufende Siedlung unter einem eigenen Namen speichern und aktiv setzen. */
    public static void speichernUnter(Siedlung s, String name, String beschreibung) throws Ablage.Fehler {
        Speicher sp = speicher();
        sp.speichern(new Daten.Siedlung(name, s.seed, true, s.haeuser.size(), beschreibung, Daten.EIGEN), zeilen(s, null), Startdaten.wege(s));
        sp.aktivieren(name);
        siedlungName = name;
    }

    /** Die Zeile zu einem Haus der Szene (gleicher Ort auf 5 cm) in der Siedlung des Speichers, oder null. */
    public static Daten.Haus zeile(String siedlung, Siedlung.Haus h) throws Ablage.Fehler {
        Daten.Haus best = null;
        double bd = 0.05;
        for (Daten.Haus x : speicher().haeuser(siedlung)) {
            double d = Math.hypot(x.x() - h.house().x(), x.z() - h.house().z());
            if (d < bd) { bd = d; best = x; }
        }
        return best;
    }

    /**
     * Für die Hauskarte: der Name einer Siedlung, die Änderungen nimmt. Ist die Siedlung der Szene mitgeliefert oder
     * nicht gespeichert, wird sie zuerst als „… (bearbeitet)“ gespeichert und aktiv gesetzt (F28 A).
     */
    public static String bearbeitbar(Siedlung s) throws Ablage.Fehler {
        String n = siedlungName;
        Speicher sp = speicher();
        Daten.Siedlung a = null;
        if (n != null) for (Daten.Siedlung x : sp.siedlungen()) if (x.name().equals(n)) a = x;
        if (a != null && Daten.EIGEN.equals(a.herkunft())) return n;
        String basis = n != null ? n : "Startwert " + s.seed, neu = bearbeitet(basis);
        java.util.Set<String> da = new java.util.HashSet<>();
        for (Daten.Siedlung x : sp.siedlungen()) da.add(x.name());
        for (int i = 2; da.contains(neu); i++) neu = basis + " (bearbeitet " + i + ")";
        speichernUnter(s, neu, "Bearbeitet aus „" + (n != null ? n : "Startwert " + s.seed) + "“ mit der Hauskarte");
        Protokoll.info("Siedlung", "Siedlung als „" + neu + "“ gespeichert (Hauskarte)");
        return neu;
    }

    /** Der Name, unter dem eine mitgelieferte Siedlung beim ersten Bearbeiten gespeichert wird. */
    public static String bearbeitet(String name) { return name + " (bearbeitet)"; }
}
