package com.dan.haithabu.data;

import com.dan.haithabu.camera.Ansichten;
import com.dan.haithabu.scene.Befestigung;
import com.dan.haithabu.scene.Flotte;
import com.dan.haithabu.scene.Hafen;
import com.dan.haithabu.scene.Regie;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.longship.Longship;
import com.dan.longship.ShipType;
import com.dan.store.Felder;
import com.dan.timber.HouseType;
import com.dan.weather.Weather;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Die mitgelieferten Daten (Phase 16): was {@code 04_startdaten.sql} in die Datenbank legt und was ohne Datenbank
 * gilt. Haustypen und Schiffstypen kommen aus den Enums von {@code timber} und {@code longship}, die Regiebücher aus
 * {@code scene/regie/*.txt}, Quellen und Befunde aus {@code quellen.txt} und {@code befunde.txt} neben dieser Klasse,
 * die Presets aus den Fabrikmethoden der Packages. Die Siedlung „Haithabu 950“ und der Lageplan werden aus der Szene
 * gerechnet ({@link Szene}); gleicher Startwert und gleiches Gelände, gleiche Zahlen.
 */
public final class Startdaten {
    private Startdaten() { }

    public static final String SIEDLUNG = "Haithabu 950";
    public static final long STARTWERT = 950;

    // ------------------------------------------------------------------ Quellen und Befunde

    private static List<String> zeilen(String datei) {
        try (InputStream in = Startdaten.class.getResourceAsStream(datei)) {
            if (in == null) throw new IllegalStateException(datei + " fehlt im Build");
            List<String> l = new ArrayList<>();
            for (String z : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\\R")) if (!z.isBlank() && !z.startsWith("#")) l.add(z);
            return l;
        } catch (IOException e) {
            throw new IllegalStateException(datei + " nicht lesbar: " + e.getMessage(), e);
        }
    }

    private static String leer(String s) { s = s.strip(); return s.isEmpty() || s.equals("-") ? null : s; }

    public static List<Daten.Quelle> quellen() {
        List<Daten.Quelle> l = new ArrayList<>();
        for (String z : zeilen("quellen.txt")) {
            String[] p = z.split("\\|", -1);
            String ab = leer(p[4]);
            l.add(new Daten.Quelle(p[0].strip(), p[1].strip(), leer(p[2]), p[3].strip(), ab == null ? null : LocalDate.parse(ab), leer(p[5])));
        }
        return l;
    }

    public static List<Daten.Befund> befunde() {
        List<Daten.Befund> l = new ArrayList<>();
        for (String z : zeilen("befunde.txt")) {
            String[] p = z.split("\\|", -1);
            List<String> q = new ArrayList<>();
            for (String k : p[4].split(",")) if (!k.isBlank()) q.add(k.strip());
            l.add(new Daten.Befund(p[0].strip(), p[1].strip(), p[2].strip(), p[3].strip(), q));
        }
        return l;
    }

    /** Der Befund zu einem Gegenstand oder null. */
    public static Daten.Befund befund(String gegenstand) {
        for (Daten.Befund b : befunde()) if (b.gegenstand().equals(gegenstand)) return b;
        return null;
    }

    // ------------------------------------------------------------------ Typen

    /** Welcher Befund zu welchem Haustyp gehört. */
    static String befundGegenstand(HouseType t) {
        return switch (t) {
            case HALLE -> "Hallenhaus";
            case WOHNHAUS -> "Wohnhaus";
            case BOHLENHAUS -> "Spaltbohlenhaus";
            case UFERHAUS -> "Uferhaus";
            case GRUBENHAUS -> "Grubenhaus";
            case SCHUPPEN -> "Werkstattschuppen";
        };
    }

    public static List<Daten.Haustyp> haustypen() {
        List<Daten.Haustyp> l = new ArrayList<>();
        for (HouseType t : HouseType.values()) {
            Daten.Befund b = befund(befundGegenstand(t));
            l.add(new Daten.Haustyp(t.name(), t.label, t.length, t.width, t.wallHeight, t.pitchDeg, t.wall.name(), t.sunk, b.befund(), b.gegenstand(), b.text()));
        }
        return l;
    }

    public static List<Daten.Schiffstyp> schiffstypen() {
        List<Daten.Schiffstyp> l = new ArrayList<>();
        for (ShipType t : ShipType.values()) {
            String g = switch (t) { case LANGSCHIFF -> "Haithabu 1"; case KNORR -> "Knorr"; case FAERING -> "Faering"; };
            String vorbild = switch (t) { case LANGSCHIFF -> "Haithabu 1 (um 985)"; case KNORR -> "Haithabu 3 (um 1023)"; case FAERING -> null; };
            Daten.Befund b = befund(g);
            l.add(new Daten.Schiffstyp(t.name(), t.label, vorbild, t.length, t.beam, t.draft, t.oarPairs, t.sailWidth > 0, t.displacement, b.befund(), g));
        }
        return l;
    }

    // ------------------------------------------------------------------ Wetterlagen

    public static List<Daten.Wetterlage> wetterlagen() {
        List<Daten.Wetterlage> l = new ArrayList<>();
        String[] namen = {"Klar", "Aufziehend", "Front", "Sturm", "Gewitter", "Abklingend", "Aufklarend", "Seenebel"};
        String[] monate = {"1-12", "1-12", "1-12", "9-3", "5-8", "1-12", "1-12", "9-11"};
        String[] text = {"Hoch über der westlichen Ostsee, leichte Brise über dem Noor, Schönwetterwolken",
                "Ein Tief nähert sich: Cirren, rückdrehender Wind",
                "Die Front: geschlossene Regenschicht, der Wind frischt auf",
                "Sturm aus Südwest bis West, Schauer; auf dem Noor höchstens Bft 7 (F7)",
                "Sommergewitter über der Schlei, Böen und Starkregen",
                "Der Sturm flaut ab, Schauer, aufklarender Himmel",
                "Rückseite: klare Luft, weite Sicht, Wind auf Nordwest",
                "Schwacher Wind, feuchte Luft über kühlerem Wasser, dichter Nebel über dem Noor"};
        Weather.Phase[] ph = Weather.Phase.values();
        for (int i = 0; i < ph.length; i++) {
            double[] w = Weather.target(ph[i]);
            w[Weather.Var.SWELL.ordinal()] = Double.NaN;
            l.add(new Daten.Wetterlage(namen[i], (double) Weather.beaufort(w[0]), ph[i].name(), w, monate[i], text[i], Daten.MITGELIEFERT));
        }
        //                         Wind Richt Böig Bed hoch Wolke Regen Sicht Nebel Druck Temp Feuchte Dünung Gewitter
        l.add(new Daten.Wetterlage("Windstille", 0.0, "KLAR", new double[]{0.2, 180, 0.05, 0, 0.1, 0, 0, 40, 0, 1032, 15, 70, Double.NaN, 0}, "1-12",
                "Das Noor spiegelglatt, wolkenlos, Hochdruck [G]", Daten.MITGELIEFERT));
        l.add(new Daten.Wetterlage("Nebelmorgen im Herbst", 0.0, "NEBEL", new double[]{0.6, 160, 0.05, 0.5, Double.NaN, Double.NaN, 0, 10, 0.9, 1026, 5, 99, Double.NaN, 0},
                "9-11", "Wie der erste Schritt von „Ein Nebelmorgen“: windstill, Nebel liegt flach über dem Noor [G]", Daten.MITGELIEFERT));
        l.add(new Daten.Wetterlage("Ostwind 1050", 4.0, "KLAR", new double[]{com.dan.haithabu.wiring.Beaufort.mid(4), 80, 0.14, 1, Double.NaN, Double.NaN, 0, Double.NaN, 0,
                Double.NaN, Double.NaN, Double.NaN, Double.NaN, 0}, "10",
                "Die Nacht von 1050: Ostwind Bft 4 über See, klar, trocken [G]", Daten.MITGELIEFERT));
        l.add(new Daten.Wetterlage("Schneetag", 3.0, "FRONT", new double[]{5, 70, 0.12, 8, Double.NaN, 1, 1.5, 3, 0, 1018, -2, 92, Double.NaN, 0}, "12-2",
                "Grauer Wintertag mit leichtem Schneefall aus Ost, um −2 °C [G]", Daten.MITGELIEFERT));
        return l;
    }

    // ------------------------------------------------------------------ Regiebücher

    public static List<Daten.Regiebuch> regiebuecher() {
        List<Daten.Regiebuch> l = new ArrayList<>();
        for (String d : Regie.DATEIEN) {
            String t = Regie.text(d);
            Regie.Book b = Regie.parse(t);
            l.add(new Daten.Regiebuch(b.name(), t, b.about(), Daten.MITGELIEFERT));
        }
        return l;
    }

    // ------------------------------------------------------------------ Ansichten und Fahrten

    /** Die sieben festen Ansichten (Tasten 1–7) aus {@link Ansichten#ALLE}. Kamera: x, Augenhöhe NaN (aus dem Gelände), z, Blick, Neigung. */
    public static List<Daten.Ansicht> ansichten() {
        List<Daten.Ansicht> l = new ArrayList<>();
        for (Ansichten.Ansicht a : Ansichten.ALLE)
            l.add(new Daten.Ansicht(0, a.name(), a.key(), "FEST", new double[]{a.x(), Double.NaN, a.z(), a.heading(), a.pitch(), Double.NaN},
                    a.eyeAboveGround(), a.orbit(), a.orbit() ? a.dist() : null, null, null, null, Daten.MITGELIEFERT));
        return l;
    }

    /** Die drei Fahrten; „Durch die Gasse“ mit den Stützpunkten der Szene, wenn sie gegeben ist. */
    public static List<Daten.Fahrt> fahrten(List<Daten.Stuetzpunkt> gasse) {
        return List.of(
                new Daten.Fahrt("Über den Wall", 8, "WALLKAMM", false, "Auf dem Wehrgang vom Südende am Noor bis zum Nordende; die App folgt dem Kamm aus dem Gelände", Daten.MITGELIEFERT, List.of()),
                new Daten.Fahrt("Mitfahrt", 9, "MITFAHRT", false, "Am Steuer der einlaufenden Knorr: unter Segel heran, durch die Palisade, an den Querkopf", Daten.MITGELIEFERT, List.of()),
                new Daten.Fahrt("Durch die Gasse", 0, "STUETZPUNKTE", false, "Auf dem Bohlenweg am Bach, durch den Hof und die Osttür ins Versammlungshaus; die App rechnet sie aus der aktiven Siedlung",
                        Daten.MITGELIEFERT, gasse == null ? List.of() : gasse));
    }

    // ------------------------------------------------------------------ Presets

    /** Die Klassen, deren Presets mitkommen: jede öffentliche statische Methode ohne Argument, die die Klasse liefert. */
    public static final String[] PAKETE = {"com.dan.ocean.Ocean", "com.dan.reed.Reed", "com.dan.cloud.Clouds", "com.dan.rain.Rain", "com.dan.fog.Fog",
            "com.dan.lightning.Lightning", "com.dan.weathering.Weathering", "com.dan.buoyancy.Buoyancy", "com.dan.flock.Flock", "com.dan.soundscape.Soundscape",
            "com.dan.spray.Spray"};
    private static List<Daten.PaketPreset> presets;

    public static synchronized List<Daten.PaketPreset> presets() {
        if (presets != null) return presets;
        List<Daten.PaketPreset> l = new ArrayList<>();
        for (String k : PAKETE) {
            try {
                Class<?> c = Class.forName(k);
                List<Method> ms = new ArrayList<>();
                for (Method m : c.getMethods())
                    if (Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0 && m.getReturnType() == c) ms.add(m);
                ms.sort(Comparator.comparing(Method::getName));
                for (Method m : ms) {
                    Object o = m.invoke(null);
                    l.add(new Daten.PaketPreset(c.getPackageName(), c.getSimpleName(), m.getName(), "Preset " + m.getName() + "() aus " + c.getPackageName(),
                            Daten.MITGELIEFERT, Felder.lesen(o)));
                }
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Preset von " + k + " nicht lesbar: " + e, e);
            }
        }
        presets = Collections.unmodifiableList(l);
        return presets;
    }

    // ------------------------------------------------------------------ aus der Szene

    /** Was aus der Szene gerechnet wird: Siedlung mit Häusern und Wegen, Lageplan, Gelände, Flotte, Stützpunkte der Gasse. */
    public record Szene(Daten.Siedlung siedlung, List<Daten.Haus> haeuser, List<Daten.Weg> wege, List<Daten.Bauwerk> bauwerke, Daten.Gelaende gelaende,
                        List<Daten.Schiff> schiffe, List<Daten.Stuetzpunkt> gasse) { }

    /** Die Häuser einer Siedlung als Zeilen, in ihrer Reihenfolge (NR ab 1). */
    public static List<Daten.Haus> haeuser(Siedlung s) {
        List<Daten.Haus> l = new ArrayList<>();
        int nr = 0;
        for (Siedlung.Haus h : s.haeuser) {
            var o = h.house();
            l.add(new Daten.Haus(++nr, h.name(), o.type().name(), h.rolle(), o.x(), o.y(), o.z(), o.headingDeg(), o.lengthScale(), o.widthScale(), o.state(), o.seed(),
                    h.museum(), false, null));
        }
        return l;
    }

    /** Wege, Zäune und Gärten einer Siedlung. */
    public static List<Daten.Weg> wege(Siedlung s) {
        List<Daten.Weg> l = new ArrayList<>();
        int[] n = new int[4];
        for (Siedlung.Weg w : s.wege) {
            if (w.punkte().length < 2) continue;
            int k = switch (w.art()) { case "GASSE" -> 0; case "BOHLENWEG" -> 1; case "ZAUN" -> 2; default -> 3; };
            String name = switch (k) { case 0 -> "Gasse "; case 1 -> "Bohlenweg "; case 2 -> "Zaun "; default -> "Garten "; } + (++n[k]);
            l.add(new Daten.Weg(w.art(), name, w.art().equals("GARTEN") ? Daten.Geom.flaeche(w.punkte()) : Daten.Geom.linie(w.punkte()), w.breite()));
        }
        return l;
    }

    private static Daten.Bauwerk bw(String art, String name, Daten.Geom g, Double h, Double b, String gegenstand, String text) {
        Daten.Befund bf = befund(gegenstand);
        return new Daten.Bauwerk(art, name, g, h, b, bf == null ? Daten.GESTALTET : bf.befund(), gegenstand, text);
    }

    /** Jeder n-te Punkt (Linien des Plans brauchen nicht jede Probe zu 2 m), Anfang und Ende immer. */
    static double[][] duenn(double[][] p, int n) {
        List<double[]> l = new ArrayList<>();
        for (int i = 0; i < p.length; i++) if (i % n == 0 || i == p.length - 1) l.add(new double[]{p[i][0], p[i][1]});
        return l.toArray(new double[0][]);
    }

    /** Der Lageplan aus der Szene (F29 A). */
    public static List<Daten.Bauwerk> bauwerke(Terrain t, Siedlung s) {
        List<Daten.Bauwerk> l = new ArrayList<>();
        Befestigung w = s.wall;
        Hafen h = s.hafen;
        if (w != null) {
            int n = w.x.length;
            double[][] kamm = new double[n][], graben = new double[n][], pal = new double[n][];
            for (int i = 0; i < n; i++) {
                kamm[i] = new double[]{w.x[i], w.z[i]};
                graben[i] = new double[]{w.x[i] + w.nx[i] * Befestigung.GRABEN_MITTE, w.z[i] + w.nz[i] * Befestigung.GRABEN_MITTE};
                pal[i] = new double[]{w.x[i] + w.nx[i] * Befestigung.PAL_OFF, w.z[i] + w.nz[i] * Befestigung.PAL_OFF};
            }
            l.add(bw("WALLKAMM", "Halbkreiswall", Daten.Geom.linie(duenn(kamm, 4)), 9.0, 2 * Befestigung.FLACH, "Kammlinie des Halbkreiswalls",
                    String.format(Locale.GERMAN, "Kammlinie %,.0f m, %.0f %% im DGM1 gemessen, Nordwestbogen und Enden ergänzt", w.length, w.gemessen * 100)));
            l.add(bw("GRABEN", "Graben vor dem Wall", Daten.Geom.linie(duenn(graben, 4)), -Befestigung.GRABEN_TIEFE, 2 * Befestigung.GRABEN_HALB, "Graben, Palisade, Wehrgang",
                    "Graben 17 m vor der Kammlinie, 10 m breit, 2 m tief [G]"));
            l.add(bw("WALLPALISADE", "Palisade auf dem Wall", Daten.Geom.linie(duenn(pal, 4)), Befestigung.PAL_H, null, "Graben, Palisade, Wehrgang",
                    "Palisade 3 m auf der Außenkante des Walls, Wehrgang dahinter [G]"));
            if (h != null && h.ufer.size() > 2) {
                List<double[]> ring = new ArrayList<>(Arrays.asList(duenn(kamm, 4)));
                for (int i = h.ufer.size() - 1; i >= 0; i -= 2) ring.add(new double[]{h.ufer.get(i)[0], h.ufer.get(i)[1]});
                Daten.Geom f = Daten.Geom.flaeche(ring.toArray(new double[0][]));
                l.add(bw("WALLFLAECHE", "Fläche im Halbkreiswall", f, null, null, "Höhe und Fläche des Walls",
                        String.format(Locale.GERMAN, "Zwischen Kammlinie und Ufer von 950: %.1f ha (Literatur 26 ha)", f.flaecheM2() / 10_000)));
            }
            for (Befestigung.Tor tor : w.tore) {
                int k = 0;
                for (int i = 0; i < n; i++) if (Math.abs(w.s[i] - tor.s()) < Math.abs(w.s[k] - tor.s())) k = i;
                l.add(bw(tor.bach() ? "BACHDURCHLASS" : "TOR", tor.name(), Daten.Geom.punkt(w.x[k], w.z[k]), null, tor.bach() ? null : Befestigung.TOR_BREITE, "Tore",
                        tor.bach() ? "Der Haithabu-Bach läuft durch den Wall" : "Torbau [G]; " + String.format(Locale.GERMAN, "%,.0f m vom Südende der Kammlinie", tor.s())));
            }
            double hr = Math.toRadians(Befestigung.HB_HEADING), ax = Math.sin(hr), az = -Math.cos(hr), bx = Math.cos(hr), bz = Math.sin(hr);
            double hl = Befestigung.HB_L / 2, hw = Befestigung.HB_W / 2, cx = Befestigung.HB_X, cz = Befestigung.HB_Z;
            l.add(bw("HOCHBURG", "Hochburg", Daten.Geom.flaeche(new double[][]{{cx - ax * hl - bx * hw, cz - az * hl - bz * hw}, {cx + ax * hl - bx * hw, cz + az * hl - bz * hw},
                    {cx + ax * hl + bx * hw, cz + az * hl + bz * hw}, {cx - ax * hl + bx * hw, cz - az * hl + bz * hw}}), Befestigung.HB_WALL, null, "Hochburg",
                    "Innenfläche 240 × 72 m auf der Moränenkuppe, Wall 2 m um 950, Tor im Nordosten [G in Lage und Maß]"));
            int g = 0;
            for (double[] k : w.kuppen)
                l.add(bw("GRABHUEGEL", String.format("Grabhügel %02d", ++g), Daten.Geom.punkt(k[0], k[1]), Math.round(k[2] * 100) / 100.0, Math.round(2 * k[3] * 100) / 100.0,
                        "Grabhügel der Hochburg", "Kuppe im DGM1; Höhe um 950 gestaltet"));
            int v = 0;
            for (double[][] line : Befestigung.VERBINDUNG)
                l.add(bw("WALL_EINGEEBNET", "Verbindungswall, Stück " + (++v), Daten.Geom.linie(line), null, null, "Verbindungswall",
                        "Im DGM1 erhalten, um 950 noch nicht gebaut (um 968): eingeebnet (F24)"));
        }
        if (h != null) {
            int p = 0;
            for (double[][] pl : h.plattformen)
                l.add(bw("PLATTFORM", "Plattform " + (++p), Daten.Geom.linie(pl), Hafen.DECK, Hafen.PLATTFORM_BREITE, "Landebrücken und Plattformen",
                        String.format(Locale.GERMAN, "Plattform am Ufer, %.0f m lang, 13 m breit", Daten.Geom.linie(pl).laenge())));
            int b = 0;
            for (Hafen.Bruecke br : h.bruecken)
                l.add(bw("LANDEBRUECKE", (br.querkopf() ? "Querkopf " : "Landebrücke ") + (++b), Daten.Geom.linie(new double[][]{{br.x0(), br.z0()}, {br.x1(), br.z1()}}),
                        Hafen.DECK, br.width(), "Landebrücken und Plattformen", String.format(Locale.GERMAN, "%.0f m lang, %.1f m breit", br.length(), br.width())));
            if (h.umschlag != null && h.umschlag.length > 1)
                l.add(bw("UMSCHLAGPLATZ", "Umschlagplatz", Daten.Geom.linie(h.umschlag), Hafen.DECK, h.umschlagBreite, "Landebrücken und Plattformen", "Markt und Umschlag am Hafen"));
            int q = 0;
            for (double[][] pl : h.palisade)
                l.add(bw("HAFENPALISADE", "Hafenpalisade " + (++q), Daten.Geom.linie(duenn(pl, 3)), Hafen.PALISADE_TOP, null, "Hafenpalisade", "Pfahlreihe im Wasser, Kopf 1,3 m über dem Mittelwasser"));
            if (h.durchfahrt != null)
                l.add(bw("DURCHFAHRT", "Durchfahrt", Daten.Geom.punkt(h.durchfahrt[0], h.durchfahrt[1]), null, Hafen.DURCHFAHRT, "Durchfahrt", "14 m breit, nach Nordost zur Schlei"));
            if (h.becken != null && h.becken.length > 2)
                l.add(bw("HAFENBECKEN", "Hafenbecken", Daten.Geom.flaeche(duenn(h.becken, 3)), null, null, "Hafenpalisade",
                        String.format(Locale.GERMAN, "Becken innerhalb der Palisade, %.1f ha (Literatur 8 bis 11 ha)", h.flaecheHa)));
            if (h.ufer.size() > 1) {
                double[][] u = new double[h.ufer.size()][];
                for (int i = 0; i < u.length; i++) u[i] = new double[]{h.ufer.get(i)[0], h.ufer.get(i)[1]};
                l.add(bw("UFER_950", "Ufer von 950", Daten.Geom.linie(duenn(u, 2)), null, null, "Uferlinie von 950", "Ufer zwischen den Wallenden, rund 1 m unter dem heutigen [G]"));
            }
        }
        if (t.brook != null && t.brook.length > 1)
            l.add(bw("BACH", "Haithabu-Bach", Daten.Geom.linie(duenn(t.brook, 2)), null, null, "Haithabu-Bach", "Lauf aus dem Gelände gefunden, bis zur Mündung am Ufer von 950"));
        double[][] damm = new double[com.dan.haithabu.tools.GelaendeImport.DAMM.length][];
        for (int i = 0; i < damm.length; i++) {
            double[] ll = com.dan.haithabu.scene.Geo.UTM32.inverse(com.dan.haithabu.tools.GelaendeImport.DAMM[i][0], com.dan.haithabu.tools.GelaendeImport.DAMM[i][1]);
            damm[i] = com.dan.haithabu.scene.Site.xz(ll);
        }
        l.add(bw("DAMM_ENTFERNT", "Damm zwischen Noor und Schlei", Daten.Geom.linie(damm), null, com.dan.haithabu.tools.GelaendeImport.DAMM_BREITE, "Damm zwischen Noor und Schlei",
                "Damm von Bundesstraße und Bahn, für 950 auf Wasser gesetzt (F23)"));
        return l;
    }

    /** Eckdaten des Geländes; die Prüfsumme ist SHA-256 der Höhendatei in dir (oder null). */
    public static Daten.Gelaende gelaende(Terrain t, File dir) {
        long gem = 0;
        for (byte b : t.src) if (b == Terrain.GEMESSEN) gem++;
        double x0 = Terrain.X0, z0 = Terrain.Z0, x1 = x0 + Terrain.N * Terrain.CELL, z1 = z0 + Terrain.N * Terrain.CELL;
        String sum = null;
        File f = dir == null ? null : new File(dir, Terrain.HOEHE);
        if (f != null && f.isFile()) sum = sha256(f);
        String quelle = t.props.getProperty("quelle", "DGM1 Schleswig-Holstein");
        return new Daten.Gelaende("Haddebyer Noor", quelle, Daten.Geom.flaeche(new double[][]{{x0, z0}, {x1, z0}, {x1, z1}, {x0, z1}}),
                com.dan.haithabu.scene.Site.LON, com.dan.haithabu.scene.Site.LAT, Terrain.CELL, Terrain.N, Terrain.N, Math.round(1000.0 * gem / t.src.length) / 10.0,
                "daten/gelaende/" + Terrain.HOEHE, sum,
                "Damm zwischen Noor und Schlei entfernt (F23); Verbindungswall eingeebnet (F24); Noorgrund modelliert, Uferlinie von 950 rund 1 m unter heute; Wall geformt (Phase 7)");
    }

    public static String sha256(File f) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            try (InputStream in = Files.newInputStream(f.toPath())) {
                byte[] buf = new byte[1 << 16];
                for (int n; (n = in.read(buf)) > 0; ) md.update(buf, 0, n);
            }
            StringBuilder b = new StringBuilder();
            for (byte x : md.digest()) b.append(String.format("%02x", x));
            return b.toString();
        } catch (IOException | java.security.NoSuchAlgorithmException e) {
            return null;
        }
    }

    /** Die Flotte mit Liegeplätzen. */
    public static List<Daten.Schiff> schiffe(Flotte f) {
        List<Daten.Schiff> l = new ArrayList<>();
        if (f == null) return l;
        for (Longship s : f.ships) {
            String rolle = s == f.einlaeufer ? "KNORR" : f.fischer.contains(s) ? "FISCHER" : "LIEGER";
            l.add(new Daten.Schiff(s.name, s.type.name(), rolle, s.x, s.z, s.heading, null,
                    s.type == ShipType.KNORR ? "Mühlsteine, Specksteintöpfe, Fässer [G]" : null));
        }
        l.add(new Daten.Schiff(f.brander.name, f.brander.type.name(), "BRANDER", f.start == null ? null : f.start[0], f.start == null ? null : f.start[1], null, null,
                "Pech und Reet: der Brander der Nacht von 1050 [G]"));
        return l;
    }

    /** Alles aus der Szene für die Startdaten. */
    public static Szene szene(Terrain t, Siedlung s, Flotte f, List<Daten.Stuetzpunkt> gasse, File gelaendeDir) {
        Daten.Siedlung kopf = new Daten.Siedlung(SIEDLUNG, s.seed, true, s.haeuser.size(),
                "Die Siedlung aus dem Startwert 950 mit den sieben Häusern am Bach (Phasen 5 bis 7)", Daten.MITGELIEFERT);
        return new Szene(kopf, haeuser(s), wege(s), bauwerke(t, s), gelaende(t, gelaendeDir), schiffe(f), gasse);
    }

    /** Stützpunkte einer Fahrt der Kamera als Zeilen. */
    public static List<Daten.Stuetzpunkt> punkte(com.dan.haithabu.camera.Fahrt fahrt) {
        List<Daten.Stuetzpunkt> l = new ArrayList<>();
        if (fahrt == null) return l;
        double[][] p = fahrt.stuetzpunkte();
        for (int i = 0; i < p.length; i++) l.add(new Daten.Stuetzpunkt(i + 1, p[i][0], p[i][1], p[i][2], p[i][3], p[i][4], p[i][5], Double.NaN));
        return l;
    }

    /** Für Anzeigen: wie viele Zeilen je Art mitkommen. */
    public static Map<String, Integer> zahlen(Szene sz) {
        Map<String, Integer> m = new LinkedHashMap<>();
        m.put("Quellen", quellen().size());
        m.put("Befunde", befunde().size());
        m.put("Haustypen", haustypen().size());
        m.put("Häuser", sz.haeuser().size());
        m.put("Wege", sz.wege().size());
        m.put("Bauwerke", sz.bauwerke().size());
        m.put("Schiffstypen", schiffstypen().size());
        m.put("Schiffe", sz.schiffe().size());
        m.put("Wetterlagen", wetterlagen().size());
        m.put("Regiebücher", regiebuecher().size());
        m.put("Ansichten", ansichten().size());
        m.put("Fahrten", 3);
        m.put("Presets", presets().size());
        return m;
    }

    static final LocalDate START = SceneClock.START_DATE;
}
