package com.dan.haithabu.data;

import com.dan.store.Db;
import com.dan.store.Einrichter;
import com.dan.weather.Weather;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Das Schema HAITHABU (F17 A, F26 A): Ort von {@code db/}, Zugang aus {@code db/db.properties} und der Einrichter mit
 * allem, was er für Haithabu prüft. Schema und Benutzer legt {@code db/USER.sql} an (Haithabu auf PDBORCL).
 */
public final class Verbindung {
    private Verbindung() { }

    public static final String PRAEFIX = "HB_";
    public static final String ENV = "HAITHABU_DB_PASSWORD";
    /** Die Ausbaustufe dieser App (HB_SCHEMA.VERSION). */
    public static final int VERSION = 1;
    public static final String[] SICHTEN = {"HB_HAUS_V", "HB_BAUWERK_V", "HB_SCHIFF_V", "HB_LAGEPLAN_V", "HB_UFERZEILE_V", "HB_IM_WALL_V", "HB_BEFUND_V",
            "HB_LETZTE_SITZUNG_V"};
    public static final String[] METADATEN = {"HB_HAUS.LAGE", "HB_HAUS.GRUNDRISS", "HB_WEG.GEOM", "HB_BAUWERK.GEOM", "HB_GELAENDE.AUSSCHNITT",
            "HB_GELAENDE.URSPRUNG", "HB_SCHIFF.LIEGEPLATZ"};

    /** Die Wetterspalten von HB_WETTERLAGE in der Reihenfolge von {@code Weather.Var} (die Dünung hat keine). */
    public static final Map<Weather.Var, String> WETTER = new LinkedHashMap<>();
    static {
        WETTER.put(Weather.Var.WIND, "WIND_MS");
        WETTER.put(Weather.Var.DIRECTION, "RICHTUNG_GRAD");
        WETTER.put(Weather.Var.GUST, "BOEIGKEIT");
        WETTER.put(Weather.Var.COVER, "BEDECKUNG_ACHTEL");
        WETTER.put(Weather.Var.HIGH, "HOHE_SCHICHT");
        WETTER.put(Weather.Var.CLOUD, "WOLKENART");
        WETTER.put(Weather.Var.RAIN, "REGEN_MMH");
        WETTER.put(Weather.Var.VISIBILITY, "SICHT_KM");
        WETTER.put(Weather.Var.FOG, "NEBEL");
        WETTER.put(Weather.Var.PRESSURE, "LUFTDRUCK_HPA");
        WETTER.put(Weather.Var.TEMPERATURE, "TEMPERATUR_C");
        WETTER.put(Weather.Var.HUMIDITY, "FEUCHTE_PROZ");
        WETTER.put(Weather.Var.THUNDER, "GEWITTER");
    }

    /** Der Ordner db: -Dhaithabu.db.dir, sonst ./db, sonst db neben dem Jar. */
    public static File ordner() { return Db.ordner("haithabu.db.dir", Verbindung.class); }

    public static File skripte() { return new File(ordner(), "sql"); }

    /**
     * Der Zugang aus db/db.properties. Fehlt die Datei, wird sie aus der Vorlage db.properties.example angelegt (ohne
     * Passwort); das Startbild fragt dann danach und trägt es nach dem Verbinden ein (F26 A).
     */
    public static Db.Konfig konfig() throws IOException {
        File f = new File(ordner(), "db.properties"), vorlage = new File(ordner(), "db.properties.example");
        if (!f.isFile() && vorlage.isFile()) java.nio.file.Files.copy(vorlage.toPath(), f.toPath());
        return Db.konfig(f, "Haithabu", ENV);
    }

    /** Die Spatial-Indizes (je Geometriespalte einer: HB_HAUS_LAGE_SX …). */
    public static String[] raeumlich() {
        String[] r = new String[METADATEN.length];
        for (int i = 0; i < r.length; i++) r[i] = METADATEN[i].replace('.', '_') + "_SX";
        return r;
    }

    /**
     * Die Zahlen der Startdaten aus der Zeile {@code -- ZAHLEN: Art=n; …} von 04_startdaten.sql (die Häuser, Wege und
     * Bauwerke hängen an der Szene; so muss der Einrichter sie nicht neu rechnen).
     */
    public static Map<String, Integer> zahlen(File dir) {
        Map<String, Integer> m = new LinkedHashMap<>();
        try {
            for (String z : Files.readAllLines(new File(dir, "04_startdaten.sql").toPath(), StandardCharsets.UTF_8)) {
                if (!z.startsWith("-- ZAHLEN:")) continue;
                for (String p : z.substring(10).split(";")) {
                    String[] kv = p.strip().split("=");
                    if (kv.length == 2) m.put(kv[0].strip(), Integer.parseInt(kv[1].strip()));
                }
                break;
            }
        } catch (IOException | RuntimeException e) { /* dann prüft der Einrichter ohne Zahlen */ }
        return m;
    }

    /** Die SQL-Abfrage je Zahl der Startdaten. */
    static final Map<String, String> ZAEHLEN = new LinkedHashMap<>();
    static {
        String m = " WHERE HERKUNFT = 'MITGELIEFERT'";
        ZAEHLEN.put("Quellen", "SELECT COUNT(*) FROM HB_QUELLE" + m);
        ZAEHLEN.put("Befunde", "SELECT COUNT(*) FROM HB_BEFUND" + m);
        ZAEHLEN.put("Belege", "SELECT COUNT(*) FROM HB_BEFUND_QUELLE x JOIN HB_BEFUND b ON b.ID = x.BEFUND_ID WHERE b.HERKUNFT = 'MITGELIEFERT'");
        ZAEHLEN.put("Haustypen", "SELECT COUNT(*) FROM HB_HAUSTYP" + m);
        ZAEHLEN.put("Siedlungen", "SELECT COUNT(*) FROM HB_SIEDLUNG" + m);
        ZAEHLEN.put("Häuser", "SELECT COUNT(*) FROM HB_HAUS h JOIN HB_SIEDLUNG s ON s.ID = h.SIEDLUNG_ID WHERE s.HERKUNFT = 'MITGELIEFERT'");
        ZAEHLEN.put("Wege", "SELECT COUNT(*) FROM HB_WEG w JOIN HB_SIEDLUNG s ON s.ID = w.SIEDLUNG_ID WHERE s.HERKUNFT = 'MITGELIEFERT'");
        ZAEHLEN.put("Bauwerke", "SELECT COUNT(*) FROM HB_BAUWERK" + m);
        ZAEHLEN.put("Gelände", "SELECT COUNT(*) FROM HB_GELAENDE" + m);
        ZAEHLEN.put("Schiffstypen", "SELECT COUNT(*) FROM HB_SCHIFFSTYP" + m);
        ZAEHLEN.put("Schiffe", "SELECT COUNT(*) FROM HB_SCHIFF" + m);
        ZAEHLEN.put("Wetterlagen", "SELECT COUNT(*) FROM HB_WETTERLAGE" + m);
        ZAEHLEN.put("Regiebücher", "SELECT COUNT(*) FROM HB_REGIEBUCH" + m);
        ZAEHLEN.put("Stichworte", "SELECT COUNT(*) FROM HB_STICHWORT x JOIN HB_REGIEBUCH r ON r.ID = x.REGIEBUCH_ID WHERE r.HERKUNFT = 'MITGELIEFERT'");
        ZAEHLEN.put("Ansichten", "SELECT COUNT(*) FROM HB_ANSICHT" + m + " AND ART = 'FEST'");
        ZAEHLEN.put("Fahrten", "SELECT COUNT(*) FROM HB_FAHRT" + m);
        ZAEHLEN.put("Stützpunkte", "SELECT COUNT(*) FROM HB_STUETZPUNKT x JOIN HB_FAHRT f ON f.ID = x.FAHRT_ID WHERE f.HERKUNFT = 'MITGELIEFERT'");
        ZAEHLEN.put("Presets", "SELECT COUNT(*) FROM HB_PAKET_PRESET" + m);
        ZAEHLEN.put("Presetwerte", "SELECT COUNT(*) FROM HB_PAKET_WERT x JOIN HB_PAKET_PRESET p ON p.ID = x.PAKET_PRESET_ID WHERE p.HERKUNFT = 'MITGELIEFERT'");
    }

    /** Der Einrichter für das Schema HAITHABU. */
    public static Einrichter einrichter() {
        Einrichter e = new Einrichter();
        e.praefix = PRAEFIX;
        e.version = VERSION;
        e.sichten = SICHTEN.clone();
        e.metadaten = METADATEN.clone();
        e.raeumlich = raeumlich();
        e.startdaten = () -> {
            List<Einrichter.Soll> l = new ArrayList<>();
            Map<String, Integer> z = zahlen(skripte());
            for (Map.Entry<String, String> q : ZAEHLEN.entrySet()) if (z.containsKey(q.getKey())) l.add(new Einrichter.Soll(q.getKey(), q.getValue(), z.get(q.getKey())));
            return l;
        };
        e.rechnet = () -> List.of(
                new Einrichter.Soll("Fläche im Halbkreiswall (ha, Literatur 26)", "SELECT TO_CHAR(MAX(FLAECHE_HA), 'FM990.0') FROM HB_BAUWERK_V WHERE ART = 'WALLFLAECHE'", -1),
                new Einrichter.Soll("Hafenbecken (ha, Szene 10,0)", "SELECT TO_CHAR(MAX(FLAECHE_HA), 'FM990.0') FROM HB_BAUWERK_V WHERE ART = 'HAFENBECKEN'", -1),
                new Einrichter.Soll("Kammlinie des Walls (m, Szene 1 402)", "SELECT TO_CHAR(MAX(LAENGE_M), 'FM99990') FROM HB_BAUWERK_V WHERE ART = 'WALLKAMM'", -1),
                new Einrichter.Soll("Häuser der Uferzeile bis 60 m", "SELECT TO_CHAR(COUNT(*)) FROM HB_UFERZEILE_V", -1),
                new Einrichter.Soll("Häuser in der Wallfläche", "SELECT TO_CHAR(COUNT(*)) FROM HB_IM_WALL_V", -1));
        return e;
    }
}
