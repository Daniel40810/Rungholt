package com.dan.haithabu.data;

import com.dan.haithabu.camera.Camera;
import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.scene.Flotte;
import com.dan.haithabu.scene.Regie;
import com.dan.longship.Longship;
import com.dan.store.Felder;
import com.dan.store.Zahl;
import com.dan.weather.Scenario;
import com.dan.weather.Weather;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Der ganze Zustand der Szene als Text (F33 A): alle öffentlichen Felder aller Packages, dazu Uhr, Kamera, Wetterregie
 * mit Handreglern, das laufende Regiebuch mit Stelle, die aktive Siedlung, der Brand je Haus, die Schiffe mit Ort und
 * das Jahr. Dasselbe Format dient für „Weiter wie zuletzt“, für gemerkte Ansichten und für die Dateien ohne Datenbank.
 * Die Tiere werden neu gewürfelt; Befehle, die ein Schiff gerade abarbeitet, gehen nicht mit (es bleibt, wo es ist).
 * <p>
 * Schlüssel der Form {@code teil.feld}: {@code ocean.windSpeed}, {@code kamera.x}, {@code regie.hand.WIND},
 * {@code brand.zustand}. Die Szenenzeit steht als {@code uhr.datum} (ISO, gregorianisch zurückgerechnet) und
 * {@code uhr.stunde}, nie als Millisekunden seit 1970 (F32).
 */
public final class Zustand {
    private Zustand() { }

    static final Set<String> OHNE = Set.of("quality");
    /** Anfragen, Tastenzustände, abgeleitete Größen. */
    static final Set<String> OHNE_RENDERER = Set.of("photoRequest", "frozen", "quality");
    static final Set<String> OHNE_WIRING = Set.of("cloudsDrawn", "fogBase", "fogTop", "precipRate", "snowRate", "gustNow", "quality");
    static final Set<String> OHNE_SKY = Set.of("epochMillis", "latDeg", "lonDeg", "quality");

    /** Die Teile mit öffentlichen Feldern: Name im Zustand → Objekt. */
    static Map<String, Object> teile(Renderer r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("renderer", r);
        if (r.wiring != null) {
            m.put("wiring", r.wiring);
            m.put("wind", r.wiring.wind);
            m.put("pegel", r.wiring.waterLevel);
            m.put("jahr", r.wiring.year);
        }
        m.put("ocean", r.ocean);
        m.put("reed", r.reed);
        m.put("sky", r.sky);
        m.put("clouds", r.clouds);
        m.put("rain", r.rain);
        m.put("fog", r.fog);
        m.put("lightning", r.lightning);
        m.put("weathering", r.weathering);
        m.put("smoke", r.smoke);
        m.put("timber", r.timber);
        m.put("klang", r.sound);
        if (r.feuer != null) m.put("feuer", r.feuer);
        if (r.flotte != null) m.put("flotte", r.flotte);
        if (r.leben != null) {
            m.put("voegel", r.leben.flock);
            m.put("tiere", r.leben.herd);
        }
        return m;
    }

    /** Das laufende Objekt einer Klasse mit Presets (Startdaten.PAKETE, einfacher Name) in der Szene, oder null. */
    public static Object objekt(Renderer r, String klasse) {
        for (Object o : teile(r).values()) if (o != null && o.getClass().getSimpleName().equals(klasse)) return o;
        if (r.flotte != null && "Spray".equals(klasse)) return r.flotte.spray;
        return null;
    }

    private static Set<String> ohne(String teil) {
        return switch (teil) {
            case "renderer" -> OHNE_RENDERER;
            case "wiring" -> OHNE_WIRING;
            case "sky" -> OHNE_SKY;
            default -> OHNE;
        };
    }

    /** „0950-10-16 17.5“ → Szenenzeit. */
    public static Daten.Szenenzeit szenenzeit(String s) {
        String[] p = s.strip().split(" ");
        LocalDate d = LocalDate.parse(p[0]);
        return Daten.Szenenzeit.of(d, p.length > 1 ? Zahl.lies(p[1]) : 0);
    }

    public static String text(Daten.Szenenzeit z) { return z.datum() + " " + Zahl.text(Math.round(z.stunde() * 1e5) / 1e5); }

    /** Erfasst den Zustand (aus dem Swing-Faden oder dem Faden der Daten; die Felder sind volatile). */
    public static LinkedHashMap<String, String> erfassen(Renderer r, boolean tonAn, String siedlung) {
        LinkedHashMap<String, String> z = new LinkedHashMap<>();
        z.put("app.version", Renderer.VERSION);
        z.put("app.qualitaet", r.quality().name());
        z.put("app.ton", Boolean.toString(tonAn));
        z.put("uhr.datum", r.clock.date().toString());
        z.put("uhr.stunde", Zahl.text(Math.round(r.clock.hour() * 1e6) / 1e6));
        z.put("uhr.lapse", Zahl.text(r.clock.lapse));
        Camera c = r.camera;
        z.put("kamera.modus", c.mode == Camera.Mode.KREISEN ? "KREISEN" : "FREI");
        z.put("kamera.kreisen", Boolean.toString(c.autoOrbit));
        double[] k = kamera(r);
        String[] n = {"x", "y", "z", "gier", "nick", "fov"};
        for (int i = 0; i < 6; i++) z.put("kamera." + n[i], Zahl.text(Math.round(k[i] * 1000) / 1000.0));
        z.put("kamera.ziel", Zahl.text(c.tx) + " " + Zahl.text(c.ty) + " " + Zahl.text(c.tz) + " " + Zahl.text(c.yaw) + " " + Zahl.text(c.pitch) + " " + Zahl.text(c.dist));
        if (siedlung != null) z.put("siedlung.name", siedlung);
        if (r.siedlung != null) z.put("siedlung.startwert", Long.toString(r.siedlung.seed));
        if (r.wiring != null) {
            Weather w = r.wiring.weather;
            Weather.Snapshot ws = w.snapshot();
            z.put("regie.an", Boolean.toString(r.wiring.regie));
            z.put("regie.lage", ws != null ? ws.phase().name() : "KLAR");
            Scenario sc = w.scenario();
            if (sc != null && ws != null && ws.step() >= 0) {
                z.put("regie.text", sc.toText());
                z.put("regie.beginn", Zahl.text(w.scenarioStart()));
            }
            double[] h = w.handValues();
            for (int i = 0; i < h.length; i++) if (!Double.isNaN(h[i])) z.put("regie.hand." + Weather.Var.values()[i].name(), Zahl.text(h[i]));
        }
        Regie.Book bk = r.regie.book();
        if (bk != null) {
            z.put("regiebuch.name", bk.name());
            z.put("regiebuch.text", bk.text());
            z.put("regiebuch.sekunde", Zahl.text(Math.round(r.regie.time() * 100) / 100.0));
        }
        var fe = r.feuer;
        if (fe != null && fe.brand != null) z.put("brand.zustand", fe.brand.state());
        Flotte fl = r.flotte;
        if (fl != null) {
            List<Longship> alle = new ArrayList<>(fl.ships);
            alle.add(fl.brander);
            for (Longship s : alle)
                z.put("schiff." + s.name, Zahl.text(Math.round(s.x * 100) / 100.0) + " " + Zahl.text(Math.round(s.z * 100) / 100.0) + " " + Zahl.text(Math.round(s.heading * 100) / 100.0));
        }
        for (Map.Entry<String, Object> e : teile(r).entrySet())
            for (Map.Entry<String, String> f : Felder.lesen(e.getValue(), ohne(e.getKey())).entrySet()) z.put(e.getKey() + "." + f.getKey(), f.getValue());
        return z;
    }

    /** Kamera für Ansichten: {x, y, z, Gier, Nick, Bildwinkel} aus dem laufenden Bild. */
    public static double[] kamera(Renderer r) {
        Camera c = r.camera;
        double[] e = c.eye, f = c.fwd;
        double nick = Math.toDegrees(-Math.asin(Math.max(-1, Math.min(1, f[1]))));
        return new double[]{e[0], e[1], e[2], c.heading(), nick, Camera.FOVY};
    }

    /** Szenenzeit des Zustands oder null. */
    public static Daten.Szenenzeit szenenzeit(Map<String, String> z) {
        String d = z.get("uhr.datum");
        if (d == null) return null;
        return Daten.Szenenzeit.of(LocalDate.parse(d), Zahl.lies(z.get("uhr.stunde")));
    }

    public static Quality qualitaet(Map<String, String> z) {
        try { return Quality.valueOf(z.get("app.qualitaet")); } catch (RuntimeException e) { return null; }
    }

    /**
     * Stellt den Zustand her (aus dem Swing-Faden). Qualität, Ton und Siedlung stellt der Aufrufer ein (sie brauchen
     * die Oberfläche oder einen Neubau); hier alles andere. Gibt zurück, was nicht ging.
     */
    public static List<String> anwenden(Renderer r, Map<String, String> z) {
        List<String> fehler = new ArrayList<>();
        for (Map.Entry<String, Object> e : teile(r).entrySet()) {
            Map<String, String> t = Felder.teil(z, e.getKey());
            t.keySet().removeIf(x -> x.contains("."));
            for (String f : Felder.schreiben(e.getValue(), t, ohne(e.getKey()))) fehler.add(e.getKey() + "." + f);
        }
        String d = z.get("uhr.datum");
        double h = Zahl.lies(z.get("uhr.stunde"));
        if (d != null && !Double.isNaN(h)) {
            try { r.clock.set(LocalDate.parse(d), h); } catch (RuntimeException ex) { fehler.add("uhr.datum: " + ex.getMessage()); }
        }
        double lapse = Zahl.lies(z.get("uhr.lapse"));
        if (!Double.isNaN(lapse)) r.clock.lapse = lapse;
        Camera c = r.camera;
        c.stopFahrt();
        c.stopMitfahrt();
        String[] ziel = z.getOrDefault("kamera.ziel", "").split(" ");
        if ("KREISEN".equals(z.get("kamera.modus")) && ziel.length == 6) {
            c.mode = Camera.Mode.KREISEN;
            c.lookAt(Zahl.lies(ziel[0]), Zahl.lies(ziel[1]), Zahl.lies(ziel[2]), Zahl.lies(ziel[3]), Zahl.lies(ziel[4]), Zahl.lies(ziel[5]));
            c.autoOrbit = "true".equals(z.get("kamera.kreisen"));
            c.snap();
        } else {
            double x = Zahl.lies(z.get("kamera.x")), y = Zahl.lies(z.get("kamera.y")), zz = Zahl.lies(z.get("kamera.z"));
            if (!Double.isNaN(x) && !Double.isNaN(y) && !Double.isNaN(zz)) {
                c.mode = Camera.Mode.FREI;
                c.place(x, y, zz, Zahl.lies(z.get("kamera.gier")), Zahl.lies(z.get("kamera.nick")));
                c.snap();
            }
        }
        // Wetterregie
        if (r.wiring != null) {
            Weather w = r.wiring.weather;
            double now = r.clock.epochMillis() / 1000.0;
            String text = z.get("regie.text");
            boolean gestartet = false;
            if (text != null) {
                try {
                    Scenario sc = Scenario.parse(text);
                    double b = Zahl.lies(z.get("regie.beginn"));
                    w.start(sc, Double.isNaN(b) ? now : b);
                    gestartet = true;
                } catch (RuntimeException ex) {
                    fehler.add("regie.text: " + ex.getMessage());
                }
            }
            if (!gestartet) {
                Weather.Phase p;
                try { p = Weather.Phase.valueOf(z.getOrDefault("regie.lage", "KLAR")); } catch (IllegalArgumentException ex) { p = Weather.Phase.KLAR; }
                w.startFree(now, p);
            }
            r.wiring.resumeRegie();
            for (Weather.Var v : Weather.Var.values()) {
                double hv = Zahl.lies(z.get("regie.hand." + v.name()));
                if (!Double.isNaN(hv)) r.wiring.hand(v, hv);
            }
            r.wiring.regie = !"false".equals(z.get("regie.an"));
        }
        // Schiffe an ihren Ort (laufende Befehle gehen nicht mit)
        Flotte fl = r.flotte;
        if (fl != null) {
            List<Longship> alle = new ArrayList<>(fl.ships);
            alle.add(fl.brander);
            for (Longship s : alle) {
                String v = z.get("schiff." + s.name);
                if (v == null) continue;
                String[] p = v.split(" ");
                s.commands.clear();
                s.x = Zahl.lies(p[0]);
                s.z = Zahl.lies(p[1]);
                s.heading = Zahl.lies(p[2]);
                s.speed = 0;
                s.mode = Longship.Mode.FEST;
            }
        }
        // Brand
        String bz = z.get("brand.zustand");
        if (bz != null) {
            try { r.brandHerstellen(bz); } catch (RuntimeException ex) { fehler.add("brand.zustand: " + ex.getMessage()); }
        } else r.clearBrand();
        // Regiebuch an seiner Stelle
        String rb = z.get("regiebuch.text");
        if (rb != null) {
            try {
                Regie.Book b = Regie.parse(rb);
                double sek = Zahl.lies(z.get("regiebuch.sekunde"));
                r.regieFortsetzen(b, Double.isNaN(sek) ? 0 : sek);
            } catch (RuntimeException ex) {
                fehler.add("regiebuch.text: " + ex.getMessage());
            }
        } else r.startRegie(null);
        return fehler;
    }
}
