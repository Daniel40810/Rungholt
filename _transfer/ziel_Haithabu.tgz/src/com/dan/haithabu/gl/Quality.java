package com.dan.haithabu.gl;

import com.dan.cloud.Clouds;
import com.dan.fog.Fog;
import com.dan.forest.ForestField;
import com.dan.timber.Timber;
import com.dan.lightning.Lightning;
import com.dan.ocean.Ocean;
import com.dan.rain.Rain;
import com.dan.reed.Reed;
import com.dan.smoke.Smoke;
import com.dan.spray.Spray;
import com.dan.flock.Flock;
import com.dan.soundscape.Soundscape;
import com.dan.weathering.Weathering;

import java.util.Locale;

/**
 * Qualitätsstufen der App (aus Lighthouse). Phase 1: Anteil der Bildgröße, in dem gerechnet wird. Phase 2: Sichtweite
 * des Geländes (Knotengrößen je Stufe), FFT des Noors ({@code com.dan.ocean}) und Reichweite und Dichte der Halme
 * ({@code com.dan.reed}). Phase 3: Wolken, Regen, Nebel und Blitz (Stufen wie in Lighthouse). Phase 2b: Wald und Sonnenschatten. Jede weitere Package-Phase hängt die Stufe ihres Packages an. Die Packages haben ihre eigene
 * Kopie dieser Aufzählung (Paketvertrag Punkt 7).
 * Ziel (F16 A): „Mittel“ hält 60 Bilder/s in Full HD auf der Radeon 680M, „Hoch“ mindestens 30.
 */
public enum Quality {
    NIEDRIG("Niedrig", 0.67, 1.8, Ocean.Quality.LOW, Reed.Quality.LOW, Clouds.Quality.FLAT, Rain.Quality.LOW, Fog.Quality.LOW, Lightning.Quality.LOW, ForestField.Quality.LOW, 1024, 150, Timber.Quality.LOW,
            Smoke.Quality.LOW, 20, Spray.Quality.LOW, Flock.Quality.MEDIUM, 16, Soundscape.Quality.LOW, Weathering.Quality.LOW),
    MITTEL("Mittel", 0.85, 2.3, Ocean.Quality.MEDIUM, Reed.Quality.MEDIUM, Clouds.Quality.MEDIUM, Rain.Quality.MEDIUM, Fog.Quality.MEDIUM, Lightning.Quality.MEDIUM, ForestField.Quality.MEDIUM, 2048, 220, Timber.Quality.MEDIUM,
            Smoke.Quality.MEDIUM, 36, Spray.Quality.LOW, Flock.Quality.HIGH, 24, Soundscape.Quality.MEDIUM, Weathering.Quality.MEDIUM),
    HOCH("Hoch", 1.0, 2.8, Ocean.Quality.HIGH, Reed.Quality.HIGH, Clouds.Quality.HIGH, Rain.Quality.HIGH, Fog.Quality.HIGH, Lightning.Quality.HIGH, ForestField.Quality.HIGH, 2048, 300, Timber.Quality.HIGH,
            Smoke.Quality.HIGH, 48, Spray.Quality.MEDIUM, Flock.Quality.HIGH, 30, Soundscape.Quality.HIGH, Weathering.Quality.HIGH),
    ULTRA("Ultra", 1.0, 3.4, Ocean.Quality.ULTRA, Reed.Quality.ULTRA, Clouds.Quality.ULTRA, Rain.Quality.ULTRA, Fog.Quality.ULTRA, Lightning.Quality.ULTRA, ForestField.Quality.ULTRA, 4096, 420, Timber.Quality.ULTRA,
            Smoke.Quality.ULTRA, 56, Spray.Quality.HIGH, Flock.Quality.ULTRA, 36, Soundscape.Quality.ULTRA, Weathering.Quality.ULTRA);

    public final String label;
    /** Anteil der Bildgröße, in dem gerechnet wird. */
    public final double renderScale;
    /** Phase 2: Sichtweite jeder Geländestufe in ihren Knotengrößen (CDLOD). */
    public final double terrainRange;
    /** Phase 2: Stufe des Noors und der Halme. */
    public final Ocean.Quality ocean;
    public final Reed.Quality reed;
    /** Phase 3: Wolken, Regen, Nebel, Blitz. */
    public final Clouds.Quality clouds;
    public final Rain.Quality rain;
    public final Fog.Quality fog;
    public final Lightning.Quality lightning;
    /** Phase 2b: Wald (Reichweite, Stufen, Abstand) und die Sonnenschattenkarte (Texel, halbe Kante in m). */
    public final ForestField.Quality forest;
    public final int shadowSize;
    public final double shadowHalf;
    /** Phase 5: Stufen der Häuser (nah, mittel, fern). */
    public final Timber.Quality timber;
    /**
     * Phase 17 (durchgängig): Rauchfahnen (nah, fern, Bälle), Schritte des Rauchs im Versammlungshaus, Spritzer der
     * Riemen, Möwen je Schwarm, der Halbmesser der Bodendecke um das Auge (m), Klang (Abtastrate, Stimmen, Hall) und
     * die Nässekarte. „Mittel“ bleibt, wie es bis Phase 16 war.
     */
    public final Smoke.Quality smoke;
    public final int roomSteps;
    public final Spray.Quality spray;
    public final Flock.Quality flock;
    public final double groundRadius;
    public final Soundscape.Quality sound;
    public final Weathering.Quality weathering;

    Quality(String label, double renderScale, double terrainRange, Ocean.Quality ocean, Reed.Quality reed, Clouds.Quality clouds, Rain.Quality rain,
            Fog.Quality fog, Lightning.Quality lightning, ForestField.Quality forest, int shadowSize, double shadowHalf, Timber.Quality timber,
            Smoke.Quality smoke, int roomSteps, Spray.Quality spray, Flock.Quality flock, double groundRadius,
            Soundscape.Quality sound, Weathering.Quality weathering) {
        this.sound = sound;
        this.weathering = weathering;
        this.timber = timber;
        this.smoke = smoke;
        this.roomSteps = roomSteps;
        this.spray = spray;
        this.flock = flock;
        this.groundRadius = groundRadius;
        this.forest = forest;
        this.shadowSize = shadowSize;
        this.shadowHalf = shadowHalf;
        this.clouds = clouds;
        this.rain = rain;
        this.fog = fog;
        this.lightning = lightning;
        this.label = label;
        this.renderScale = renderScale;
        this.terrainRange = terrainRange;
        this.ocean = ocean;
        this.reed = reed;
    }

    /** Bildzeit, die die Stufe bei 60 Bildern/s höchstens verbrauchen darf (ms); „Hoch“ das Doppelte, „Niedrig“ die Hälfte. */
    public double budgetMs() {
        return switch (this) { case NIEDRIG -> 8.0; case MITTEL -> 15.9; case HOCH -> 31.8; case ULTRA -> 50.0; };
    }

    /** Was die Stufe einstellt, als eine Zeile (Bedienfeld, README). */
    public String summary() {
        return String.format(Locale.GERMAN, "%s: %d %% der Auflösung, Budget %.1f ms, Gelände %.1f Knoten, Noor %d × %d², Halme %.0f %% Reichweite, Wolken %s, Regen %,d Tropfen, Nebel %d Schritte, Blitz bis %,d Stücke, Wald bis %,.0f m, Sonnenschatten %d² über %.0f m, Rauch %d Fahnen nah, im Haus %d Schritte, Spritzer bis %d, Möwen %d, Bodendecke %.0f m, Klang %.1f kHz, Nässekarte %d × %d",
                label, Math.round(renderScale * 100), budgetMs(), terrainRange, ocean.cascades, ocean.n, reed.range * 100,
                clouds == Clouds.Quality.FLAT ? "2.5D" : "1/" + clouds.divisor, rain.drops, fog.steps, lightning.maxSegments, forest.radius, shadowSize, shadowHalf * 2,
                smoke.near, roomSteps, spray.maxParcels, flock.birds, groundRadius, sound.sampleRate / 1000.0, weathering.mapW, weathering.mapH);
    }

    @Override public String toString() { return label; }
}
