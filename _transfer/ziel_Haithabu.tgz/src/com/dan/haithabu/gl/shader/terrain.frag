// terrain.frag — die Oberfläche des Geländes (Phase 2). Boden nach Lage: Gras auf dem Land (Mitte Oktober schon
// gelblich), offener Boden an steilen Flanken (Wall, Hochburg, Böschungen), nasser Sand und Schlick am Ufer von 950,
// Schlamm am Grund des Noors (durch das Wasser zu sehen), das Bachbett; dazu der Schilfgürtel als Farbe mit Wellen im
// Wind für die Ferne (die Halme selbst zeichnet com.dan.reed in der Nähe). Feine Normale aus der Höhentextur in der
// Nähe, Mulden dunkler (Krümmung). Licht: Sonne, Mond und Himmel aus common.glsl (ab Phase 3 com.dan.sky, vorbelichtet),
// Wolkenschatten aus der Karte von com.dan.cloud, Blitzlicht, Nässe nach Regen, Dunst nach Entfernung.
// Mit uMarks: Raster 100 m, Marke am Bachmund, modellierte Flächen schraffiert [G].
#include "common.glsl"
#include "terrain_height.glsl"
in vec3 vWorld;
in vec3 vNormal;
in float vDist;
out vec4 frag;
uniform int uMarks;
uniform vec2 uWindTo;
uniform float uWindSpeed;
uniform sampler2D uReedMap;    // Schilf (r) und Binsen (g) je 2-m-Zelle aus scene.Vegetation, wie die Halme
uniform sampler2D uBrook;      // Bach (com.dan.river): vx, vz, Tiefe, Schaum je 1-m-Zelle
uniform vec4 uBrookRect;       // Nordwestecke x, z und Größe in m (z = 0: kein Bach)
uniform vec2 uReed;            // ab dieser Entfernung (m) zeigt das Gelände den Schilf als Farbe, davor die Halme; an (1) / aus (0)
uniform sampler2D uCloudShadow; // Phase 3: Schattenkarte der Wolken (r = Durchlässigkeit für die Sonne)
uniform vec4 uCloudRect;       // Ecke x, z, Kantenlänge (m), an (1) / aus (0)
uniform vec3 uFlashDir, uFlashRgb; // Phase 3: das stärkste Blitzlicht als Richtung und Bestrahlung (vorbelichtet)
uniform int uFireN;            // Phase 10: Feuer und Fackeln als Punktlichter (bis 8)
uniform vec4 uFirePos[8];      // Ort, Größe der Quelle (m)
uniform vec4 uFireRgb[8];      // Lichtstärke RGB (vorbelichtet, E = I / d²)
uniform float uWet;            // Phase 3: Nässe nach Regen 0..1
uniform vec3 uWood;            // Phase 2b: Wald (b, a der Schilfkarte): ab x (m) Kronendach statt Waldboden, Reichweite der Bäume y, an z
uniform sampler2DShadow uSunShadow; // Phase 2b: Sonnenschatten der Bäume (Tiefe −1..1 → 0..1)
uniform mat4 uSunShadowM;
uniform int uSunShadowOn;
uniform sampler2D uYard;       // Phase 5: zertretener Hofboden (r) und Lehmboden in den Häusern (g) um die Höfe am Bach
uniform vec4 uYardRect;        // Ecke x, z, Kantenlänge (m), an
uniform vec4 uWall;            // Phase 6: Mitte x, z des Halbkreiswalls, Ende des Feldgürtels (m hinter dem Kamm), an
uniform vec4 uWallR[45];       // Phase 6: Halbmesser des Wallkamms je 2° (atan2(z, x) um die Mitte); seit Phase 7 aus der gemessenen Kammlinie
uniform vec4 uNoField;         // Phase 7: keine Felder im Umkreis z (m) um x, y (die Hochburg mit den Grabhügeln)
uniform vec4 uHole;            // Phase 11: Versammlungshaus x, z, Richtung (rad), an: dort liegt der Lehmboden des Hauses
uniform vec2 uHoleSize;        // halbe Länge und Breite innen (m)
// Phase 12 (com.dan.season): das Jahr
uniform vec4 uSeason;          // Gras 0 Winter … 1 Mai (Mitte Oktober 0,5), Tag im Jahr (1..365), Laub in der Ferne 0..1, Herbstfärbung 0..1
uniform vec4 uSnow;            // Schneehöhe (m), Nässe des Schnees 0..1, Reif 0..1, Schilf 0 Sommer … 0,75 Herbst … 1 Winter
uniform vec4 uYear2;           // Schnee in den Kronen 0..1, frei

float wallRadius(float deg) {
    float f = deg / 2.0 - 0.5;
    int i = int(floor(f));
    float t = f - float(i);
    int a = (i + 180) % 180, b = (i + 181) % 180;
    return mix(uWallR[a / 4][a % 4], uWallR[b / 4][b % 4], t);
}

float sunShadowAt(vec3 p, vec3 n) {
    if (uSunShadowOn == 0) return 1.0;
    vec4 q = uSunShadowM * vec4(p + n * 0.3, 1.0);
    vec3 s = q.xyz / q.w * 0.5 + 0.5;
    if (any(lessThan(s.xy, vec2(0.002))) || any(greaterThan(s.xy, vec2(0.998))) || s.z > 1.0) return 1.0;
    vec2 tx = 1.0 / vec2(textureSize(uSunShadow, 0));
    float sum = 0.0;
    for (int j = -1; j <= 1; j++)
        for (int i = -1; i <= 1; i++) sum += texture(uSunShadow, vec3(s.xy + vec2(i, j) * tx * 1.5, s.z - 0.0008));
    // zum Rand der Karte hin auslaufen lassen
    float edge = smoothstep(0.0, 0.08, min(min(s.x, s.y), min(1.0 - s.x, 1.0 - s.y)));
    return mix(1.0, sum / 9.0, edge);
}

float hash21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i), b = hash21(i + vec2(1.0, 0.0)), c = hash21(i + vec2(0.0, 1.0)), d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(vec2 p) { return 0.5 * vnoise(p) + 0.3 * vnoise(p * 2.07 + 5.3) + 0.2 * vnoise(p * 4.13 - 2.1); }

// Phase 12: ein Feldstreifen im Jahr. k = 0: Sommergerste (im Herbst gepflügt), 1: Hafer (im Frühjahr gepflügt),
// 2: Winterroggen (im Oktober gesät). soil: wie viel nackter Boden zu sehen ist (Furchen).
vec3 cropAt(int k, float day, float g2, float g3, out float soil) {
    vec3 P = mix(vec3(0.085, 0.062, 0.040), vec3(0.115, 0.085, 0.055), g3);       // gepflügt
    vec3 H = P * 1.22;                                                           // geeggt, abgetrocknet
    vec3 G = mix(vec3(0.050, 0.092, 0.026), vec3(0.064, 0.108, 0.030), g2);      // grüne Halme
    vec3 Y = mix(vec3(0.150, 0.148, 0.062), vec3(0.170, 0.160, 0.070), g2);      // gelbgrün, reifend
    vec3 O = mix(vec3(0.255, 0.200, 0.100), vec3(0.225, 0.178, 0.090), g2);      // reif, golden
    vec3 T = mix(vec3(0.19, 0.155, 0.085), vec3(0.15, 0.125, 0.07), g2);         // Stoppeln
    vec3 W = T * vec3(0.72, 0.76, 0.84);                                         // Stoppeln im Winter, ausgeblichen
    vec3 N = mix(vec3(0.075, 0.075, 0.042), vec3(0.06, 0.09, 0.035), g2);        // frische Saat
    vec3 c;
    if (k == 0) {
        c = P;
        c = mix(c, H, smoothstep(85.0, 100.0, day));
        c = mix(c, mix(H, G, 0.35), smoothstep(115.0, 135.0, day));
        c = mix(c, G, smoothstep(135.0, 160.0, day));
        c = mix(c, Y, smoothstep(185.0, 205.0, day));
        c = mix(c, O, smoothstep(205.0, 220.0, day));
        c = mix(c, T, smoothstep(222.0, 228.0, day));
        c = mix(c, P, smoothstep(268.0, 280.0, day));
        soil = 1.0 - smoothstep(115.0, 150.0, day) + smoothstep(268.0, 280.0, day);
    } else if (k == 1) {
        c = W;
        c = mix(c, P, smoothstep(95.0, 105.0, day));
        c = mix(c, mix(P, G, 0.35), smoothstep(125.0, 140.0, day));
        c = mix(c, G, smoothstep(140.0, 165.0, day));
        c = mix(c, Y, smoothstep(190.0, 210.0, day));
        c = mix(c, O, smoothstep(210.0, 225.0, day));
        c = mix(c, T, smoothstep(228.0, 234.0, day));
        c = mix(c, W, smoothstep(320.0, 365.0, day));
        soil = smoothstep(95.0, 105.0, day) * (1.0 - smoothstep(125.0, 155.0, day)) + 0.6 * smoothstep(228.0, 234.0, day);
    } else {
        vec3 start = mix(N, G * 0.8, 0.5);
        c = start;
        c = mix(c, G, smoothstep(85.0, 130.0, day));
        c = mix(c, mix(G, Y, 0.4), smoothstep(150.0, 170.0, day));
        c = mix(c, Y, smoothstep(175.0, 190.0, day));
        c = mix(c, O, smoothstep(190.0, 205.0, day));
        c = mix(c, T, smoothstep(210.0, 216.0, day));
        c = mix(c, P, smoothstep(255.0, 262.0, day));
        c = mix(c, N, smoothstep(270.0, 280.0, day));
        c = mix(c, start, smoothstep(300.0, 365.0, day));
        soil = 0.6 - 0.6 * smoothstep(85.0, 130.0, day) + smoothstep(255.0, 262.0, day) * 0.4 + 0.6 * smoothstep(210.0, 216.0, day) * (1.0 - smoothstep(255.0, 262.0, day));
    }
    soil = clamp(soil, 0.0, 1.0);
    return c;
}

float lineAA(float d, float w, float px) { return 1.0 - smoothstep(w, w + px * 1.5, d); }

void main() {
    vec2 w = vWorld.xz;
    float y = vWorld.y;
    if (uHole.w > 0.5) {
        vec2 d = w - uHole.xy;
        float sh = sin(uHole.z), ch = cos(uHole.z);
        if (abs(d.x * sh - d.y * ch) < uHoleSize.x && abs(d.x * ch + d.y * sh) < uHoleSize.y) discard;
    }
    // feine Normale in der Nähe (DGM 1 m), in der Ferne die grobe aus dem Vertex-Shader
    vec3 n = normalize(vNormal);
    if (vDist < 600.0) {
        float e = 0.75, l = heightLevel(vDist) * 0.5;
        vec3 nf = normalize(vec3(heightAt(w - vec2(e, 0.0), l) - heightAt(w + vec2(e, 0.0), l), 2.0 * e,
                                 heightAt(w - vec2(0.0, e), l) - heightAt(w + vec2(0.0, e), l)));
        n = normalize(mix(nf, n, smoothstep(250.0, 600.0, vDist)));
    }
    float slope = 1.0 - n.y;
    uint src = sourceAt(w);
    // Krümmung aus einer groben Stufe: Mulden sammeln Feuchte und Schatten
    float c0 = heightAt(w, 3.0), cs = (heightAt(w + vec2(8.0, 0.0), 3.0) + heightAt(w - vec2(8.0, 0.0), 3.0)
            + heightAt(w + vec2(0.0, 8.0), 3.0) + heightAt(w - vec2(0.0, 8.0), 3.0)) * 0.25;
    float hollow = clamp((cs - c0) * 1.5, -1.0, 1.0);

    // Gras: Mitte Oktober grün mit gelben und braunen Flecken; in Mulden satter. Phase 12: nach dem Jahr (uSeason.x)
    // im Mai saftig grün mit wenig trockenen Stellen, im Winter matt olivbraun
    float g1 = fbm(w / 23.0), g2 = fbm(w / 4.1 + 11.0), g3 = vnoise(w * 1.7);
    float lush = uSeason.x;
    vec3 grassGreen = mix(vec3(0.050, 0.070, 0.030), vec3(0.064, 0.112, 0.024), lush), grassDry = vec3(0.125, 0.112, 0.050), grassDark = vec3(0.040, 0.062, 0.022);
    vec3 alb = mix(grassGreen, grassDry, clamp(smoothstep(0.40, 0.80, g1) * 0.75 * (1.6 - 1.2 * lush), 0.0, 1.0));
    alb = mix(alb, vec3(0.095, 0.085, 0.055), (1.0 - smoothstep(0.0, 0.35, lush)) * 0.45);
    alb = mix(alb, grassDark, clamp(hollow * 0.8 + 0.25 * (g2 - 0.5), 0.0, 0.7));
    // feine Struktur der Grasnarbe in der Nähe: Büschel, Halme, kahle Stellen
    float fine = fbm(w / 1.9) * 0.6 + vnoise(w * 2.9) * 0.4;
    alb *= mix(1.0, 0.7 + 0.6 * fine, 1.0 - smoothstep(30.0, 140.0, vDist));
    alb *= 0.88 + 0.24 * g3;
    // offener Boden an steilen Flanken und auf Kuppen
    vec3 soil = mix(vec3(0.12, 0.09, 0.06), vec3(0.17, 0.13, 0.08), g2);
    alb = mix(alb, soil, smoothstep(0.32, 0.6, slope + 0.15 * (g1 - 0.5)));
    // Ufer von 950: Schlick und nasser Sand zwischen −0,4 und +0,7 m, darunter der Grund des Noors
    vec3 mud = vec3(0.085, 0.075, 0.055), sand = vec3(0.20, 0.17, 0.12);
    float shore = 1.0 - smoothstep(0.15, 0.7 + 0.3 * g1, y);
    alb = mix(alb, mix(mud, sand, smoothstep(-0.2, 0.4, y) * (0.4 + 0.6 * g2)), shore);
    if (y < -0.4) alb = mix(vec3(0.10, 0.09, 0.065), vec3(0.14, 0.12, 0.085), g1);
    // Bachbett: nasser Kies und Schlamm
    if (src == 3u) alb = mix(vec3(0.07, 0.065, 0.05), vec3(0.13, 0.11, 0.08), g3);
    // Schilfgürtel als Farbe (Herbst: gold bis braun, wenig Grün), in der Ferne mit Wellen im Wind
    float reedMask = 0.0;
    if (uReed.y > 0.0) {
        vec2 rm = texture(uReedMap, gridUV(w)).rg;
        float far = smoothstep(uReed.x * 0.75, uReed.x * 1.05, vDist);
        reedMask = rm.r * far;
        float along = dot(w, uWindTo);
        float wave = 0.5 + 0.5 * sin(along * 0.35 - uTime * 0.7 * max(0.5, uWindSpeed) * 0.35 + 2.0 * sin(0.11 * (w.x - w.y)));
        // Phase 12: Schilf im Jahr (uSnow.w): grün im Sommer, gold im Herbst, strohgrau im Winter
        float rs = uSnow.w;
        vec3 reedS = mix(vec3(0.07, 0.11, 0.035), vec3(0.05, 0.08, 0.03), g2), reedA = mix(vec3(0.20, 0.155, 0.075), vec3(0.12, 0.10, 0.05), g2);
        vec3 reedW = mix(vec3(0.22, 0.19, 0.13), vec3(0.16, 0.14, 0.10), g2);
        vec3 reedC = rs < 0.75 ? mix(reedS, reedA, smoothstep(0.25, 0.75, rs)) : mix(reedA, reedW, smoothstep(0.75, 1.0, rs));
        vec3 reed = reedC * (0.8 + 0.4 * wave * smoothstep(1.0, 6.0, uWindSpeed));
        alb = mix(alb, reed, reedMask);
        alb = mix(alb, vec3(0.10, 0.11, 0.05) * (0.8 + 0.4 * g3), rm.g * 0.7);
    }

    // Phase 6: Felder vor dem Wall. Lange schmale Streifen quer zum Wall (Pflug mit dem Ochsen), je Streifen ein
    // anderer Stand Mitte Oktober: frisch gepflügt, Stoppeln von Gerste und Roggen, die grüne Wintersaat, Brache;
    // Raine aus Gras zwischen den Streifen, Furchen in der Nähe
    float fieldSoil = 0.0;
    if (uWall.w > 0.0 && y > 1.0) {
        vec2 q = w - uWall.xy;
        float d = length(q), deg = mod(degrees(atan(q.y, q.x)) + 360.0, 360.0);
        if (deg > 60.0 && deg < 268.0) {
            float r0 = wallRadius(deg);
            float zone = smoothstep(r0 + 30.0, r0 + 60.0, d) * (1.0 - smoothstep(r0 + uWall.z - 120.0, r0 + uWall.z, d + 80.0 * (g1 - 0.5)));
            zone *= 1.0 - smoothstep(0.12, 0.25, slope);
            zone *= smoothstep(uNoField.z, uNoField.z + 40.0, length(w - uNoField.xy));
            if (zone > 0.0) {
                float s = radians(deg) * 500.0 + 6.0 * sin(d / 70.0);      // Bogenmaß quer, in m auf 500 m
                float strip = floor(s / 13.0), block = floor((d - r0) / 110.0 + 0.3 * hash21(vec2(strip, 3.0)));
                float hcrop = hash21(vec2(strip, block));
                float u = fract(s / 13.0);
                // Phase 12: je Streifen eine Frucht durch das Jahr (Mitte Oktober wie bisher: gepflügt, Stoppeln, Saat, Brache)
                float soilF = 0.0;
                vec3 crop = hcrop < 0.85 ? cropAt(hcrop < 0.35 ? 0 : hcrop < 0.65 ? 1 : 2, uSeason.y, g2, g3, soilF) : alb;
                float near = 1.0 - smoothstep(40.0, 160.0, vDist);
                float furrow = 0.5 + 0.5 * sin(s * 6.2832 / 0.9);
                crop *= mix(1.0, 0.8 + 0.4 * furrow, near * (hcrop < 0.85 ? 1.0 : 0.0));
                fieldSoil = soilF * zone * (hcrop < 0.85 ? 1.0 : 0.0) * (0.5 + 0.5 * furrow);
                float balk = 1.0 - smoothstep(0.0, 0.06, min(u, 1.0 - u));      // Rain zwischen den Streifen
                crop = mix(crop, alb, balk * 0.8);
                alb = mix(alb, crop, zone);
            }
        }
    }

    // Phase 2b: Wald. Nah Waldboden (Laubstreu, im Erlenbruch nass und dunkel) unter den Bäumen; wo die Bäume zum
    // Rand ihrer Reichweite ausgedünnt werden und dahinter das Kronendach als Farbe (Herbst: grün, gelb, braun gefleckt)
    float canopy = 0.0, treeCov = 0.0, trod = 0.0;
    if (uWood.z > 0.0) {
        vec2 wa = texture(uReedMap, gridUV(w)).ba;
        float dens = clamp(wa.x + wa.y, 0.0, 1.0);
        vec3 litter = mix(vec3(0.085, 0.060, 0.034), vec3(0.120, 0.085, 0.045), g2) * (0.8 + 0.3 * g3);
        litter = mix(litter, vec3(0.045, 0.045, 0.030), wa.y / max(dens, 0.01) * 0.8);
        alb = mix(alb, litter, smoothstep(0.15, 0.6, dens) * (1.0 - shore));
        float far = smoothstep(uWood.x, mix(uWood.x, uWood.y, 0.7), vDist);
        float c1 = fbm(w / 37.0 + 3.0), c2 = vnoise(w / 9.0);
        // Phase 12: Laub und Färbung nach dem Jahr (uSeason.z, .w; Mitte Oktober wie bisher), im Winter kahle Kronen
        float fall = min(1.0, uSeason.w * 2.0);
        vec3 crown = mix(vec3(0.050, 0.075, 0.025), vec3(0.15, 0.11, 0.03), smoothstep(0.35, 0.75, c1) * fall);
        crown = mix(crown, vec3(0.13, 0.065, 0.025), smoothstep(0.55, 0.85, c2) * 0.6 * fall);
        crown = mix(crown, vec3(0.11, 0.075, 0.04), smoothstep(0.5, 1.0, uSeason.w) * 0.5);
        crown = mix(crown, vec3(0.035, 0.060, 0.025), wa.y / max(dens, 0.01) * (1.0 - smoothstep(0.6, 1.0, uSeason.w)));
        crown = mix(crown, vec3(0.075, 0.115, 0.032), (1.0 - fall) * (1.0 - smoothstep(0.6, 0.95, uSeason.z)) * smoothstep(0.05, 0.3, uSeason.z));
        vec3 bare = mix(vec3(0.072, 0.064, 0.055), vec3(0.058, 0.052, 0.048), c2);
        bare = mix(bare, vec3(0.20, 0.205, 0.215), uYear2.x * 0.6);
        crown = mix(bare, crown, max(uSeason.z, step(0.86, c2)));
        canopy = smoothstep(0.2, 0.65, dens) * far;
        treeCov = smoothstep(0.15, 0.6, dens);
        alb = mix(alb, crown * (0.75 + 0.35 * c2), canopy);
    }

    // Phase 5: Höfe am Bach. Zertretener, schlammiger Boden um die Häuser und an den Wegen, Lehm in den Häusern
    if (uYardRect.w > 0.0) {
        vec2 yu = (w - uYardRect.xy) / uYardRect.z;
        if (all(greaterThan(yu, vec2(0.0))) && all(lessThan(yu, vec2(1.0)))) {
            vec3 yd = texture(uYard, yu).rgb;
            // Phase 6: Gärten hinter den Häusern, Beete mit Kohl, Bohnen und Lauch in Reihen, dazwischen dunkle Erde
            if (yd.b > 0.0) {
                float row = 0.5 + 0.5 * sin((w.x + w.y) * 6.2832 / 0.7);
                vec3 bed = mix(vec3(0.07, 0.052, 0.035), vec3(0.055, 0.085, 0.03) * (0.8 + 0.4 * g3), smoothstep(0.55, 0.9, row) * step(0.3, g2));
                alb = mix(alb, bed, yd.b * 0.9);
            }
            vec3 trodden = mix(vec3(0.075, 0.060, 0.042), vec3(0.13, 0.10, 0.068), g2) * (0.85 + 0.3 * g3);
            alb = mix(alb, trodden, smoothstep(0.1, 0.8, yd.r) * (0.75 + 0.25 * fine));
            trod = max(smoothstep(0.1, 0.8, yd.r), yd.g);
            alb = mix(alb, vec3(0.09, 0.07, 0.05), yd.g);
        }
    }

    // Bach: Wasser im Bett, Muster treiben mit der Strömung (zwei Phasen, die sich überblenden, damit nichts reißt)
    vec4 bf = vec4(0.0);
    if (uBrookRect.z > 0.0) {
        vec2 bu = (w - uBrookRect.xy) / uBrookRect.zw;
        if (all(greaterThan(bu, vec2(0.0))) && all(lessThan(bu, vec2(1.0)))) bf = texture(uBrook, bu);
    }
    float brookWet = smoothstep(0.02, 0.06, bf.z);
    // Phase 12: Schnee (uSnow.x) — Wehen nach Rauschen und Mulden, an steilen Flanken dünn, unter dichtem Wald weniger,
    // im Bach und am nassen Ufer keiner; Furchen schauen aus dünnem Schnee; zertreten in den Höfen grau. Reif auf dem Rest.
    float snowCov = 0.0;
    if (uSnow.x > 0.0005) {
        float drift = fbm(w / 17.0 + 1.7) - 0.5;
        float local = uSnow.x * (1.0 + 0.7 * drift + 0.6 * hollow) * (1.0 - smoothstep(0.35, 0.75, slope));
        local *= 1.0 - 0.45 * treeCov * (1.0 - canopy);
        local *= (1.0 - brookWet) * smoothstep(-0.05, 0.3, y);
        local -= fieldSoil * 0.04;
        snowCov = smoothstep(0.002, 0.03, local + 0.006 * (fine - 0.5));
        vec3 snowAlb = vec3(0.255, 0.258, 0.27) * mix(1.0, 0.72, uSnow.y) * (0.95 + 0.07 * g3);
        snowAlb = mix(snowAlb, vec3(0.11, 0.10, 0.085), trod * 0.75);
        float keepReed = reedMask * 0.6;
        alb = mix(alb, snowAlb, snowCov * (1.0 - keepReed));
        n = normalize(mix(n, vec3(0.0, 1.0, 0.0), snowCov * 0.5));
    }
    if (uSnow.z > 0.0) alb = mix(alb, vec3(0.20, 0.205, 0.215), uSnow.z * 0.5 * (1.0 - snowCov) * smoothstep(0.1, 0.5, y) * (1.0 - canopy) * (1.0 - trod));
    // Licht: Sonne (im Wolkenschatten), Mond, Himmel, Blitz; Mulden etwas dunkler. Der echte Himmel (Phase 3) ist
    // im Mittel heller als sein Zenit, darum dort ein höheres Gewicht als beim Platzhalter.
    float shade = 1.0;
    if (uCloudRect.w > 0.0) shade = textureLod(uCloudShadow, (w - uCloudRect.xy) / uCloudRect.z, 0.0).r;
    float sunSh = sunShadowAt(vWorld, n);
    alb *= 1.0 - 0.35 * uWet * (1.0 - shore);
    vec3 sky = uSkyMode == 1 ? uSkyAmb : skyColor(vec3(0.0, 1.0, 0.0));
    float ao = clamp(0.85 - hollow * 0.25 + n.y * 0.15, 0.5, 1.05);
    float ambW = uSkyMode == 1 ? 0.55 + 0.45 * n.y : 0.30 + 0.25 * n.y;
    // Kronendach in der Ferne: ein rauer, halb im Eigenschatten liegender Körper, nicht der flache Boden
    vec3 nl = normalize(mix(n, vec3(0.0, 1.0, 0.0), canopy * 0.5));
    float self = mix(1.0, 0.55, canopy);
    vec3 col = alb * ((sunLight() * max(dot(nl, uSun), 0.0) * sunSh * self + moonLight() * max(dot(n, uMoonDir), 0.0)) * shade
                      + sky * ambW * ao + uFlashRgb * max(dot(n, uFlashDir), 0.0));
    for (int i = 0; i < 8; i++) {
        if (i >= uFireN) break;
        vec3 tl = uFirePos[i].xyz - vWorld;
        float d2 = dot(tl, tl) + uFirePos[i].w * uFirePos[i].w;
        col += alb * uFireRgb[i].rgb * max(dot(n, tl * inversesqrt(max(d2, 1e-4))), 0.0) / d2;
    }
    // nasse Flächen glänzen schwach zum Himmel
    float wet = max(shore * (1.0 - smoothstep(-0.1, 0.5, y)), uWet * 0.6);
    vec3 v = normalize(uCam - vWorld);
    float fres = 0.02 + 0.3 * pow(1.0 - max(dot(n, v), 0.0), 5.0);
    col = mix(col, skyColor(reflect(-v, n)), wet * fres);

    if (brookWet > 0.0) {
        vec2 vel = bf.xy;
        float ph0 = fract(uTime * 0.25), ph1 = fract(uTime * 0.25 + 0.5);
        float wgt = abs(ph0 - 0.5) * 2.0;
        vec2 q0 = w * 2.2 - vel * ph0 * 4.0, q1 = w * 2.2 - vel * ph1 * 4.0 + 0.37;
        float e = 0.08;
        vec2 g0 = vec2(vnoise(q0 + vec2(e, 0.0)) - vnoise(q0 - vec2(e, 0.0)), vnoise(q0 + vec2(0.0, e)) - vnoise(q0 - vec2(0.0, e))) / (2.0 * e);
        vec2 g1 = vec2(vnoise(q1 + vec2(e, 0.0)) - vnoise(q1 - vec2(e, 0.0)), vnoise(q1 + vec2(0.0, e)) - vnoise(q1 - vec2(0.0, e))) / (2.0 * e);
        vec2 g = mix(g0, g1, wgt) * (0.04 + 0.05 * length(vel)) + vec2(sin(dot(w, uWindTo) * 3.0 - uTime * 2.0)) * 0.01 * uWindSpeed / 8.0;
        vec3 nw = normalize(vec3(-g.x, 1.0, -g.y));
        vec3 vv = normalize(uCam - vWorld);
        float F = 0.02 + 0.98 * pow(1.0 - max(dot(nw, vv), 0.0), 5.0);
        vec3 refl = skyColor(reflect(-vv, nw) * vec3(1.0, 1.0, 1.0));
        float T = exp(-1.6 * bf.z * (1.0 + 1.0 / max(vv.y, 0.15)));
        vec3 under = col * T + vec3(0.02, 0.035, 0.03) * (sky * 0.4 + sunLight() * max(uSun.y, 0.0) * 0.3) * (1.0 - T);
        vec3 water = mix(under, refl, F);
        water += sunLight() * 4.0 * pow(max(dot(reflect(-vv, nw), uSun), 0.0), 300.0) * F;
        float foam = bf.w * smoothstep(0.5, 0.8, vnoise(q0 * 1.7) * (1.0 - wgt) + vnoise(q1 * 1.7) * wgt);
        water = mix(water, vec3(0.75) * (sky * 0.5 + sunLight() * max(uSun.y, 0.0) * 0.4) * 0.6, foam * 0.6);
        col = mix(col, water, brookWet);
    }

    if (uMarks == 1) {
        float px = vDist * 0.0012 / max(0.08, abs(normalize(vWorld - uCam).y));
        vec3 ink = sky * 0.9 + sunLight() * max(uSun.y, 0.0) * 0.4;
        vec2 g100 = abs(fract(w / 100.0 + 0.5) - 0.5) * 100.0;
        float grid = lineAA(min(g100.x, g100.y), 0.25, px) * 0.18 * (1.0 - smoothstep(1500.0, 3000.0, vDist));
        col = mix(col, ink * vec3(0.85, 0.75, 0.5), grid);
        if (src == 1u) {
            float hatch = step(0.5, fract((w.x + w.y) / 12.0));
            col = mix(col, col * vec3(1.15, 1.05, 0.85), 0.35 * hatch);
        }
        float r0 = abs(length(w) - 6.0);
        float north = length(w - vec2(0.0, clamp(w.y, -26.0, -6.0))) ;
        float mark = max(lineAA(r0, 0.6, px), lineAA(north, 0.6, px));
        col = mix(col, vec3(1.0, 0.42, 0.12) * (0.4 + 0.6 * sunLight().r) + vec3(0.08, 0.03, 0.01), mark);
    }

    col = aerial(col, normalize(vWorld - uCam), vDist);
    frag = vec4(col, 1.0);
}
