// terrain_height.glsl — Höhe des Geländes für Vertex- und Fragment-Shader (Phase 2, nach Kīlauea).
// Höhentextur R16 (normiert, 4096² zu 1 m, mit Mip-Stufen), Höhe = Wert · uHMap.x + uHMap.y, bilinear wie
// Terrain.height in Java, damit Kamera und Bild dieselbe Fläche sehen. In der Ferne aus gröberen Mip-Stufen (stetig
// nach der Entfernung, damit Nachbarknoten dieselbe Fläche sehen). Außerhalb des Rasters gilt sein Rand.
uniform sampler2D uHeight;
uniform usampler2D uSource;    // Herkunft je Zelle: 0 gemessen, 1 modelliert, 2 Noorbett, 3 Bach
uniform vec3 uGrid;            // X0, Z0 (Nordwestecke), Zellgröße
uniform float uGridN;          // Zellen je Seite
uniform vec2 uHMap;            // Spanne, kleinste Höhe
uniform vec3 uLodRange;        // Sichtweite der feinsten Stufe (m), Beginn des Gleitens (Anteil), Sichtweite in Knotengrößen

vec2 gridUV(vec2 w) { return (w - uGrid.xy) / (uGrid.z * uGridN); }

// Mip-Stufe nach der Entfernung: ein Texel etwa so groß wie der Punktabstand dort
float heightLevel(float dist) { return clamp(log2(max(dist, 1.0) / (64.0 * uLodRange.z * uGrid.z)), 0.0, 9.0); }

float heightAt(vec2 w, float lvl) { return textureLod(uHeight, gridUV(w), lvl).r * uHMap.x + uHMap.y; }

float terrainHeight(vec2 w, float dist) { return heightAt(w, heightLevel(dist)); }

uint sourceAt(vec2 w) {
    ivec2 c = clamp(ivec2(floor((w - uGrid.xy) / uGrid.z)), ivec2(0), ivec2(int(uGridN) - 1));
    return texelFetch(uSource, c, 0).r;
}
