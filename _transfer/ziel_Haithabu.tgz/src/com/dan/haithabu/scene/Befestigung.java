package com.dan.haithabu.scene;

import com.dan.timber.Fortification;
import com.dan.timber.Structures;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Phase 7: Wall, Tore, Hochburg. Der Halbkreiswall steht im Gelände (DGM1): sein Kamm ist hier als Linie gemessen
 * ({@link #KAMM}, verfolgt im Höhenmodell, je 8 m ein Punkt). Was das DGM nicht zeigt, wird für 950 ergänzt und ist
 * gestaltet [G]: der Bogen im Nordwesten, wo eine moderne Straße den Wall durchschneidet (mit dem Nordtor), die beiden
 * Enden bis an das Ufer von 950, Lücken späterer Wege, ein Graben vor dem Wall, die Palisade auf der Außenkante des
 * Kamms mit dem Wehrgang dahinter, drei Tore mit Torbauten (Nord, West am Bach, Süd) und der Durchlass des Bachs.
 * <p>
 * Die Hochburg im Norden ist ein langes Rechteck auf der Moränenkuppe, gelegt um die Grabhügel, die das DGM als
 * flache Kuppen zeigt [Lage nach den Kuppen, Maß nach KuLaDig: innen 240 × 72 m]; ihr niedriger Wall, das Tor im
 * Nordosten und die Höhe der Hügel um 950 sind gestaltet [G].
 * <p>
 * Der Verbindungswall zum Danewerk entstand erst um 968 (Werkbuch, Abschnitt 2) und steht um 950 noch nicht (F24 A):
 * wo das DGM ihn zeigt, wird er eingeebnet.
 * <p>
 * {@link #formen} ändert das Gelände der Szene (vor allem anderen, gleich nach dem Laden), {@link #bauwerke} legt die
 * Hölzer in eine {@link Structures.Set} der Siedlung, {@link #inside} und {@link #radius} ersetzen die Messung des
 * Walls aus Phase 6, {@link #fahrt} gibt den Weg der Kamerafahrt „Über den Wall“.
 */
public final class Befestigung {
    /** Querschnitt des Walls, wo er ergänzt wird: oben flach ±3,5 m um die Kammlinie, Flanken 0,62 m je m (32°) [G]. */
    public static final double FLACH = 3.5, NEIGUNG = 0.62;
    /** Palisade auf der Außenkante (m nach außen von der Kammlinie), Höhe über dem Boden; Wehrgang dahinter [G]. */
    public static final double PAL_OFF = 2.6, PAL_H = 3.0, WALK_OFF = 1.0, WALK_W = 1.6, WALK_LIFT = 1.0;
    /** Graben vor dem Wall: Mitte in m vor der Kammlinie, halbe Breite, Tiefe [G]. */
    public static final double GRABEN_MITTE = 17, GRABEN_HALB = 5, GRABEN_TIEFE = 2.0;
    /** Lichte Breite der Tore [G]. */
    public static final double TOR_BREITE = 3.6;
    /** Hochburg: Mitte, Richtung der Längsachse (Grad von Nord), Innenmaß, Höhe ihres Walls um 950 [G]. */
    public static final double HB_X = -198, HB_Z = -688, HB_HEADING = 36, HB_L = 240, HB_W = 72, HB_WALL = 2.0;
    /** Mitte für die Halbmesser je Winkel (wie Phase 6, {@link Siedlung#WALL_CX}). */
    public static final double CX = Siedlung.WALL_CX, CZ = Siedlung.WALL_CZ;

    /**
     * Der Kamm des Halbkreiswalls, vom Südende am Noor über Westen nach Norden: x, z, Art (0 = im DGM1 gemessen,
     * 1 = ergänzt [G]). Verfolgt im Höhenmodell (größte Erhebung quer zur Linie über dem Mittel 12 m daneben), geglättet
     * und je 8 m abgetastet; der Bogen im Nordwesten ist eine Kurve zwischen den gemessenen Enden.
     */
    static final double[] KAMM = {
            36.2, 182.5, 1, 30.0, 187.6, 1, 23.9, 192.7, 1, 17.7, 197.9, 1, 11.6, 203.0, 1, 5.0, 207.5, 0,
            0.1, 213.3, 0, -6.7, 217.6, 0, -14.1, 220.6, 0, -21.6, 223.4, 0, -29.1, 226.1, 0, -36.6, 229.0, 0,
            -44.0, 231.9, 0, -51.4, 234.9, 0, -58.8, 238.0, 0, -66.3, 240.9, 0, -73.8, 243.6, 0, -81.4, 245.9, 0,
            -89.2, 247.8, 0, -97.1, 249.3, 0, -105.0, 250.5, 0, -112.9, 251.4, 0, -120.9, 252.2, 0, -128.9, 252.8, 0,
            -136.9, 252.9, 0, -144.9, 252.7, 0, -152.8, 251.9, 0, -160.8, 250.9, 0, -168.7, 249.6, 0, -176.5, 248.1, 0,
            -184.1, 245.6, 0, -191.1, 241.8, 0, -198.4, 238.6, 0, -206.3, 237.7, 0, -214.2, 238.8, 0, -222.2, 239.8, 0,
            -230.2, 240.3, 0, -238.2, 240.4, 0, -246.2, 240.4, 0, -254.2, 240.1, 0, -262.1, 239.3, 0, -270.0, 238.2, 0,
            -277.9, 236.8, 0, -285.6, 234.4, 0, -293.1, 231.7, 0, -300.7, 229.3, 0, -308.6, 228.8, 0, -316.6, 229.1, 0,
            -324.6, 229.7, 0, -332.6, 229.3, 0, -340.5, 228.2, 0, -348.3, 226.5, 0, -356.0, 224.1, 0, -363.5, 221.5, 0,
            -371.0, 218.8, 0, -378.5, 216.0, 0, -386.0, 213.2, 0, -393.6, 210.6, 0, -401.2, 208.2, 0, -408.8, 205.7, 0,
            -416.3, 203.0, 0, -423.7, 199.8, 0, -431.0, 196.6, 0, -438.3, 193.2, 0, -445.5, 189.8, 0, -452.7, 186.2, 0,
            -459.6, 182.3, 0, -466.6, 178.4, 0, -473.6, 174.5, 0, -480.5, 170.6, 0, -487.1, 166.1, 0, -493.0, 160.6, 0,
            -499.2, 155.6, 0, -505.7, 150.9, 0, -512.3, 146.4, 0, -518.0, 140.9, 0, -522.9, 134.5, 0, -527.5, 128.0, 0,
            -532.0, 121.3, 0, -535.8, 114.3, 0, -539.9, 107.5, 0, -543.9, 100.5, 0, -548.2, 93.8, 0, -552.4, 87.0, 0,
            -556.1, 79.9, 0, -560.1, 73.0, 0, -564.6, 66.4, 0, -569.8, 60.3, 0, -575.1, 54.3, 0, -579.1, 47.4, 0,
            -581.6, 39.9, 0, -582.2, 31.9, 0, -582.2, 23.9, 0, -583.7, 16.2, 0, -586.6, 8.7, 0, -590.2, 1.6, 0,
            -592.8, -5.9, 0, -594.6, -13.7, 0, -595.8, -21.6, 0, -596.3, -29.6, 0, -595.6, -37.6, 0, -593.9, -45.4, 0,
            -591.4, -53.0, 0, -587.9, -60.2, 0, -583.2, -66.6, 0, -578.0, -72.7, 0, -573.0, -78.9, 0, -568.7, -85.6, 0,
            -564.7, -92.6, 0, -560.9, -99.6, 0, -557.2, -106.7, 0, -553.7, -113.9, 0, -550.5, -121.3, 0, -547.4, -128.6, 0,
            -544.3, -136.0, 0, -541.0, -143.3, 0, -537.7, -150.6, 0, -534.6, -158.0, 0, -531.4, -165.3, 0, -528.2, -172.6, 0,
            -524.5, -179.7, 0, -521.2, -187.0, 0, -518.3, -194.4, 0, -514.9, -201.7, 0, -511.6, -208.9, 0, -508.0, -216.1, 0,
            -506.2, -223.9, 0, -504.4, -231.7, 0, -503.6, -239.6, 0, -502.6, -247.5, 0, -503.2, -255.4, 1, -501.6, -263.2, 1,
            -498.2, -270.4, 1, -493.1, -276.5, 1, -486.8, -281.5, 1, -479.8, -285.4, 1, -472.5, -288.5, 1, -465.0, -291.3, 1,
            -457.4, -293.9, 1, -449.8, -296.4, 1, -442.2, -299.0, 1, -434.8, -301.9, 1, -427.5, -305.2, 1, -420.4, -309.0, 1,
            -414.1, -313.7, 0, -408.1, -318.5, 0, -401.1, -322.3, 0, -394.3, -326.4, 0, -387.5, -330.6, 0, -380.4, -334.4, 0,
            -373.1, -337.6, 0, -365.5, -340.0, 0, -357.8, -342.1, 0, -349.9, -343.5, 0, -342.0, -344.9, 0, -334.2, -346.6, 0,
            -327.1, -350.1, 0, -320.7, -354.9, 0, -313.8, -358.9, 0, -306.4, -361.9, 0, -298.9, -364.7, 0, -291.5, -367.6, 0,
            -283.7, -369.5, 0, -275.8, -370.3, 0, -267.8, -369.8, 0, -259.8, -368.9, 0, -251.9, -367.8, 0, -243.9, -367.4, 0,
            -235.9, -367.8, 0, -228.0, -367.7, 0, -220.5, -368.2, 0, -214.4, -364.0, 1, -206.6, -362.4, 1, -198.7, -360.8, 1,
            -190.9, -359.2, 1, -183.1, -357.6, 1, -178.3, -356.6, 1,
    };

    /** Der Verbindungswall im DGM1 (drei erhaltene Stücke westlich des Westtors), je 20 m ein Punkt (F24). */
    public static final double[][][] VERBINDUNG = {
            {{-628, 49}, {-646, 56}, {-666, 66}, {-685, 69}, {-707, 71}, {-727, 72}, {-747, 74}, {-767, 77}, {-787, 73}, {-807, 70}, {-828, 68}, {-848, 69}, {-869, 69}, {-889, 68}, {-905, 73}},
            {{-1030, 60}, {-1050, 60}, {-1070, 62}, {-1090, 63}, {-1110, 67}, {-1130, 69}, {-1142, 71}},
            {{-1372, 58}, {-1380, 58}, {-1400, 59}, {-1420, 58}, {-1441, 59}, {-1461, 52}, {-1481, 47}, {-1501, 43}, {-1520, 36}, {-1540, 32}, {-1560, 27}, {-1579, 22},
                    {-1600, 21}, {-1620, 16}, {-1640, 12}, {-1659, 7}, {-1679, 2}, {-1698, -2}, {-1706, -5}}};

    /** Abstand der Proben auf der Kammlinie (m). */
    public static final double STEP = 2.0;

    /** Ein Tor: Name, Lage auf der Kammlinie (m vom Südende), der Torbau; bach = Durchlass des Bachs. */
    public record Tor(String name, double s, Fortification.Gate gate, boolean bach) { }

    /** Die Kammlinie in Proben zu 2 m: Lage, Kammhöhe (nach dem Formen), Bogenlänge, Normale nach außen, Art. */
    public final double[] x, z, y, s, nx, nz;
    public final byte[] art;
    /** Länge der Kammlinie (m). */
    public final double length;
    public final List<Tor> tore = new ArrayList<>();
    /** Grabhügel der Hochburg: x, z, Höhe, Halbmesser (m). */
    public final List<double[]> kuppen = new ArrayList<>();
    /** Für Prüfung und HUD: Anteil gemessen, tiefster Graben, Rest des Verbindungswalls (m), Zeit (ms). */
    public double gemessen, grabenTiefe, verbindungRest, ms;
    /** Erhebung des gemessenen Kamms über dem Gelände 22 m daneben (vor dem Formen), Mittel (m). */
    public double erhebung;
    /** Der Wall von der Grabensohle bis zum Kamm, Mittel über die gemessenen Proben (m). */
    public double grabenBisKamm;

    private final Terrain t;
    // Innen-Raster und Abstand zur Kammlinie (1 m, um die Linie)
    private final double gx0, gz0;
    private final int gw, gh;
    private final byte[] in;
    private final float[] dist;

    private Befestigung(Terrain t) {
        this.t = t;
        // Kammlinie in 2-m-Proben
        int n8 = KAMM.length / 3;
        double[] cum = new double[n8];
        for (int i = 1; i < n8; i++) cum[i] = cum[i - 1] + Math.hypot(KAMM[i * 3] - KAMM[i * 3 - 3], KAMM[i * 3 + 1] - KAMM[i * 3 - 2]);
        length = cum[n8 - 1];
        int n = (int) Math.floor(length / STEP) + 1;
        x = new double[n]; z = new double[n]; y = new double[n]; s = new double[n]; nx = new double[n]; nz = new double[n];
        art = new byte[n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            double si = Math.min(length, i * STEP);
            while (k < n8 - 2 && cum[k + 1] < si) k++;
            double f = (si - cum[k]) / Math.max(1e-9, cum[k + 1] - cum[k]);
            x[i] = KAMM[k * 3] + (KAMM[k * 3 + 3] - KAMM[k * 3]) * f;
            z[i] = KAMM[k * 3 + 1] + (KAMM[k * 3 + 4] - KAMM[k * 3 + 1]) * f;
            art[i] = (byte) (f < 0.5 ? KAMM[k * 3 + 2] : KAMM[k * 3 + 5]);
            s[i] = si;
        }
        // Normale nach außen: weg von der Mitte der Siedlung
        int sign = 0;
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 2), b = Math.min(n - 1, i + 2);
            double tx = x[b] - x[a], tz = z[b] - z[a], l = Math.hypot(tx, tz);
            nx[i] = -tz / l; nz[i] = tx / l;
            if (i == n / 2) sign = (nx[i] * (x[i] + 300) + nz[i] * (z[i] + 50)) > 0 ? 1 : -1;
        }
        for (int i = 0; i < n; i++) { nx[i] *= sign; nz[i] *= sign; }
        double minX = 1e9, maxX = -1e9, minZ = 1e9, maxZ = -1e9;
        for (int i = 0; i < n; i++) { minX = Math.min(minX, x[i]); maxX = Math.max(maxX, x[i]); minZ = Math.min(minZ, z[i]); maxZ = Math.max(maxZ, z[i]); }
        gx0 = Math.floor(minX) - 95; gz0 = Math.floor(minZ) - 95;
        gw = (int) (Math.ceil(maxX) + 95 - gx0) + 1; gh = (int) (Math.ceil(maxZ) + 95 - gz0) + 1;
        in = new byte[gw * gh];
        dist = new float[gw * gh];
    }

    /** Formt das Gelände für 950 und gibt die Befestigung; ohne Höhendaten (flache Bühne) null. */
    public static Befestigung formen(Terrain t) {
        if (t.brook.length <= 2) return null;
        long t0 = System.nanoTime();
        Befestigung b = new Befestigung(t);
        b.verbindungEinebnen();
        b.kammHoehen();
        b.toreSetzen();
        b.wallFormen();
        b.hochburgFormen();
        b.innenRaster();
        t.refresh();
        b.ms = (System.nanoTime() - t0) / 1e6;
        return b;
    }

    // ------------------------------------------------------------------ Kamm und Tore

    private int n() { return x.length; }

    /** Index der Probe bei Bogenlänge si. */
    public int index(double si) { return (int) Math.max(0, Math.min(n() - 1, Math.round(si / STEP))); }

    /** Kammhöhe an der Bogenlänge si (linear). */
    public double crestY(double si) {
        double f = Math.max(0, Math.min(n() - 1.0, si / STEP));
        int i = (int) Math.min(n() - 2, Math.floor(f));
        return y[i] + (y[i + 1] - y[i]) * (f - i);
    }

    /**
     * Kammhöhe je Probe: wo der Wall im DGM deutlich steht (gemessen, über 2,5 m über dem Gelände 22 m daneben), die
     * höchste Stelle quer zur Linie (±3 m), geglättet; sonst das Gelände daneben plus die Erhebung der nächsten guten
     * Nachbarn auf beiden Seiten.
     */
    private void kammHoehen() {
        int n = n();
        double[] hc = new double[n], gl = new double[n], r = new double[n];
        boolean[] good = new boolean[n];
        double sumE = 0;
        int nE = 0;
        for (int i = 0; i < n; i++) {
            double best = -1e9;
            for (double o = -3; o <= 3.01; o += 0.5) best = Math.max(best, t.height(x[i] + nx[i] * o, z[i] + nz[i] * o));
            hc[i] = best;
            gl[i] = 0.5 * (t.height(x[i] + nx[i] * 22, z[i] + nz[i] * 22) + t.height(x[i] - nx[i] * 22, z[i] - nz[i] * 22));
            r[i] = hc[i] - gl[i];
            good[i] = art[i] == 0 && r[i] > 2.5;
            if (good[i]) { sumE += r[i]; nE++; }
        }
        erhebung = nE > 0 ? sumE / nE : 0;
        gemessen = 0;
        for (int i = 0; i < n; i++) if (art[i] == 0) gemessen++;
        gemessen /= n;
        // Erhebung in den Lücken aus den Nachbarn
        double[] ri = new double[n];
        for (int i = 0; i < n; i++) {
            if (good[i]) { ri[i] = r[i]; continue; }
            int a = i, b = i;
            while (a > 0 && !good[a]) a--;
            while (b < n - 1 && !good[b]) b++;
            double ra = good[a] ? r[a] : Double.NaN, rb = good[b] ? r[b] : Double.NaN;
            ri[i] = Double.isNaN(ra) ? rb : Double.isNaN(rb) ? ra : ra + (rb - ra) * (i - a) / (double) (b - a);
            if (Double.isNaN(ri[i])) ri[i] = 5.5;
            // an den ergänzten Enden läuft der Wall zum Ufer hin flach aus
            if (Double.isNaN(ra) || Double.isNaN(rb)) ri[i] *= smooth(0, 24, Math.min(s[i], length - s[i]));
        }
        for (int i = 0; i < n; i++) {
            if (!good[i]) {
                int a = i, b = i;
                while (a > 0 && !good[a]) a--;
                while (b < n - 1 && !good[b]) b++;
                if (good[a] && good[b] && (b - a) * STEP < 40) {
                    // kurze Lücke (Tor, späterer Weg): Kamm geradlinig zwischen den Nachbarn
                    y[i] = hc[a] + (hc[b] - hc[a]) * (i - a) / (double) (b - a);
                    continue;
                }
            }
            if (good[i]) {
                double sum = 0;
                int c = 0;
                for (int j = Math.max(0, i - 2); j <= Math.min(n - 1, i + 2); j++) if (good[j]) { sum += hc[j]; c++; }
                y[i] = sum / c;
            } else y[i] = gl[i] + ri[i];
        }
        this.good = good;
    }

    private boolean[] good;

    /** Die drei Tore und der Durchlass des Bachs. */
    private void toreSetzen() {
        int n = n();
        // Süden: die Lücke im DGM südlich der Mitte
        int sued = nearest(-203.8, 238.0);
        // Norden: Mitte des ergänzten Bogens im Nordwesten
        int a = -1, b = -1, bestLen = 0;
        for (int i = 0; i < n; ) {
            if (art[i] == 1) {
                int j = i;
                while (j < n && art[j] == 1) j++;
                if (i > 0 && j < n && j - i > bestLen) { bestLen = j - i; a = i; b = j - 1; }
                i = j;
            } else i++;
        }
        int nord = a >= 0 ? (a + b) / 2 : n * 3 / 4;
        // Westen: wo der Bach die Kammlinie kreuzt; das Tor 9 m daneben, auf der Seite mit mehr Platz in der Lücke
        double sb = brookCrossing();
        int west;
        if (!Double.isNaN(sb)) {
            int ib = index(sb), lo = ib, hi = ib;
            while (lo > 0 && !good[lo]) lo--;
            while (hi < n - 1 && !good[hi]) hi++;
            int dir = (hi - ib) >= (ib - lo) ? 1 : -1;
            west = index(sb + dir * 9);
        } else west = nearest(-574, 55);
        java.util.List<Object[]> plan = new java.util.ArrayList<>();
        plan.add(new Object[]{"Südtor", sued, TOR_BREITE, true, true});
        plan.add(new Object[]{"Westtor", west, TOR_BREITE, true, true});
        plan.add(new Object[]{"Nordtor", nord, TOR_BREITE, true, true});
        if (!Double.isNaN(sb)) {
            double hwB = 1.6;
            for (double[] p : t.brook) if (Math.hypot(p[0] - x[index(sb)], p[1] - z[index(sb)]) < 6) hwB = Math.max(hwB, p[4]);
            plan.add(new Object[]{"Bachdurchlass", index(sb), 2 * hwB + 1.6, false, false});
        }
        // Um 950 stand der Wall an den Toren in voller Höhe (Fassung aus Holz); die abgeflachten Enden im DGM sind
        // spätere Abtragung. Je ±32 m um ein Tor wird der Kamm geradlinig zwischen den Nachbarn ergänzt [G].
        boolean[] win = new boolean[n];
        for (Object[] pl : plan) {
            int c = (Integer) pl[1];
            for (int i = Math.max(0, c - 16); i <= Math.min(n - 1, c + 16); i++) win[i] = true;
        }
        for (int i = 0; i < n; ) {
            if (!win[i]) { i++; continue; }
            int j = i;
            while (j < n && win[j]) j++;
            int wa = Math.max(0, i - 1), wb = Math.min(n - 1, j);
            for (int k = i; k < j; k++) {
                double target = y[wa] + (y[wb] - y[wa]) * (k - wa) / (double) Math.max(1, wb - wa);
                if (target > y[k] + 0.15) { y[k] = target; good[k] = false; }
            }
            i = j;
        }
        for (Object[] pl : plan) tore.add(tor((String) pl[0], (Integer) pl[1], (Double) pl[2], (Boolean) pl[3], (Boolean) pl[4]));
    }

    private Tor tor(String name, int i, double width, boolean tower, boolean leaves) {
        double heading = Math.toDegrees(Math.atan2(nx[i], -nz[i]));
        double floorRef = t.height(x[i], z[i]);
        double yc = y[i];
        double rise = Math.max(1.5, yc - floorRef);
        double hd = Math.max(8, Math.min(17, FLACH + rise / NEIGUNG + 1.0));
        double fin = t.height(x[i] - nx[i] * hd, z[i] - nz[i] * hd), fout = t.height(x[i] + nx[i] * hd, z[i] + nz[i] * hd);
        boolean bach = !leaves && !tower;
        if (bach) {
            double lv = t.brookLevel(x[i], z[i]);
            double bed = t.height(x[i], z[i]);
            fin = fout = Math.min(bed, Double.isInfinite(lv) ? bed : lv - 0.4);
        } else {
            // die Gasse nicht über den Wall: Enden höchstens 0,8 m über der Mitte
            fin = Math.min(fin, floorRef + 0.8);
            fout = Math.min(fout, floorRef + 0.8);
        }
        Fortification.Gate g = new Fortification.Gate(x[i], z[i], heading, fin, fout, yc + WALK_LIFT, width, 2 * hd, FLACH, NEIGUNG, PAL_OFF + 0.4, tower, leaves);
        return new Tor(name, s[i], g, bach);
    }

    private int nearest(double px, double pz) {
        int best = 0;
        double bd = 1e18;
        for (int i = 0; i < n(); i++) { double d = Math.hypot(x[i] - px, z[i] - pz); if (d < bd) { bd = d; best = i; } }
        return best;
    }

    /** Bogenlänge, an der der Bach die Kammlinie kreuzt (NaN ohne Bach). */
    private double brookCrossing() {
        double[][] bk = t.brook;
        for (int i = 0; i + 1 < n(); i++)
            for (int j = 0; j + 1 < bk.length; j++) {
                double ax = x[i], az = z[i], bx = x[i + 1], bz = z[i + 1], cx = bk[j][0], cz = bk[j][1], dx = bk[j + 1][0], dz = bk[j + 1][1];
                double den = (bx - ax) * (dz - cz) - (bz - az) * (dx - cx);
                if (Math.abs(den) < 1e-12) continue;
                double u = ((cx - ax) * (dz - cz) - (cz - az) * (dx - cx)) / den, v = ((cx - ax) * (bz - az) - (cz - az) * (bx - ax)) / den;
                if (u >= 0 && u <= 1 && v >= 0 && v <= 1) return s[i] + u * (s[i + 1] - s[i]);
            }
        return Double.NaN;
    }

    // ------------------------------------------------------------------ Gelände formen

    /**
     * Für jede Zelle um die Kammlinie: nächster Punkt der Linie (Bogenlänge) und Abstand mit Vorzeichen (+ außen).
     * Dann: wo der Wall fehlt (ergänzt, Lücken außer Torgassen und Bach), der Querschnitt mit max(); außen der Graben;
     * zuletzt die Torgassen eben nach ihrem Boden.
     */
    private void wallFormen() {
        int n = n();
        float[] bd = new float[gw * gh], bs = new float[gw * gh], sd = new float[gw * gh];
        java.util.Arrays.fill(bd, Float.MAX_VALUE);
        double reach = GRABEN_MITTE + GRABEN_HALB + 4, far = 90;
        for (int i = 0; i + 1 < n; i++) {
            double ax = x[i], az = z[i], bx = x[i + 1], bz = z[i + 1], ex = bx - ax, ez = bz - az, l2 = ex * ex + ez * ez;
            int i0 = (int) Math.floor(Math.min(ax, bx) - far - gx0), i1 = (int) Math.ceil(Math.max(ax, bx) + far - gx0);
            int j0 = (int) Math.floor(Math.min(az, bz) - far - gz0), j1 = (int) Math.ceil(Math.max(az, bz) + far - gz0);
            for (int j = Math.max(0, j0); j <= Math.min(gh - 1, j1); j++)
                for (int ii = Math.max(0, i0); ii <= Math.min(gw - 1, i1); ii++) {
                    double px = gx0 + ii + 0.5, pz = gz0 + j + 0.5;
                    double u = Math.max(0, Math.min(1, ((px - ax) * ex + (pz - az) * ez) / l2));
                    double qx = ax + ex * u - px, qz = az + ez * u - pz, d2 = qx * qx + qz * qz;
                    int k = j * gw + ii;
                    if (d2 < bd[k]) {
                        double d = Math.sqrt(d2);
                        bd[k] = (float) d2;
                        bs[k] = (float) (s[i] + u * (s[i + 1] - s[i]));
                        double mnx = nx[i] + (nx[i + 1] - nx[i]) * u, mnz = nz[i] + (nz[i + 1] - nz[i]) * u;
                        sd[k] = (float) ((-qx) * mnx + (-qz) * mnz >= 0 ? d : -d);
                    }
                }
        }
        double deepest = 0;
        for (int j = 0; j < gh; j++)
            for (int ii = 0; ii < gw; ii++) {
                int k = j * gw + ii;
                bd[k] = bd[k] == Float.MAX_VALUE ? Float.MAX_VALUE : (float) Math.sqrt(bd[k]);
                dist[k] = Math.min(bd[k], 90f);
                if (bd[k] > reach) continue;
                double px = gx0 + ii + 0.5, pz = gz0 + j + 0.5, si = bs[k], d = sd[k], ad = Math.abs(d);
                int ti = cellIndex(px, pz);
                if (ti < 0) continue;
                double h0 = Terrain.decode(t.h[ti]), h = h0;
                int ix = index(si);
                // Wallkörper, wo er im DGM fehlt (nicht in Torgassen und am Bach)
                if (!good[ix] && ad < FLACH + 14 && !inPassage(si, 0.08)) {
                    double target = crestY(si) - Math.max(0, ad - FLACH) * NEIGUNG;
                    // an den Enden der Linie läuft der Wall rund aus
                    if (si <= 0.01 || si >= length - 0.01) target = crestY(si) - Math.max(0, bd[k] - FLACH) * NEIGUNG;
                    h = Math.max(h, target);
                }
                // Graben außen
                if (d > 0) {
                    double q = (d - GRABEN_MITTE) / GRABEN_HALB;
                    if (Math.abs(q) < 1) {
                        double depth = GRABEN_TIEFE * grabenFade(si);
                        double c = Math.cos(q * Math.PI / 2);
                        h -= depth * c * c;
                    }
                }
                if (Math.abs(h - h0) > 0.005) {
                    t.h[ti] = Terrain.encode(h);
                    if (Math.abs(h - h0) > 0.05 && t.src[ti] == Terrain.GEMESSEN) t.src[ti] = Terrain.MODELLIERT;
                }
            }
        // Torgassen eben nach ihrem Boden
        for (Tor tr : tore) {
            Fortification.Gate g = tr.gate();
            double hw = g.width() / 2 + 0.5, hd = g.depth() / 2;
            double r = Math.hypot(hw, hd) + 1;
            for (double pz = g.z() - r; pz <= g.z() + r; pz += 1)
                for (double px = g.x() - r; px <= g.x() + r; px += 1) {
                    double cx = Math.floor(px) + 0.5, cz = Math.floor(pz) + 0.5;
                    double a = Math.toRadians(g.headingDeg());
                    double ls = (cx - g.x()) * Math.sin(a) - (cz - g.z()) * Math.cos(a), lq = (cx - g.x()) * Math.cos(a) + (cz - g.z()) * Math.sin(a);
                    if (Math.abs(lq) > hw || Math.abs(ls) > hd) continue;
                    int ti = cellIndex(cx, cz);
                    if (ti < 0 || tr.bach()) continue;
                    double f = g.floor(ls);
                    // am Rand der Gasse weich in den Wall übergehen
                    double w = Math.max(0, Math.min(1, (hw - Math.abs(lq)) / 0.5));
                    double h0 = Terrain.decode(t.h[ti]);
                    double h = h0 + (f - h0) * w;
                    t.h[ti] = Terrain.encode(h);
                }
        }
        // Graben: tiefster Punkt gegenüber dem Gelände daneben, für die Prüfung; Wall von der Sohle bis zum Kamm
        double sumG = 0;
        int cG = 0;
        for (int i = 0; i < n; i += 5) {
            if (grabenFade(s[i]) < 0.99) continue;
            double bottom = t.height(x[i] + nx[i] * GRABEN_MITTE, z[i] + nz[i] * GRABEN_MITTE);
            double edges = 0.5 * (t.height(x[i] + nx[i] * (GRABEN_MITTE - GRABEN_HALB - 1), z[i] + nz[i] * (GRABEN_MITTE - GRABEN_HALB - 1))
                    + t.height(x[i] + nx[i] * (GRABEN_MITTE + GRABEN_HALB + 1), z[i] + nz[i] * (GRABEN_MITTE + GRABEN_HALB + 1)));
            deepest = Math.max(deepest, edges - bottom);
            if (good[i]) { sumG += y[i] - bottom; cG++; }
        }
        grabenTiefe = deepest;
        grabenBisKamm = cG > 0 ? sumG / cG : 0;
    }

    /** Liegt die Bogenlänge si in einer Torgasse (oder im Durchlass des Bachs), mit Rand pad? */
    private boolean inPassage(double si, double pad) {
        for (Tor tr : tore) if (Math.abs(si - tr.s()) < tr.gate().width() / 2 + pad) return true;
        return false;
    }

    /** Tiefe des Grabens 0..1: läuft an den Enden, vor den Toren und am Ufer aus (für die Prüfung). */
    public double grabenFadeAt(double si) { return grabenFade(si); }

    /** Tiefe des Grabens 0..1: läuft an den Enden, vor den Toren und am Ufer aus. */
    double grabenFade(double si) {
        double f = smooth(0, 40, si) * smooth(0, 40, length - si);
        for (Tor tr : tore) f *= smooth(7, 15, Math.abs(si - tr.s()));
        int i = index(si);
        double outside = t.height(x[i] + nx[i] * (GRABEN_MITTE + GRABEN_HALB + 4), z[i] + nz[i] * (GRABEN_MITTE + GRABEN_HALB + 4));
        return f * smooth(1.6, 3.2, outside);
    }

    static double smooth(double a, double b, double v) {
        double q = Math.max(0, Math.min(1, (v - a) / (b - a)));
        return q * q * (3 - 2 * q);
    }

    private static int cellIndex(double px, double pz) {
        int i = (int) Math.floor((px - Terrain.X0) / Terrain.CELL), j = (int) Math.floor((pz - Terrain.Z0) / Terrain.CELL);
        return i < 0 || j < 0 || i >= Terrain.N || j >= Terrain.N ? -1 : j * Terrain.N + i;
    }

    /**
     * F24 A: der Verbindungswall (um 968) steht um 950 noch nicht. Quer zu jedem Stück wird das Gelände zwischen den
     * Punkten 19 m links und rechts geradlinig verbunden und der Wall bis darauf abgetragen.
     */
    private void verbindungEinebnen() {
        double rest = 0;
        for (double[][] line : VERBINDUNG) {
            // Höhen vor dem Abtragen lesen (die Stücke überlappen sich nicht)
            java.util.Map<Integer, Double> neu = new java.util.HashMap<>();
            for (int i = 0; i + 1 < line.length; i++) {
                double ax = line[i][0], az = line[i][1], bx = line[i + 1][0], bz = line[i + 1][1], ex = bx - ax, ez = bz - az, l = Math.hypot(ex, ez);
                double ux = ex / l, uz = ez / l, pnx = -uz, pnz = ux;
                for (double pz = Math.floor(Math.min(az, bz) - 30); pz <= Math.max(az, bz) + 30; pz += 1)
                    for (double px = Math.floor(Math.min(ax, bx) - 30); px <= Math.max(ax, bx) + 30; px += 1) {
                        double cx = px + 0.5, cz = pz + 0.5;
                        double along = (cx - ax) * ux + (cz - az) * uz, perp = (cx - ax) * pnx + (cz - az) * pnz;
                        if (along < (i == 0 ? -14 : -2) || along > l + (i == line.length - 2 ? 14 : 2) || Math.abs(perp) > 16) continue;
                        double fx = ax + ux * along, fz = az + uz * along;
                        double hl = t.height(fx + pnx * 19, fz + pnz * 19), hr = t.height(fx - pnx * 19, fz - pnz * 19);
                        double base = hr + (hl - hr) * (perp + 19) / 38;
                        int ti = cellIndex(cx, cz);
                        if (ti < 0) continue;
                        double h = Terrain.decode(t.h[ti]);
                        // an den Enden der Stücke weich auslaufen
                        double endW = (i == 0 ? smooth(-14, -4, along) : 1) * (i == line.length - 2 ? smooth(l + 14, l + 4, along) : 1);
                        double w = (1 - smooth(11, 16, Math.abs(perp))) * endW;
                        double target = h - w * Math.max(0, h - base);
                        Double prev = neu.get(ti);
                        if (prev == null || target < prev) neu.put(ti, target);
                    }
            }
            for (var e : neu.entrySet()) {
                double h0 = Terrain.decode(t.h[e.getKey()]);
                if (e.getValue() < h0 - 0.005) {
                    t.h[e.getKey()] = Terrain.encode(e.getValue());
                    if (h0 - e.getValue() > 0.05 && t.src[e.getKey()] == Terrain.GEMESSEN) t.src[e.getKey()] = Terrain.MODELLIERT;
                }
            }
            // Rest: größte Erhebung der Linie über dem Gelände 19 m daneben
            for (int i = 1; i + 2 < line.length; i++)
                for (double f = 0.1; f < 0.95; f += 0.2) {
                    double px = line[i][0] + (line[i + 1][0] - line[i][0]) * f, pz = line[i][1] + (line[i + 1][1] - line[i][1]) * f;
                    double ex = line[i + 1][0] - line[i][0], ez = line[i + 1][1] - line[i][1], l = Math.hypot(ex, ez);
                    double pnx = -ez / l, pnz = ex / l;
                    double base = 0.5 * (t.height(px + pnx * 19, pz + pnz * 19) + t.height(px - pnx * 19, pz - pnz * 19));
                    double top = -1e9;
                    for (double o = -6; o <= 6; o += 1) top = Math.max(top, t.height(px + pnx * o, pz + pnz * o));
                    rest = Math.max(rest, top - base);
                }
        }
        verbindungRest = rest;
    }

    /**
     * Die Hochburg [G]: um das Rechteck ein niedriger Wall von 2 m (Kamm 3 m vor der Innenkante, Flanken 0,45),
     * offen am Nordostende für das Tor; die Grabhügel an den Kuppen, die das DGM zeigt, aufgehöht auf ihre Form um 950
     * (0,6 bis 1,4 m hoch, 5 bis 11 m breit).
     */
    private void hochburgFormen() {
        double a = Math.toRadians(HB_HEADING), ux = Math.sin(a), uz = -Math.cos(a), vx = Math.cos(a), vz = Math.sin(a);
        int R = (int) Math.ceil(HB_L / 2 + 30);
        int w = 2 * R + 1, x0 = (int) Math.floor(HB_X) - R, z0 = (int) Math.floor(HB_Z) - R;
        float[] h = new float[w * w];
        for (int j = 0; j < w; j++) for (int i = 0; i < w; i++) h[j * w + i] = (float) t.height(x0 + i + 0.5, z0 + j + 0.5);
        float[] b4 = blur(blur(h, w, 4), w, 4), b8 = blur(blur(h, w, 8), w, 8);
        // Kuppen: Maxima der Erhebung über dem geglätteten Gelände
        double A = HB_L / 2, B = HB_W / 2;
        for (int j = 3; j < w - 3; j++)
            for (int i = 3; i < w - 3; i++) {
                int k = j * w + i;
                double r = h[k] - b4[k];
                if (r < 0.18) continue;
                double px = x0 + i + 0.5, pz = z0 + j + 0.5, lu = (px - HB_X) * ux + (pz - HB_Z) * uz, lv = (px - HB_X) * vx + (pz - HB_Z) * vz;
                if (Math.abs(lu) > A - 3 || Math.abs(lv) > B - 3) continue;
                boolean max = true;
                for (int dj = -3; dj <= 3 && max; dj++) for (int di = -3; di <= 3; di++) if ((di != 0 || dj != 0) && h[k + dj * w + di] - b4[k + dj * w + di] > r) { max = false; break; }
                if (!max) continue;
                double q = Math.min(1, r / 0.6);
                kuppen.add(new double[]{px, pz, 0.6 + 0.8 * q, 2.5 + 3 * q, b4[k]});
            }
        for (int j = 0; j < w; j++)
            for (int i = 0; i < w; i++) {
                int k = j * w + i;
                double px = x0 + i + 0.5, pz = z0 + j + 0.5;
                int ti = cellIndex(px, pz);
                if (ti < 0) continue;
                double h0 = Terrain.decode(t.h[ti]), hn = h0;
                double lu = (px - HB_X) * ux + (pz - HB_Z) * uz, lv = (px - HB_X) * vx + (pz - HB_Z) * vz;
                // Wall der Hochburg
                double qx = Math.abs(lu) - (A + 3), qy = Math.abs(lv) - (B + 3);
                double sdist = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0);
                boolean torGap = lu > A - 4 && Math.abs(lv) < 2.5;
                if (Math.abs(sdist) < 0.8 + HB_WALL / 0.45 && !torGap) hn = Math.max(hn, b8[k] + HB_WALL - Math.max(0, Math.abs(sdist) - 0.8) * 0.45);
                // Grabhügel
                for (double[] m : kuppen) {
                    double d = Math.hypot(px - m[0], pz - m[1]);
                    if (d >= m[3]) continue;
                    double f = 1 - (d / m[3]) * (d / m[3]);
                    hn = Math.max(hn, m[4] + m[2] * Math.pow(f, 1.5));
                }
                if (hn > h0 + 0.005) {
                    t.h[ti] = Terrain.encode(hn);
                    if (hn - h0 > 0.05 && t.src[ti] == Terrain.GEMESSEN) t.src[ti] = Terrain.MODELLIERT;
                }
            }
    }

    /** Gleitendes Mittel (Kasten 2r+1) in beiden Richtungen. */
    private static float[] blur(float[] a, int w, int r) {
        float[] tmp = new float[a.length], out = new float[a.length];
        for (int j = 0; j < w; j++)
            for (int i = 0; i < w; i++) {
                double s = 0;
                int c = 0;
                for (int d = -r; d <= r; d++) { int ii = i + d; if (ii >= 0 && ii < w) { s += a[j * w + ii]; c++; } }
                tmp[j * w + i] = (float) (s / c);
            }
        for (int j = 0; j < w; j++)
            for (int i = 0; i < w; i++) {
                double s = 0;
                int c = 0;
                for (int d = -r; d <= r; d++) { int jj = j + d; if (jj >= 0 && jj < w) { s += tmp[jj * w + i]; c++; } }
                out[j * w + i] = (float) (s / c);
            }
        return out;
    }

    // ------------------------------------------------------------------ Innen und Halbmesser

    /** Innen-Raster: Polygon aus der Kammlinie, im Osten über das Noor geschlossen; Zeile für Zeile gefüllt. */
    private void innenRaster() {
        int n = n();
        double[][] poly = new double[n + 2][];
        for (int i = 0; i < n; i++) poly[i] = new double[]{x[i], z[i]};
        poly[n] = new double[]{gx0 + gw + 400, z[n - 1]};
        poly[n + 1] = new double[]{gx0 + gw + 400, z[0]};
        double[] xs = new double[poly.length];
        for (int j = 0; j < gh; j++) {
            double pz = gz0 + j + 0.5;
            int c = 0;
            for (int e = 0; e < poly.length; e++) {
                double[] p = poly[e], q = poly[(e + 1) % poly.length];
                if ((p[1] <= pz) != (q[1] <= pz)) xs[c++] = p[0] + (pz - p[1]) / (q[1] - p[1]) * (q[0] - p[0]);
            }
            java.util.Arrays.sort(xs, 0, c);
            for (int e = 0; e + 1 < c; e += 2) {
                int i0 = (int) Math.ceil(xs[e] - gx0 - 0.5), i1 = (int) Math.floor(xs[e + 1] - gx0 - 0.5);
                for (int i = Math.max(0, i0); i <= Math.min(gw - 1, i1); i++) in[j * gw + i] = 1;
            }
        }
    }

    /** Liegt (px, pz) innerhalb des Walls, mindestens margin m vom Kamm (margin bis 85 m)? Östlich der Linie: ja. */
    public boolean inside(double px, double pz, double margin) {
        int i = (int) Math.floor(px - gx0), j = (int) Math.floor(pz - gz0);
        if (i < 0 || j < 0 || i >= gw || j >= gh) return px > gx0 + gw && pz > gz0 && pz < gz0 + gh;
        int k = j * gw + i;
        return in[k] != 0 && dist[k] > margin;
    }

    /** Abstand zur Kammlinie (m); 90 heißt „90 m oder weiter“. */
    public double distance(double px, double pz) {
        int i = (int) Math.floor(px - gx0), j = (int) Math.floor(pz - gz0);
        if (i < 0 || j < 0 || i >= gw || j >= gh) return 90;
        return dist[j * gw + i];
    }

    /** Halbmesser der Kammlinie von der Mitte (CX, CZ) aus in Richtung deg (atan2(z, x)); ohne Treffer def. */
    public double radius(double deg, double def) {
        double a = Math.toRadians(deg), dx = Math.cos(a), dz = Math.sin(a), best = Double.MAX_VALUE;
        for (int i = 0; i + 1 < n(); i++) {
            double ex = x[i + 1] - x[i], ez = z[i + 1] - z[i];
            double den = dx * ez - dz * ex;
            if (Math.abs(den) < 1e-12) continue;
            double wx = x[i] - CX, wz = z[i] - CZ;
            double tt = (wx * ez - wz * ex) / den, u = (wx * dz - wz * dx) / den;
            if (tt > 0 && u >= 0 && u <= 1) best = Math.min(best, tt);
        }
        return best == Double.MAX_VALUE ? def : best;
    }

    // ------------------------------------------------------------------ Hölzer

    /**
     * Legt Palisade, Wehrgang, Torbauten und das Tor der Hochburg in set. Die Palisade steht PAL_OFF m vor der
     * Kammlinie und setzt an den Torgassen aus (der Torturm schließt die Lücke); über den Bach läuft sie als Sperre aus
     * Pfählen im Wasser. Der Wehrgang setzt an den Plattformen der Tore aus.
     */
    public void bauwerke(Structures.Set set, Structures.Ground g) {
        List<double[]> pal = new ArrayList<>(), walk = new ArrayList<>();
        long seed = 7001;
        for (int i = 0; i < n(); i++) {
            double si = s[i];
            boolean gapPal = false, gapWalk = false;
            for (Tor tr : tore) {
                double hw = tr.gate().width() / 2;
                if (!tr.bach() && Math.abs(si - tr.s()) < hw + 0.25) gapPal = true;
                if (Math.abs(si - tr.s()) < hw + 0.7) gapWalk = true;
            }
            if (gapPal) { flush(set, pal, true, g, seed++); } else pal.add(new double[]{x[i] + nx[i] * PAL_OFF, z[i] + nz[i] * PAL_OFF});
            if (gapWalk) { flush(set, walk, false, g, seed++); } else walk.add(new double[]{x[i] + nx[i] * WALK_OFF, z[i] + nz[i] * WALK_OFF});
        }
        flush(set, pal, true, g, seed++);
        flush(set, walk, false, g, seed++);
        for (Tor tr : tore) set.gate(tr.gate(), seed++);
        set.gate(hochburgTor(), seed);
    }

    private void flush(Structures.Set set, List<double[]> pts, boolean palisade, Structures.Ground g, long seed) {
        if (pts.size() >= 2) {
            double[][] l = pts.toArray(new double[0][]);
            if (palisade) set.palisade(l, PAL_H, g, seed);
            else {
                // Wehrgang: Boden der Linie geglättet (kein Hüpfen über Unebenheiten des Kamms)
                set.wallWalk(l, WALK_W, WALK_LIFT, smoothGround(l, g), seed);
            }
        }
        pts.clear();
    }

    /** Boden entlang einer Linie, über ±6 m gemittelt; außerhalb der Linie das Gelände. */
    private static Structures.Ground smoothGround(double[][] l, Structures.Ground g) {
        double[] hs = new double[l.length];
        for (int i = 0; i < l.length; i++) {
            double sum = 0;
            int c = 0;
            for (int j = Math.max(0, i - 3); j <= Math.min(l.length - 1, i + 3); j++) { sum += g.height(l[j][0], l[j][1]); c++; }
            hs[i] = sum / c;
        }
        return (px, pz) -> {
            int best = 0;
            double bd = 1e18;
            for (int i = 0; i < l.length; i++) { double d = (l[i][0] - px) * (l[i][0] - px) + (l[i][1] - pz) * (l[i][1] - pz); if (d < bd) { bd = d; best = i; } }
            return bd < 9 ? hs[best] : g.height(px, pz);
        };
    }

    /** Das Tor der Hochburg im Nordosten: ein schlichter Torbau ohne Turm [G]. */
    public Fortification.Gate hochburgTor() {
        double a = Math.toRadians(HB_HEADING), ux = Math.sin(a), uz = -Math.cos(a);
        double cx = HB_X + ux * (HB_L / 2 + 3), cz = HB_Z + uz * (HB_L / 2 + 3);
        double fin = t.height(cx - ux * 4, cz - uz * 4), fout = t.height(cx + ux * 4, cz + uz * 4), f = Math.min(fin, fout);
        return new Fortification.Gate(cx, cz, HB_HEADING, fin, fout, f + 3.2, 3.0, 8, 0.8, 0.45, 1.5, false, true);
    }

    // ------------------------------------------------------------------ Kamerafahrt

    /**
     * Der Weg der Fahrt „Über den Wall“: auf dem Wehrgang vom Südende am Noor über Westen nach Norden, je 2 m ein
     * Punkt {x, Augenhöhe, z}; das Auge 1,7 m über den Bohlen (über Toren auf der Plattform, über dem Bach auf dem Steg).
     */
    public double[][] fahrt() {
        int n = n();
        int i0 = index(12), i1 = index(length - 12);
        double[][] p = new double[i1 - i0 + 1][];
        double[] yy = new double[p.length];
        for (int i = i0; i <= i1; i++) {
            double px = x[i] + nx[i] * WALK_OFF, pz = z[i] + nz[i] * WALK_OFF;
            double deck = Math.max(t.height(px, pz), y[i] - 0.4) + WALK_LIFT;
            for (Tor tr : tore) if (Math.abs(s[i] - tr.s()) < tr.gate().width() / 2 + 1.5) deck = Math.max(deck, tr.gate().topY());
            p[i - i0] = new double[]{px, 0, pz};
            yy[i - i0] = deck + 1.7;
        }
        for (int i = 0; i < p.length; i++) {
            double sum = 0;
            int c = 0;
            for (int j = Math.max(0, i - 4); j <= Math.min(p.length - 1, i + 4); j++) { sum += yy[j]; c++; }
            p[i][1] = Math.max(sum / c, yy[i] - 0.3);
        }
        return p;
    }

    /** „Wall 1 402 m (86 % im DGM gemessen), Graben 2,0 m, 3 Tore · Hochburg 78 Grabhügel“ */
    public String describe() {
        return String.format(Locale.GERMAN, "Wall %,.0f m (%.0f %% im DGM gemessen, %.1f m über dem Gelände, %.1f m über der Grabensohle), Palisade %.1f m, %d Tore, Bachdurchlass · Hochburg %d Grabhügel · Verbindungswall eingeebnet (Rest %.1f m)",
                length, gemessen * 100, erhebung, grabenBisKamm, PAL_H, tore.stream().filter(tr -> !tr.bach()).count(), kuppen.size(), verbindungRest);
    }
}
