package com.dan.haithabu.scene;

/**
 * Phase 2b: wo die Bodendecke aus {@code com.dan.ground} (Biom „Schlei im Herbst“) wächst [G]. Unter Bäumen Adlerfarn
 * und Laubstreu, auf dem Erlenbruch Seggen auf nassem Boden; auf den Wiesen späte Schafgarbe und Rainfarn in Flecken
 * (das Gras selbst zeichnet {@code com.dan.reed}); Kiesel am Ufer, verstreut Steine und Findlinge. Im Wasser, im
 * Schilf und im Bachbett nichts. Die Siedlung (Phase 6) bringt Wege und offene Erde dazu.
 */
public final class Bodendecke implements com.dan.ground.Site {
    private final Terrain t;
    private final Vegetation v;

    public Bodendecke(Terrain t, Vegetation v) { this.t = t; this.v = v; }

    @Override public float height(double x, double z) { return (float) t.height(x, z); }

    @Override public void cover(double x, double z, float[] o) {
        double y = t.height(x, z);
        Siedlung s = v.siedlung;
        if (y < 0.25 || t.sourceAt(x, z) == Terrain.BACH || Vegetation.map(v.reed, x, z) > 0.3 || (s != null && s.blocked(x, z))) { java.util.Arrays.fill(o, 0); return; }
        double yard = s != null ? s.yard(x, z) : 0;
        double wood = Vegetation.map(v.wood, x, z), alder = Vegetation.map(v.alder, x, z), forest = Math.min(1, wood + alder);
        double patch = Vegetation.fbm(x / 17.0 + 2.3, z / 17.0 - 8.1), patch2 = Vegetation.fbm(x / 7.0 - 1.1, z / 7.0 + 4.4);
        double shore = Vegetation.smooth(1.1, 0.35, y);
        o[0] = (float) (forest * (0.45 + 0.55 * Vegetation.smooth(0.4, 0.7, patch)) + alder * 0.4);
        o[1] = (float) ((1 - forest) * (1 - shore) * Math.max(0, patch2 * 1.6 - 0.75));
        o[2] = (float) (0.06 + shore * 0.3 + Math.max(0, patch * 1.5 - 1.1));
        o[3] = (float) (forest * 0.85 * (1 - alder * 0.5));
        o[4] = (float) Math.min(1, alder + shore + Vegetation.smooth(2.0, 0.6, y) * 0.5);
        // Phase 5: auf dem zertretenen Hofboden kaum Pflanzen, dafür Steine und offene Erde
        o[0] *= (float) (1 - 0.8 * yard);
        o[1] *= (float) (1 - yard);
        o[2] = (float) Math.min(1, o[2] + 0.4 * yard);
        o[3] = (float) Math.min(1, o[3] + 0.5 * yard);
    }
}
