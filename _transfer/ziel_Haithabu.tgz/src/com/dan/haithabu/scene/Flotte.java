package com.dan.haithabu.scene;

import com.dan.buoyancy.Floater;
import com.dan.longship.Longship;
import com.dan.longship.ShipType;
import com.dan.ocean.HullMask;
import com.dan.ocean.Ocean;
import com.dan.spray.Body;
import com.dan.spray.Spray;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Phase 9: die Schiffe im Hafen. Ein Langschiff (Haithabu 1) liegt an der dritten Brücke, ein Faering im Süden, eine
 * Knorr an einem Querkopf; die zweite Knorr kommt auf Wunsch von draußen herein: sie segelt aus dem Noor heran,
 * birgt vor der Durchfahrt das Segel, rudert durch die Lücke der Palisade und legt am Querkopf der vierten Brücke an.
 * <p>
 * Wie: Fahrt, Kurs, Segel und Riemen rechnet {@code com.dan.longship}; Tauchen, Stampfen und Rollen kommen aus
 * {@code com.dan.buoyancy} (Säulen des Rumpfs gegen die Höhe des Noors aus {@code com.dan.ocean}). Kielwasser und
 * Riemenschläge laufen als Ringwellen ins Noor, beim Einsetzen der Blätter spritzt es ({@code com.dan.spray}, F22).
 * Der Umriss jedes Rumpfs in der Wasserlinie hält das Wasser aus den offenen Booten ({@link HullMask}).
 * <p>
 * Belegt: Typen und Maße (Haithabu 1, Skuldelev, Haithabu 3 als Knorr), Liegen längsseits an Brücken. Gestaltet [G]:
 * Liegeplätze, der Weg der Knorr, Zahl der Schiffe; die Funde sind jünger als 950 (um 985 und 1023).
 */
public final class Flotte {
    /** Ein Liegeplatz: Mitte des Schiffs und Kurs, mit dem es festmacht. */
    public record Liegeplatz(double x, double z, double heading) { }

    public final List<Longship> ships = new ArrayList<>();
    public final Longship einlaeufer, langschiff, faering, knorr;
    /** Phase 13: die Fischerboote an den Brücken. */
    public final List<Longship> fischer = new ArrayList<>();
    /**
     * Phase 15: der Brander der Nacht von 1050, ein Langschiff wie Haithabu 1 (das 990 bis 1010 selbst als Brander
     * in den Hafen trieb). Nicht in {@link #ships}; er fährt und wird gezeichnet, solange {@link #branderOn} ist.
     */
    public final Longship brander = new Longship(ShipType.LANGSCHIFF, "Brander");
    public volatile boolean branderOn;
    /** Treibt der Brander (die Mannschaft ist von Bord)? Dann schiebt ihn der Wind; fest, wenn er anstößt. */
    public volatile boolean branderAdrift, branderAground;
    private Terrain terrain;
    private Hafen hafen;
    public final Liegeplatz platzEin, platzLang, platzFaering, platzKnorr;
    /** Weg der einlaufenden Knorr: Start (x, z, Kurs) und der Punkt vor der Durchfahrt, an dem sie das Segel birgt. */
    public final double[] start, bergen;
    /** Mitte der Durchfahrt und Richtung nach draußen. */
    public final double[] lucke, aussen;
    private final Map<Longship, Floater> floaters = new IdentityHashMap<>();
    /** Spritzer der Riemen (nur von Hand ausgelöste Schwälle, keine Körper). */
    public final Spray spray = Spray.calm();
    private final Terrain t;
    private Ocean ocean;
    /** Phase der einlaufenden Knorr (Text für HUD und Bedienfeld). */
    private final String[] PHASE = {"segelt an", "birgt das Segel", "rudert durch die Durchfahrt", "legt an"};
    private boolean arriving;
    public long splashes;
    /** Phase 14: jeder Ruderschlag eines Schiffs (für den Klang): Schiff, Ort, Lautstärke 0..1. */
    @FunctionalInterface public interface Stroke { void at(Longship s, double x, double y, double z, double loudness); }
    public volatile Stroke onStroke;

    private Flotte(Terrain t, Hafen h) {
        this.t = t;
        // Durchfahrt: Mitte und Richtung nach draußen aus den Enden der Palisade
        double[][] a = h.palisade.get(0), b = h.palisade.get(1);
        double[] pa = a[a.length - 1], pb = b[0];
        lucke = h.durchfahrt.clone();
        double tx = pb[0] - pa[0], tz = pb[1] - pa[1], tl = Math.hypot(tx, tz);
        double nx = tz / tl, nz = -tx / tl;
        // nach draußen: weg vom Ufer (Bachmund bei 0, 0)
        if (nx * (lucke[0]) + nz * (lucke[1]) < 0) { nx = -nx; nz = -nz; }
        aussen = new double[]{nx, nz};
        bergen = new double[]{lucke[0] + nx * 75, lucke[1] + nz * 75};
        // Start draußen im Noor, gut 200 m vor der Durchfahrt, schräg vom Wallende weg [G]
        start = new double[]{lucke[0] + nx * 120 - 110, lucke[1] + nz * 120 - 80, 0};
        start[2] = Longship.bearing(bergen[0] - start[0], bergen[1] - start[1]);

        Hafen.Bruecke kopf = null, kopf2 = null;
        for (Hafen.Bruecke br : h.bruecken) if (br.querkopf()) { if (kopf == null || br.z1() < kopf.z1()) kopf = br; }
        for (Hafen.Bruecke br : h.bruecken) if (br.querkopf() && br != kopf) { if (kopf2 == null || br.z1() < kopf2.z1()) kopf2 = br; }
        if (kopf2 == null) kopf2 = kopf;
        platzEin = amKopf(kopf, ShipType.KNORR, false);
        platzKnorr = amKopf(kopf2, ShipType.KNORR, true);
        // Langschiff längsseits an der dritten Brücke von Norden (südliche Seite), Faering an der zweiten von Süden
        List<Hafen.Bruecke> nord = new ArrayList<>(), sued = new ArrayList<>();
        for (Hafen.Bruecke br : h.bruecken) (br.z0() < 0 ? nord : sued).add(br);
        nord.sort((p, q) -> Double.compare(p.z0(), q.z0()));
        sued.sort((p, q) -> Double.compare(q.z0(), p.z0()));
        Hafen.Bruecke bl = pick(nord, 3, kopf, kopf2), bf = pick(sued, 2, kopf, kopf2);
        platzLang = laengsseits(bl, ShipType.LANGSCHIFF, 1, ShipType.LANGSCHIFF.length / 2 + 1);
        platzFaering = laengsseits(bf, ShipType.FAERING, 1, 9);

        einlaeufer = new Longship(ShipType.KNORR, "Knorr");
        knorr = new Longship(ShipType.KNORR, "Knorr am Querkopf");
        langschiff = new Longship(ShipType.LANGSCHIFF, "Langschiff");
        faering = new Longship(ShipType.FAERING, "Faering");
        einlaeufer.mooredAt(platzEin.x, platzEin.z, platzEin.heading);
        knorr.mooredAt(platzKnorr.x, platzKnorr.z, platzKnorr.heading);
        langschiff.mooredAt(platzLang.x, platzLang.z, platzLang.heading);
        faering.mooredAt(platzFaering.x, platzFaering.z, platzFaering.heading);
        ships.add(einlaeufer);
        if (kopf2 != kopf) ships.add(knorr);
        ships.add(langschiff);
        ships.add(faering);
        // Phase 13: Fischerboote (Faeringe) längsseits an weiteren Brücken; sie dümpeln an der Vertäuung
        List<Hafen.Bruecke> rest = new ArrayList<>();
        for (Hafen.Bruecke br : h.bruecken) if (br != kopf && br != kopf2 && br != bl && br != bf) rest.add(br);
        for (int i = 0; i < Math.min(3, rest.size()); i++) {
            Hafen.Bruecke br = rest.get(i);
            Liegeplatz lp = laengsseits(br, ShipType.FAERING, i % 2 == 0 ? -1 : 1, 6 + 4 * i);
            Longship fb = new Longship(ShipType.FAERING, "Fischerboot " + (i + 1));
            fb.mooredAt(lp.x, lp.z, lp.heading);
            ships.add(fb);
            fischer.add(fb);
        }
        this.terrain = t;
        this.hafen = h;
        java.util.List<Longship> all = new ArrayList<>(ships);
        all.add(brander);
        brander.place(start[0], start[1], start[2]);
        for (Longship s : all) {
            s.externalPose = true;
            // Schwerpunkt knapp unter der Wasserlinie: Ballaststeine, Ladung, Besatzung tief im Boot [G]; sonst kentert das schlanke Langschiff
            Floater f = new Floater(s.name, s.hull.columns, -s.type.draft * 0.1, s.type.length * 0.27, s.type.beam * 0.36);
            f.x = s.x; f.z = s.z; f.heading = s.heading;
            floaters.put(s, f);
            s.onWake = (x, z, st) -> { Ocean o = ocean; if (o != null) o.addImpulse(x, z, st); };
            s.onStroke = (x, y, z, loud) -> {
                splash(s);
                Stroke l = onStroke;
                if (l != null) l.at(s, x, y, z, loud);
            };
        }
        spray.quality = Spray.Quality.LOW;
        spray.seed = 950;
    }

    private static Hafen.Bruecke pick(List<Hafen.Bruecke> l, int i, Hafen.Bruecke... not) {
        for (int k = Math.min(i, l.size() - 1); k >= 0; k--) {
            Hafen.Bruecke b = l.get(k);
            boolean ok = true;
            for (Hafen.Bruecke n : not) ok &= b != n;
            if (ok) return b;
        }
        return l.get(0);
    }

    /** Längsseits an einer Brücke, Bug zum Land, fh m vom Kopf, Seite +1 rechts der Brücke (vom Land gesehen). */
    static Liegeplatz laengsseits(Hafen.Bruecke b, ShipType ty, int side, double fh) {
        double l = b.length(), ux = (b.x1() - b.x0()) / l, uz = (b.z1() - b.z0()) / l;
        double off = b.width() / 2 + ty.beam / 2 + 0.5;
        double cx = b.x1() - ux * fh + (-uz) * side * off, cz = b.z1() - uz * fh + ux * side * off;
        return new Liegeplatz(cx, cz, Longship.bearing(-ux, -uz));
    }

    /** Vor dem Querkopf einer Brücke (seewärts, parallel dazu); nach Süden oder Norden fahrend. */
    static Liegeplatz amKopf(Hafen.Bruecke b, ShipType ty, boolean north) {
        double l = b.length(), ux = (b.x1() - b.x0()) / l, uz = (b.z1() - b.z0()) / l;
        double off = ty.beam / 2 + 0.6;
        double qx = -uz, qz = ux;                // quer zur Brücke
        if (qz < 0 ^ north) { qx = -qx; qz = -qz; }
        return new Liegeplatz(b.x1() + ux * off, b.z1() + uz * off, Longship.bearing(qx, qz));
    }

    /** Baut die Flotte zum Hafen; null ohne Hafen. */
    public static Flotte of(Terrain t, Hafen h) {
        if (h == null || h.palisade.size() < 2 || h.durchfahrt == null) return null;
        int heads = 0;
        for (Hafen.Bruecke b : h.bruecken) if (b.querkopf()) heads++;
        if (heads == 0) return null;
        return new Flotte(t, h);
    }

    // ------------------------------------------------------------------ Einlaufen

    /** Die Knorr von draußen hereinholen (von vorn, auch mitten in der Fahrt). */
    public void einlaufen(double windFromDeg, double windSpeed) {
        Longship k = einlaeufer;
        k.windFromDeg = windFromDeg;
        k.windSpeed = windSpeed;
        k.place(start[0], start[1], start[2]);
        boolean sail = k.canSail(start[2]);
        k.sailSet = k.sailTarget = sail ? 1 : 0;
        commands(k);
        Floater f = floaters.get(k);
        f.x = k.x; f.z = k.z; f.heading = k.heading;
        f.vy = f.vPitch = f.vRoll = 0;
        arriving = true;
    }

    /** Die Befehle der Einfahrt (auch für die Prüfung). */
    void commands(Longship k) {
        k.commands.add(Longship.Command.sailTo(bergen[0], bergen[1], 12));
        k.commands.add(Longship.Command.sail(0));
        k.commands.add(Longship.Command.passThrough(lucke[0], lucke[1], Longship.bearing(-aussen[0], -aussen[1])));
        k.commands.add(Longship.Command.moor(platzEin.x, platzEin.z, platzEin.heading));
    }

    /** „segelt an“ … „fest an der Brücke“, oder null, wenn sie nicht einläuft. */
    public String phase() {
        if (!arriving) return null;
        Longship k = einlaeufer;
        if (k.mode == Longship.Mode.FEST && k.commands.isEmpty()) return "fest am Querkopf";
        int i = PHASE.length - k.commands.size();
        return i >= 0 && i < PHASE.length ? PHASE[i] : "fährt";
    }

    public boolean arriving() { return arriving && !(einlaeufer.mode == Longship.Mode.FEST && einlaeufer.commands.isEmpty()); }

    // ------------------------------------------------------------------ Phase 15: Auslaufen, Brander

    /** Ist die Knorr draußen (ausgelaufen und noch nicht wieder eingelaufen)? */
    public volatile boolean knorrAway;

    /** Die Knorr legt ab, rudert durch die Durchfahrt hinaus, setzt Segel und fährt zum Start draußen im Noor. */
    public void auslaufen(double windFromDeg, double windSpeed) {
        Longship k = einlaeufer;
        k.windFromDeg = windFromDeg;
        k.windSpeed = windSpeed;
        k.commands.clear();
        double ix = lucke[0] - aussen[0] * 25, iz = lucke[1] - aussen[1] * 25;
        k.commands.add(Longship.Command.rowTo(ix, iz, 6));
        k.commands.add(Longship.Command.passThrough(lucke[0], lucke[1], Longship.bearing(aussen[0], aussen[1])));
        k.commands.add(Longship.Command.rowTo(bergen[0], bergen[1], 10));
        k.commands.add(Longship.Command.sail(1));
        k.commands.add(Longship.Command.sailTo(start[0], start[1], 20));
        arriving = false;
        knorrAway = true;
    }

    /** Läuft die Knorr gerade aus (Befehle offen, nicht fest)? */
    public boolean leaving() { return knorrAway && !einlaeufer.commands.isEmpty(); }

    /**
     * Den Brander draußen vor der Palisade setzen: die Mannschaft rudert ihn auf die Durchfahrt zu und hindurch, dann
     * verlässt sie ihn ({@link #branderAdrift}); von da an treibt er mit dem Wind (8 % der Windgeschwindigkeit, ein
     * brennender Rumpf mit hohem Steven bietet viel Fläche, dazu der Rest der Fahrt), bis er an eine Brücke, einen Pfahl oder das Ufer stößt [G].
     */
    public void branderStart() {
        Longship b = brander;
        b.commands.clear();
        double ox = lucke[0] + aussen[0] * 140, oz = lucke[1] + aussen[1] * 140;
        b.place(ox, oz, Longship.bearing(-aussen[0], -aussen[1]));
        Floater f = floaters.get(b);
        f.x = b.x; f.z = b.z; f.heading = b.heading;
        f.vy = f.vPitch = f.vRoll = 0;
        // geradeaus auf der Achse der Durchfahrt hinein und ein Stück ins Becken, dann geht die Mannschaft von Bord
        b.commands.add(Longship.Command.passThrough(lucke[0], lucke[1], Longship.bearing(-aussen[0], -aussen[1])));
        b.commands.add(Longship.Command.rowTo(lucke[0] - aussen[0] * 60, lucke[1] - aussen[1] * 60, 10));
        b.speed = 1.5;
        branderOn = true;
        branderAdrift = branderAground = false;
    }

    /** Alle Schiffe, die gezeichnet werden (mit dem Brander, wenn er fährt). */
    public List<Longship> drawn() {
        if (!branderOn) return ships;
        List<Longship> l = new ArrayList<>(ships);
        l.add(brander);
        return l;
    }

    /** Der Brander treibt: Wind schiebt ihn, an Brücken, Pfählen und dem Ufer bleibt er hängen. */
    private void drift(double h, double windFromDeg, double windSpeed) {
        Longship b = brander;
        if (!branderAdrift && b.commands.isEmpty() && b.mode != Longship.Mode.FEST) {
            branderAdrift = true;
            b.mode = Longship.Mode.TREIBEN;
        }
        if (!branderAdrift || branderAground) return;
        double to = Math.toRadians(windFromDeg + 180);
        // die Restfahrt rechnet das Schiff selbst (sie klingt ab), hier nur der Wind
        double[] f = b.forward();
        double vx = Math.sin(to) * windSpeed * 0.08, vz = -Math.cos(to) * windSpeed * 0.08;
        double nx = b.x + vx * h, nz = b.z + vz * h;
        if (hits(b, nx + f[0] * b.speed * h, nz + f[1] * b.speed * h)) { branderAground = true; b.speed = 0; return; }
        b.x = nx;
        b.z = nz;
        // der Wind dreht ihn langsam quer
        double want = Longship.bearing(Math.sin(to), -Math.cos(to)) + 90;
        double d = ((want - b.heading) % 360 + 540) % 360 - 180;
        if (Math.abs(d) > 90) d = d > 0 ? d - 180 : d + 180;
        b.heading = (b.heading + Math.max(-1, Math.min(1, d)) * h * 2 + 360) % 360;
    }

    /** Stößt der Brander an der Stelle an (Grund, Brückenköpfe, Pfähle)? */
    boolean hits(Longship b, double x, double z) {
        double hl = b.hull.halfLength * 0.9;
        double[] f = b.forward();
        for (double u = -1; u <= 1.01; u += 0.5) {
            double px = x + f[0] * hl * u, pz = z + f[1] * hl * u;
            if (terrain != null && terrain.height(px, pz) > -0.9) return true;
            if (hafen != null) {
                for (Hafen.Bruecke br : hafen.bruecken) if (segDist(px, pz, br.x0(), br.z0(), br.x1(), br.z1()) < br.width() / 2 + b.type.beam / 2) return true;
            }
        }
        return false;
    }

    static double segDist(double px, double pz, double ax, double az, double bx, double bz) {
        double dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz;
        double t = l2 < 1e-9 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (pz - az) * dz) / l2));
        return Math.hypot(px - ax - dx * t, pz - az - dz * t);
    }

    // ------------------------------------------------------------------ je Bild

    /** Fahrt, Schwimmlage, Spritzer um dt weiter; Wind aus der Regie. */
    public void step(double dt, Ocean o, double windFromDeg, double windSpeed) {
        if (dt <= 0) return;
        ocean = o;
        com.dan.buoyancy.Sea sea = new com.dan.buoyancy.Sea() {
            @Override public double height(double x, double z) { return o.heightAt(x, z); }
            @Override public double[] velocity(double x, double z) { return new double[]{0, o.verticalVelocityAt(x, z), 0}; }
            @Override public double level() { return o.waterLevel; }
        };
        double h = Math.min(dt, 0.1);
        List<Longship> moving = branderOn ? drawn() : ships;
        if (branderOn) drift(h, windFromDeg, windSpeed);
        for (Longship s : moving) {
            s.windFromDeg = windFromDeg;
            s.windSpeed = windSpeed;
            s.step(h);
            Floater f = floaters.get(s);
            f.x = s.x; f.z = s.z; f.heading = s.heading;
            f.sample(sea);
            f.integrate(h);
            s.y = f.y; s.pitch = f.pitch; s.roll = f.roll;
        }
        spray.windFromDeg = windFromDeg;
        spray.windSpeed = windSpeed;
        spray.waveHeight = Math.max(0.1, o.state().totalHs());
        spray.sea = new com.dan.spray.Sea() {
            @Override public double height(double x, double z) { return o.heightAt(x, z); }
            @Override public double[] velocity(double x, double z) { return o.velocityAt(x, z); }
            @Override public double level() { return o.waterLevel; }
        };
        spray.step(h);
        List<HullMask> m = new ArrayList<>();
        for (Longship s : moving) m.add(mask(s));
        o.hulls = m;
    }

    /** Spritzer an jedem Blatt beim Einsetzen (F22: Riemenspritzer). */
    private void splash(Longship s) {
        Ocean o = ocean;
        if (o == null) return;
        double jet = 0.25 + 0.15 * Math.min(1, s.speed / 2);
        for (double[] b : s.oarBlades()) {
            double wy = o.heightAt(b[0], b[2]);
            Body body = Body.cylinder(b[0], b[2], 0.06, wy - 0.3, wy + 0.3);
            double az = Math.toRadians(s.heading + b[3] * 90);
            spray.splash(body, az, wy, jet);
            splashes++;
        }
    }

    /**
     * Umriss in der Wasserlinie: Halbbreite und Völligkeit so, dass er nirgends mehr als 1 cm über den Rumpf hinausgeht
     * (sonst bliebe außen ein Spalt zum Wasser) und ihm sonst möglichst dicht folgt (je Typ einmal gesucht).
     */
    public static HullMask mask(Longship s) {
        double[] f = FIT.computeIfAbsent(s.type, ty -> fit(s.hull));
        return new HullMask(s.x, s.z, s.heading, f[0], f[1], f[2]);
    }

    private static final Map<ShipType, double[]> FIT = new java.util.concurrent.ConcurrentHashMap<>();

    static double[] fit(com.dan.longship.Hull h) {
        double hl = h.halfLength * 0.98, hb = h.halfBreadthAt(0, 0) * 0.99;
        double lo = 1.5, hi = 8;
        for (int it = 0; it < 30; it++) {
            double p = (lo + hi) / 2, over = 0;
            for (double u = 0; u < 1; u += 0.01) {
                double lens = hb * Math.pow(1 - Math.pow(u, p), 0.8);
                over = Math.max(over, lens - h.halfBreadthAt(u * hl, 0));
            }
            if (over <= 0.01) lo = p; else hi = p;
        }
        return new double[]{hl, hb, lo};
    }

    public Floater floater(Longship s) { return floaters.get(s); }

    /** Auge der Mitfahrt: am Steuer der einlaufenden Knorr {x, y, z, Kurs}. */
    public double[] mitfahrt() {
        Longship k = einlaeufer;
        double[] p = k.toWorld(-k.hull.halfLength * 0.78, 0.9, k.type.freeboard + k.type.sheer * 0.5 + 1.65);
        return new double[]{p[0], p[1], p[2], k.heading};
    }

    /** „4 Schiffe · Knorr segelt an · Langschiff fest …“ */
    public String describe() {
        StringBuilder sb = new StringBuilder(String.format(Locale.GERMAN, "Schiffe: %d", ships.size()));
        String ph = phase();
        sb.append(ph != null ? " · Knorr " + ph + String.format(Locale.GERMAN, " (%.1f m/s, Segel %.0f %%)", einlaeufer.speed, einlaeufer.sailSet * 100) : " · Knorr am Liegeplatz (9 oder „Knorr einlaufen“)");
        return sb.toString();
    }
}
