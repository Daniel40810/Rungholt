package com.dan.haithabu.scene;

import com.dan.flock.Flock;
import com.dan.flock.Species;
import com.dan.herd.Herd;
import com.dan.timber.House;
import com.dan.timber.HouseType;
import com.dan.timber.Timber;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Phase 13: die Tiere in Haithabu. Vögel ({@code com.dan.flock}) über Hafen und Noor, Haustiere ({@code com.dan.herd})
 * in den Höfen und am Hang. Hier steht, wo sie leben [G]:
 * <ul>
 * <li>Möwen über dem Hafen; sie sitzen auf den Pfählen der Hafenpalisade und an den Brückenköpfen und schwimmen im
 * Becken. Kormorane sitzen ebenfalls auf der Palisade (Flügel zum Trocknen gespreizt) und tauchen im Noor.</li>
 * <li>Stockenten und Höckerschwäne in flachem Wasser am Ufer und im Hafenbecken, wo kein Eis liegt.</li>
 * <li>Krähen auf den Feldern vor dem Wall und den Weiden am Hang, auf Firsten der Häuser; Schwalben im Sommer tief über
 * dem Wasser am Ufer.</li>
 * <li>Hühner in Höfen am Bach (zwischen den Häusern, nie in einem Haus), Ziegen auf einer Weide am Hang unterhalb des
 * Walls (von „Vom Wall“ zu sehen), Schweine in Pferchen am oberen Rand der Siedlung, ein Hund auf der
 * Hafenplattform und einer in den Gassen.</li>
 * </ul>
 * Der Hund und das Auge stören die Vögel; nur das Auge stört die Haustiere.
 */
public final class Leben {
    public final Flock flock = new Flock();
    public final Herd herd = new Herd();
    private final Terrain t;
    private final Siedlung s;
    /** Häuser als Raster (1 m, um die Siedlung): kein Tier läuft durch eine Wand. */
    private final boolean[] blocked;
    /** Flächen der Hafenplattformen und Brücken (Polygone in x, z), auf denen der Hund läuft. */
    private final List<double[][]> decks = new ArrayList<>();
    private volatile double level, iceDepth;
    /** Höhe des Noors an einem Ort (vom Renderer, null = flacher Spiegel). */
    public volatile Flock.Ground waterHeight;
    /** Orte der Ansichten zum Prüfen (Weide der Ziegen, Hühnerhöfe). */
    public final double[] pasture = new double[3];

    private Leben(Terrain t, Siedlung s) {
        this.t = t;
        this.s = s;
        blocked = new boolean[Siedlung.NX * Siedlung.NZ];
        for (House h : s.houses) mark(h, 0.6);
        Hafen hf = s.hafen;
        if (hf != null) {
            decks.addAll(hf.plattformen);
            for (Hafen.Bruecke b : hf.bruecken) {
                double l = b.length(), ux = (b.x1() - b.x0()) / l, uz = (b.z1() - b.z0()) / l, w = b.width() / 2 - 0.3;
                decks.add(new double[][]{{b.x0() - uz * w, b.z0() + ux * w}, {b.x1() - uz * w, b.z1() + ux * w}, {b.x1() + uz * w, b.z1() - ux * w}, {b.x0() + uz * w, b.z0() - ux * w}});
            }
        }
        setupFlock();
        setupHerd();
    }

    /** Die Tiere zur Siedlung (mit Hafen) bauen. */
    public static Leben of(Terrain t, Siedlung s) { return new Leben(t, s); }

    private void mark(House h, double margin) {
        Timber.Box b = Timber.box(h);
        double hl = b.halfLength() + margin, hw = b.halfWidth() + margin, a = Math.toRadians(b.headingDeg()), sa = Math.sin(a), ca = Math.cos(a);
        double r = Math.hypot(hl, hw);
        for (int z = (int) Math.floor(b.z() - r); z <= (int) Math.ceil(b.z() + r); z++)
            for (int x = (int) Math.floor(b.x() - r); x <= (int) Math.ceil(b.x() + r); x++) {
                double dx = x + 0.5 - b.x(), dz = z + 0.5 - b.z();
                double along = dx * sa - dz * ca, across = dx * ca + dz * sa;
                if (Math.abs(along) > hl || Math.abs(across) > hw) continue;
                int i = (int) (x - Siedlung.X0), j = (int) (z - Siedlung.Z0);
                if (i >= 0 && j >= 0 && i < Siedlung.NX && j < Siedlung.NZ) blocked[j * Siedlung.NX + i] = true;
            }
    }

    /** Für die Prüfung: liegt der Ort in einem Haus? */
    public boolean blockedForTest(double x, double z) { return house(x, z); }

    boolean house(double x, double z) {
        int i = (int) Math.floor(x - Siedlung.X0), j = (int) Math.floor(z - Siedlung.Z0);
        return i >= 0 && j >= 0 && i < Siedlung.NX && j < Siedlung.NZ && blocked[j * Siedlung.NX + i];
    }

    static boolean inPoly(double[][] p, double x, double z) {
        boolean in = false;
        for (int i = 0, j = p.length - 1; i < p.length; j = i++)
            if ((p[i][1] > z) != (p[j][1] > z) && x < (p[j][0] - p[i][0]) * (z - p[i][1]) / (p[j][1] - p[i][1]) + p[i][0]) in = !in;
        return in;
    }

    boolean onDeck(double x, double z) {
        for (double[][] d : decks) if (inPoly(d, x, z)) return true;
        return false;
    }

    /** Höhe für Tiere am Boden: Gelände, auf Plattform und Brücken das Deck. */
    double animalGround(double x, double z) {
        if (onDeck(x, z)) return level + Hafen.DECK;
        return t.height(x, z);
    }

    /** Offenes Wasser: tiefer als 25 cm, nicht unter einer Brücke, ohne Eis. */
    double water(double x, double z) {
        double depth = level - t.height(x, z);
        if (depth < 0.25 || depth < iceDepth || onDeck(x, z)) return Double.NaN;
        Flock.Ground w = waterHeight;
        return w != null ? w.height(x, z) : level;
    }

    // ------------------------------------------------------------------ Vögel

    private void setupFlock() {
        Flock f = flock;
        f.seed = 950;
        f.quality = Flock.Quality.HIGH;
        f.homeX = 45; f.homeZ = -70; f.homeRadius = 170;
        f.coastDeg = 70;
        f.ground = (x, z) -> Math.max(t.height(x, z), level);
        f.water = this::water;
        Hafen hf = s.hafen;
        if (hf != null) {
            // Pfähle der Hafenpalisade: jeder zweite Punkt der Linie ein Sitzplatz
            int k = 0;
            for (double[][] pal : hf.palisade)
                for (int i = 0; i < pal.length; i += 2) {
                    double[] p = pal[i];
                    final double px = p[0], pz = p[1];
                    Flock.Perch pe = new Flock.Perch("Palisade " + (k++), () -> new double[]{px, level + Hafen.PALISADE_TOP + Flock.legHeight(Species.MOEWE), pz});
                    f.perches.add(pe.only(Species.MOEWE, Species.KORMORAN, Species.KRAEHE));
                }
            // Pfosten an den Brücken (alle 2,5 m einer, Oberkante 0,3 bis 0,5 m über dem Deck): seit Phase 14 jeder
            // zweite ein Platz, beliebter als die Palisade (Befund Phase 13: auf den Pfosten der Brücke saß keiner)
            for (Hafen.Bruecke b : hf.bruecken) {
                double l = b.length(), ux = (b.x1() - b.x0()) / l, uz = (b.z1() - b.z0()) / l, off = b.width() / 2 - 0.15;
                for (double a0 = 5; a0 < l - 2; a0 += 5) {
                    int sd = ((int) (a0 / 5)) % 2 == 0 ? 1 : -1;
                    final double px = b.x0() + ux * a0 - uz * off * sd, pz = b.z0() + uz * a0 + ux * off * sd;
                    f.perches.add(new Flock.Perch("Brückenpfosten", () -> new double[]{px, level + Hafen.DECK + 0.05 + 0.4 + Flock.legHeight(Species.MOEWE), pz})
                            .only(Species.MOEWE, Species.KORMORAN).appeal(4));
                }
            }
            // Ecken der Brückenköpfe
            for (Hafen.Bruecke b : hf.bruecken) {
                double l = b.length(), ux = (b.x1() - b.x0()) / l, uz = (b.z1() - b.z0()) / l, w = b.width() / 2;
                for (int sd = -1; sd <= 1; sd += 2) {
                    final double px = b.x1() - ux * 0.3 - uz * w * sd, pz = b.z1() - uz * 0.3 + ux * w * sd;
                    f.perches.add(new Flock.Perch("Brücke", () -> new double[]{px, level + Hafen.DECK + 0.1 + Flock.legHeight(Species.MOEWE), pz}).only(Species.MOEWE));
                }
            }
            // Wasser im Hafenbecken und davor
            f.waters.add(new Flock.Area(40, -100, 22));
            f.waters.add(new Flock.Area(55, -105, 28));
            f.waters.add(new Flock.Area(75, -55, 35));
            f.waters.add(new Flock.Area(70, 30, 35));
            f.waters.add(new Flock.Area(90, 80, 35));
            f.waters.add(new Flock.Area(50, -160, 30));
        }
        f.waters.add(new Flock.Area(230, -40, 80));
        // Firste der Häuser nah am Ufer (Krähen und Möwen)
        Random r = new Random(13);
        int ridges = 0;
        for (House h : s.houses) {
            if (ridges >= 40 || h.x() < -260 || r.nextDouble() > 0.5) continue;
            HouseType ty = h.type();
            if (ty == HouseType.GRUBENHAUS) continue;
            double a = Math.toRadians(h.headingDeg()), half = ty.length * h.lengthScale() / 2 * 0.85, ry = h.y() + ty.ridgeY() + 0.25;
            for (int sd = -1; sd <= 1; sd += 2) {
                final double px = h.x() + Math.sin(a) * half * sd, pz = h.z() - Math.cos(a) * half * sd;
                f.perches.add(new Flock.Perch("First", px, ry + Flock.legHeight(Species.KRAEHE), pz).only(Species.KRAEHE, Species.MOEWE));
            }
            ridges++;
        }
        // Krähen: Felder vor dem Wall (Westen) und Weide am Hang
        f.feeding.add(new Flock.Area(Siedlung.WALL_CX - 393 - 140, Siedlung.WALL_CZ - 60, 60));
        f.feeding.add(new Flock.Area(Siedlung.WALL_CX - 393 - 160, Siedlung.WALL_CZ + 120, 50));
        int[] m = new int[Species.values().length];
        m[Species.KRAEHE.ordinal()] = 10;
        m[Species.SCHWALBE.ordinal()] = 16;
        m[Species.ENTE.ordinal()] = 22;
        m[Species.SCHWAN.ordinal()] = 4;
        m[Species.KORMORAN.ordinal()] = 6;
        f.mix = m;
    }

    // ------------------------------------------------------------------ Haustiere

    /** Freier Platz: an Land, kein Haus, nicht zu steil. */
    boolean free(double x, double z) {
        if (house(x, z)) return false;
        if (onDeck(x, z)) return true;
        double h = t.height(x, z);
        if (h < level + 0.2) return false;
        double sl = Math.abs(t.height(x + 1, z) - t.height(x - 1, z)) / 2 + Math.abs(t.height(x, z + 1) - t.height(x, z - 1)) / 2;
        return sl < 0.45;
    }

    /** Anteil freier Punkte in einem Kreis (Raster 2 m). */
    double freeShare(double cx, double cz, double r) {
        int n = 0, ok = 0;
        for (double z = cz - r; z <= cz + r; z += 2)
            for (double x = cx - r; x <= cx + r; x += 2) {
                if (Math.hypot(x - cx, z - cz) > r) continue;
                n++;
                if (free(x, z)) ok++;
            }
        return n == 0 ? 0 : ok / (double) n;
    }

    /** Bester freier Kreis nahe (px, pz) im Umkreis reach. */
    double[] bestSpot(double px, double pz, double reach, double r, double minShare) {
        double best = -1e9;
        double[] b = null;
        for (double z = pz - reach; z <= pz + reach; z += 6)
            for (double x = px - reach; x <= px + reach; x += 6) {
                double sh = freeShare(x, z, r);
                if (sh < minShare) continue;
                double sc = sh * 10 - Math.hypot(x - px, z - pz) / reach * 3;
                if (sc > best) { best = sc; b = new double[]{x, z}; }
            }
        return b;
    }

    private void setupHerd() {
        Herd h = herd;
        h.seed = 950;
        h.ground = this::animalGround;
        h.walkable = this::free;
        // Ziegen am Hang unterhalb des Walls, im Blick von „Vom Wall“ (−560, −103, Blick nach Osten)
        double[] g1 = bestSpot(-525, -100, 24, 15, 0.9);
        if (g1 != null) { h.pens.add(new Herd.Pen("Weide am Hang", Herd.Kind.ZIEGE, g1[0], g1[1], 16, 7)); pasture[0] = g1[0]; pasture[2] = g1[1]; pasture[1] = t.height(g1[0], g1[1]); }
        double[] g2 = bestSpot(-480, 60, 50, 14, 0.85);
        if (g2 != null) h.pens.add(new Herd.Pen("Weide am Nordhang", Herd.Kind.ZIEGE, g2[0], g2[1], 14, 5));
        // Schweine: zwei Pferche am oberen Rand
        double[] p1 = bestSpot(-450, -230, 50, 7, 0.9), p2 = bestSpot(-430, 150, 50, 7, 0.9);
        if (p1 != null) h.pens.add(new Herd.Pen("Pferch Süd", Herd.Kind.SCHWEIN, p1[0], p1[1], 7, 4));
        if (p2 != null) h.pens.add(new Herd.Pen("Pferch Nord", Herd.Kind.SCHWEIN, p2[0], p2[1], 7, 3));
        // Hühner in Höfen am Bach, nahe der Ansicht „Am Bach“ (−166, −16)
        double[][] yards = {{-145, -6}, {-136, -30}, {-150, -40}, {-130, 10}, {-190, 20}, {-210, -45}, {-110, -60}, {-170, -80}, {-240, 5}, {-95, 25}, {-260, -60}, {-120, 60}};
        int y = 0;
        for (double[] c : yards) {
            double[] sp = bestSpot(c[0], c[1], 18, 5, 0.75);
            if (sp != null) h.pens.add(new Herd.Pen("Hof " + (++y), Herd.Kind.HUHN, sp[0], sp[1], 5, 5 + (y % 3)));
        }
        // Hund auf der Hafenplattform: Wegpunkte auf den Decks
        Hafen hf = s.hafen;
        if (hf != null && !hf.plattformen.isEmpty()) {
            List<double[]> wp = new ArrayList<>();
            double[][] pl = hf.plattformen.get(0);
            for (int i = 0; i < pl.length; i += Math.max(1, pl.length / 6)) {
                // ein wenig zur Mitte der Plattform
                double cx = 0, cz = 0;
                for (double[] q : pl) { cx += q[0]; cz += q[1]; }
                cx /= pl.length; cz /= pl.length;
                double x = pl[i][0] + (cx - pl[i][0]) * 0.3, z = pl[i][1] + (cz - pl[i][1]) * 0.3;
                if (onDeck(x, z) || free(x, z)) wp.add(new double[]{x, z});
            }
            for (Hafen.Bruecke b : hf.bruecken) if (wp.size() < 10) wp.add(new double[]{b.x0() + (b.x1() - b.x0()) * 0.3, b.z0() + (b.z1() - b.z0()) * 0.3});
            if (wp.size() >= 2) {
                double[] c = wp.get(0);
                h.pens.add(new Herd.Pen("Hafen", Herd.Kind.HUND, c[0], c[1], 80, 1, wp));
            }
        }
        // ein Hund in den Gassen am Bach
        List<double[]> town = new ArrayList<>();
        for (double[] c : yards) { double[] sp = bestSpot(c[0], c[1], 10, 2, 0.9); if (sp != null) town.add(sp); }
        if (town.size() >= 2) h.pens.add(new Herd.Pen("Gassen", Herd.Kind.HUND, town.get(0)[0], town.get(0)[1], 200, 1, town));
    }

    // ------------------------------------------------------------------ je Bild

    /**
     * Ein Schritt: Auge und Hunde stören, Licht, Wind, Wetter und Jahr. dt in Szenenzeit (Zeitraffer), höchstens 3 s.
     */
    public void step(double dt, double[] eye, double sunAltDeg, double lux, double windSpeed, double windFromDeg, double rain, double snow,
                     int doy, double waterLevel, double ice, List<double[]> boats) {
        level = waterLevel;
        iceDepth = ice;
        flock.windSpeed = windSpeed;
        flock.windFromDeg = windFromDeg;
        flock.ambientLux = lux;
        flock.dayOfYear = doy;
        List<double[]> d = new ArrayList<>();
        d.add(eye.clone());
        for (Herd.Animal a : herd.animals()) if (a.kind == Herd.Kind.HUND && a.state != Herd.State.AWAY) d.add(new double[]{a.pos[0], a.pos[1] + 0.5, a.pos[2]});
        if (boats != null) d.addAll(boats);
        flock.disturbers.clear();
        flock.disturbers.addAll(d);
        herd.disturbers.clear();
        herd.disturbers.add(eye.clone());
        herd.sunAltDeg = sunAltDeg;
        herd.rain = rain;
        herd.snow = snow;
        flock.step(dt);
        herd.step(dt);
    }

    /** „Vögel: …“ */
    public String birdLine() { return "Vögel " + flock.describe(); }

    /** „Tiere: …“ */
    public String animalLine() {
        return String.format(Locale.GERMAN, "Haustiere %s · %d Gehege", herd.describe(), herd.pens.size());
    }
}
