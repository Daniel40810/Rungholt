package com.dan.haithabu.scene;

import com.dan.timber.House;
import com.dan.timber.HouseType;
import com.dan.timber.Structures;
import com.dan.timber.Timber;

import java.util.ArrayList;
import java.util.List;

/**
 * Phase 5: die sieben Häuser am Ufer, nach den Häusern des Wikinger Museums Haithabu [G in Maßen und Lage], an beiden
 * Seiten des Bachs unterhalb der Ansicht „Am Bach“. Die Grundstücke liegen quer zum Bach wie in der Grabung: schmale
 * Streifen, durch Zäune getrennt, die Giebel zum Bach und zu den Bohlenwegen an beiden Ufern; eine Brücke führt über
 * den Bach. Am Strand südlich der Mündung der Fischer mit Fischgestellen und Booten, zwischen den Höfen ein
 * Ziehbrunnen. Die Häuser sind Datensätze aus {@code com.dan.timber} (Typ, Streckung, Zustand); Phase 6 setzt den
 * Rest der Siedlung aus denselben Typen.
 * <p>
 * Dazu eine Karte zu 1 m um die Höfe: zertretener Hofboden (r) und Lehmboden in den Häusern (g) für das Gelände,
 * und {@link #blocked}, damit weder Halme noch Bodendecke durch Fußböden und Wege wachsen.
 */
public final class Siedlung {
    /** Ein Haus mit Namen und Rolle im Museum. */
    public record Haus(String name, String rolle, House house, boolean museum) { }

    /**
     * Phase 16: ein Weg, ein Zaun oder ein Garten als Linie oder Fläche (Szenenmeter), für den Lageplan in der
     * Datenbank (HB_WEG). Art: GASSE, BOHLENWEG, ZAUN oder GARTEN (Fläche, vier Ecken). Nur zum Lesen; gebaut wird
     * aus dem Startwert.
     */
    public record Weg(String art, double[][] punkte, double breite) { }

    public static final double X0 = -640, Z0 = -560, CELL = 1;
    public static final int NX = 900, NZ = 900;
    /** Phase 6: Mitte des Halbkreiswalls aus dem Gelände (Kreis durch den Wallkamm, gemessen im DGM) [gemessen]. */
    public static final double WALL_CX = -223, WALL_CZ = -139;
    /** Bogen des Walls: von Norden (−89°) über Westen bis Süden (57°), Winkel atan2(z, x) um die Mitte. */
    public static final double ARC_FROM = 57, ARC_TO = 271;
    /** Standpunkt der Ansicht „Vom Wall“ auf dem Wehrgang (Phase 7), frei von Häusern. */
    static final double[] VOM_WALL = {-560.5, -102.8};
    /** Halbmesser des Wallkamms je 2° Winkel (gemessen; Lücken der Tore überbrückt). */
    public final double[] wallR = new double[180];

    public final List<Haus> haeuser = new ArrayList<>();
    public final List<House> houses = new ArrayList<>();
    public final Structures.Set bauwerke = new Structures.Set();
    /** Hofboden und Hausboden je Zelle (0..255). */
    public final byte[] yard = new byte[NX * NZ], floor = new byte[NX * NZ], garden = new byte[NX * NZ];
    /** Startwert der übrigen Siedlung (Phase 6; Bedienfeld). */
    public final long seed;
    /** Gassen (Mittellinien) der übrigen Siedlung, für Prüfung und spätere Phasen. */
    public final List<double[][]> gassen = new ArrayList<>();
    /** Phase 16: Wege, Zäune und Gärten für den Lageplan (HB_WEG). */
    public final List<Weg> wege = new ArrayList<>();
    private final byte[] block = new byte[NX * NZ];
    /** Phase 7: der Wall aus dem Gelände (Kammlinie, Tore, Palisade); null auf der flachen Bühne. */
    public final Befestigung wall;
    /** Phase 8: der Hafen (Plattformen, Landebrücken, Palisade im Wasser, Waren); null ohne Wall. */
    public Hafen hafen;
    private final Terrain t;
    private final Structures.Ground ground;

    private Siedlung(Terrain t, long seed) {
        this.t = t;
        this.seed = seed;
        this.wall = t.befestigung;
        this.ground = (x, z) -> Math.max(t.height(x, z), -0.2);
    }

    /** Die Höfe am Bach von Haithabu um 950 [G]. */
    public static Siedlung haithabu(Terrain t) { return haithabu(t, 950); }

    /** Die Höfe am Bach und die übrige Siedlung im Wall aus dem Startwert seed [G]. */
    public static Siedlung haithabu(Terrain t, long seed) {
        Siedlung s = new Siedlung(t, seed);
        s.build();
        s.measureWall();
        s.generate();
        if (s.wall != null) s.wall.bauwerke(s.bauwerke, s.ground);
        s.hafen = Hafen.bauen(t, s);
        return s;
    }

    /** Die Mitte des Bachs bei x (z), aus dem Lauf im Gelände; 0 ohne Bach. */
    public double brookZ(double x) {
        double[][] b = t.brook;
        for (int i = 0; i + 1 < b.length; i++) {
            double x0 = b[i][0], x1 = b[i + 1][0];
            if ((x - x0) * (x - x1) <= 0 && x0 != x1) return b[i][1] + (b[i + 1][1] - b[i][1]) * (x - x0) / (x1 - x0);
        }
        return 0;
    }

    /** Wasserspiegel des Bachs bei x. */
    public double brookLevel(double x) {
        double[][] b = t.brook;
        for (int i = 0; i + 1 < b.length; i++) {
            double x0 = b[i][0], x1 = b[i + 1][0];
            if ((x - x0) * (x - x1) <= 0 && x0 != x1) return b[i][3] + (b[i + 1][3] - b[i][3]) * (x - x0) / (x1 - x0);
        }
        return 0;
    }

    private void build() {
        // Höfe nördlich des Bachs (Giebel nach Süden zum Bach), südlich (Giebel nach Norden); First quer zum Bach
        hof("Versammlungshaus", "Versammlungshaus des Museums, größtes Haus am Bach", HouseType.HALLE, -120, -1, 1.0, 0.86, 0.8, 7.5);
        hof("Herberge", "Gästehaus für Händler", HouseType.WOHNHAUS, -93, -1, 1.05, 1.0, 0.7, 7);
        hof("Haus des Kammmachers", "Werkstatt für Kämme aus Geweih", HouseType.WOHNHAUS, -68, -1, 0.85, 0.92, 0.85, 7);
        hof("Wohnhaus am Hang", "Wohnhaus aus Spaltbohlen", HouseType.BOHLENHAUS, -146, -1, 1.0, 1.0, 0.6, 7);
        hof("Haus des Tuchhändlers", "Händler für Tuch und Wolle", HouseType.WOHNHAUS, -113, 1, 1.12, 1.0, 0.75, 7);
        hof("Wohnhaus am Bach", "Wohnhaus nach Haus 1 (um 870)", HouseType.WOHNHAUS, -86, 1, 0.92, 0.95, 0.95, 7);
        hof("Haus des Fischers", "Fischer am Strand", HouseType.BOHLENHAUS, -56, 1, 0.95, 1.0, 0.9, 6.5);
        // Werkstatt des Kammmachers hinter seinem Haus, quer
        House kh = houses.get(2);
        House shed = new House(HouseType.SCHUPPEN, kh.x() + 1, 0, kh.z() - kh.length() / 2 - 5.5, 90, 0.9, 0.9, 0.75, 51);
        shed = onGround(shed);
        haeuser.add(new Haus("Werkstatt des Kammmachers", "offener Schuppen", shed, true));
        houses.add(shed);
        markHouse(shed);

        // Bohlenwege an beiden Ufern, eine Brücke
        for (int side = -1; side <= 1; side += 2) {
            double x0 = side < 0 ? -172 : -150, x1 = side < 0 ? -20 : -38;
            List<double[]> line = new ArrayList<>();
            for (double x = x0; x <= x1 + 0.1; x += 4) line.add(new double[]{x, brookZ(x) + side * 4.6});
            double[][] l = line.toArray(new double[0][]);
            bauwerke.walkway(l, 2.2, ground, 500 + side);
            markLine(l, 1.3, 2.5);
            wege.add(new Weg("BOHLENWEG", l, 2.2));
        }
        double bx = -101;
        double bz = brookZ(bx), level = brookLevel(bx);
        bauwerke.pier(new double[][]{{bx, bz - 5.5}, {bx, bz + 5.5}}, 2.0, level + 0.55, ground, 520);
        markLine(new double[][]{{bx, bz - 5.5}, {bx, bz + 5.5}}, 1.2, 1.5);

        // Zäune zwischen den Grundstücken, quer zum Bach, vom Weg bis hinter die Häuser
        double[] northX = {-159, -133, -106.5, -80.5, -55}, southX = {-126, -99.5, -70, -42};
        for (double fx : northX) fence(fx, -1, 6.5, 34);
        for (double fx : southX) fence(fx, 1, 6.5, 30);

        // Brunnen zwischen Versammlungshaus und Herberge, Fischgestelle und Boote am Strand
        double wz = brookZ(-106.5) - 16;
        bauwerke.well(-104, wz, 0, ground, 530);
        markDisc(-104, wz, 3.5, 0.9);
        block(-104, wz, 1.0);
        double[][] racks = {{-36, 21, 90, 5}, {-33, 28.5, 95, 4}};
        for (double[] r : racks) { bauwerke.rack(r[0], r[1], r[2], r[3], ground, (long) (r[0] * 7)); markDisc(r[0], r[1], 3.5, 0.6); }
        double[][] boats = {{-5.5, 17, 102, 6.0, 9}, {-4.5, 41, 78, 5.2, -11}, {-8, -14, 95, 4.6, 7}};
        for (double[] b : boats) { bauwerke.boat(b[0], b[1], b[2], b[3], b[4], ground, (long) (b[1] * 13)); markDisc(b[0], b[1], 3.2, 0.5); block(b[0], b[1], 2.2); }
    }

    /**
     * Ein Hof: das Haus quer zum Bach, sein Giebel gap Meter von der Mitte des Bachs, auf der Seite side (−1 Norden,
     * +1 Süden).
     */
    private void hof(String name, String rolle, HouseType type, double x, int side, double ls, double ws, double state, double gap) {
        double bz = brookZ(x);
        double half = type.length * ls / 2;
        double z = bz + side * (gap + 4.6 + half);
        House h = onGround(new House(type, x, 0, z, 0, ls, ws, state, Math.round(x * 31 + side)));
        haeuser.add(new Haus(name, rolle, h, true));
        houses.add(h);
        markHouse(h);
    }

    /** Stellt das Haus auf das Gelände: Mittel der Höhen an Ecken und Mitte, so dass die Schwellen kaum schweben. */
    private House onGround(House h) {
        Timber.Box b = Timber.box(new House(h.type(), h.x(), 0, h.z(), h.headingDeg(), h.lengthScale(), h.widthScale(), h.state(), h.seed()));
        double sum = 0, lo = Double.MAX_VALUE;
        int n = 0;
        for (int i = -1; i <= 1; i++)
            for (int j = -1; j <= 1; j++) {
                double[] p = h.toWorld(i * h.length() / 2, 0, j * h.width() / 2);
                double y = t.height(p[0], p[2]);
                sum += y; lo = Math.min(lo, y); n++;
            }
        double y = Math.max(sum / n - 0.05, lo + 0.05);
        return new House(h.type(), h.x(), y, h.z(), h.headingDeg(), h.lengthScale(), h.widthScale(), h.state(), h.seed());
    }

    private void fence(double fx, int side, double from, double to) {
        double bz = brookZ(fx);
        double[][] l = {{fx, bz + side * from}, {fx + 0.4, bz + side * (from + to * 0.5)}, {fx, bz + side * (from + to)}};
        bauwerke.fence(l, ground, (long) (fx * 17 + side));
        markLine(l, 0.6, 1.2);
        wege.add(new Weg("ZAUN", l, 0.1));
    }

    // ------------------------------------------------------------------ Phase 6: der Wall und die übrige Siedlung

    /**
     * Misst den Kamm des Halbkreiswalls im Gelände: je 2° auf dem Bogen der Halbmesser mit der größten Erhebung über
     * dem Mittel 20 m davor und dahinter; Tore und Lücken (Erhebung unter 1 m) werden aus den Nachbarn überbrückt.
     */
    void measureWall() {
        int n = wallR.length;
        if (wall != null) {
            // Phase 7: aus der gemessenen Kammlinie (der Nordabschnitt liegt näher an der Mitte als der Kreis aus Phase 6)
            for (int b = 0; b < n; b++) wallR[b] = wall.radius(b * 2 + 1, 393);
            return;
        }
        double[] r = new double[n];
        boolean[] ok = new boolean[n];
        for (int b = 0; b < n; b++) {
            double a = Math.toRadians(b * 2 + 1), ca = Math.cos(a), sa = Math.sin(a);
            double best = -9, br = 393;
            for (double rr = 350; rr <= 440; rr += 2) {
                double h = t.height(WALL_CX + ca * rr, WALL_CZ + sa * rr);
                double m = (t.height(WALL_CX + ca * (rr - 20), WALL_CZ + sa * (rr - 20)) + t.height(WALL_CX + ca * (rr + 20), WALL_CZ + sa * (rr + 20))) / 2;
                if (h - m > best) { best = h - m; br = rr; }
            }
            r[b] = br;
            ok[b] = best > 1.0 && onArc(b * 2 + 1);
        }
        // Lücken (Tore, Bach) linear zwischen den nächsten gemessenen Nachbarn auf dem Bogen
        for (int b = 0; b < n; b++) {
            if (ok[b] || !onArc(b * 2 + 1)) continue;
            int lo = b, hi = b;
            while (lo > 0 && !ok[lo]) lo--;
            while (hi < n - 1 && !ok[hi]) hi++;
            double rl = ok[lo] ? r[lo] : 393, rh = ok[hi] ? r[hi] : 393;
            r[b] = hi == lo ? rl : rl + (rh - rl) * (b - lo) / (double) (hi - lo);
        }
        // Median über fünf Nachbarn gegen Ausreißer (andere Kuppen im Hinterland)
        for (int b = 0; b < n; b++) {
            if (!onArc(b * 2 + 1)) { wallR[b] = 393; continue; }
            double[] w = new double[5];
            for (int k = -2; k <= 2; k++) w[k + 2] = r[Math.max(0, Math.min(n - 1, b + k))];
            java.util.Arrays.sort(w);
            wallR[b] = w[2];
        }
    }

    static boolean onArc(double deg) { double d = ((deg % 360) + 360) % 360; return d >= ARC_FROM && d <= ARC_TO; }

    /** Halbmesser des Wallkamms in Richtung (x, z) von der Mitte. */
    public double wallRadius(double x, double z) {
        double deg = Math.toDegrees(Math.atan2(z - WALL_CZ, x - WALL_CX));
        deg = ((deg % 360) + 360) % 360;
        double f = deg / 2 - 0.5;
        int i = (int) Math.floor(f);
        double w = f - i;
        return wallR[((i % 180) + 180) % 180] * (1 - w) + wallR[((i + 1) % 180 + 180) % 180] * w;
    }

    /** Liegt (x, z) im Wall, mit margin Abstand zum Kamm? Ostseite (zum Noor) offen, dort zählt das Ufer. */
    public boolean insideWall(double x, double z, double margin) {
        if (wall != null) return wall.inside(x, z, margin);
        double d = Math.hypot(x - WALL_CX, z - WALL_CZ);
        double deg = ((Math.toDegrees(Math.atan2(z - WALL_CZ, x - WALL_CX)) % 360) + 360) % 360;
        if (onArc(deg)) return d < wallRadius(x, z) - margin;
        return d < 460;
    }

    /**
     * Die übrige Siedlung aus dem Startwert [G nach dem Bild der Grabung]: Gassen aus Bohlen parallel zum Bach alle
     * 40 m (sie folgen seinen Krümmungen) und Quergassen zum Ufer; dazwischen schmale Grundstücke quer zu den Gassen,
     * je ein Haus mit dem Giebel zur Gasse, dahinter Grubenhaus oder Schuppen und ein Garten, Zäune zwischen den
     * Grundstücken. Am Ufer leichte Bohlen- und Uferhäuser, am Hang eingetiefte Grubenhäuser, das feuergefährliche
     * Gewerbe (Schmiede, Glas, Bronze) im Nordwesten abseits nahe am Wall. Frei bleiben der Bach mit den Höfen des
     * Museums, das Ufer für den Hafen (Phase 8), 18 m am Wall (Phase 7) und die Standpunkte der Ansichten.
     */
    void generate() {
        java.util.SplittableRandom r = new java.util.SplittableRandom(seed * 0x9E3779B97F4A7C15L + 7);
        double spacing = 40;
        // Gassen parallel zum Bach (k = ±1, ±2, …), von Westen bis kurz vor das Ufer
        List<double[][]> lanes = new ArrayList<>();
        for (int side = -1; side <= 1; side += 2)
            for (int k = 1; k <= 9; k++) {
                List<double[]> line = new ArrayList<>();
                List<double[]> cur = new ArrayList<>();
                double jitter = (r.nextDouble() - 0.5) * 6;
                for (double x = -640; x <= -20; x += 5) {
                    double z = brookZ(Math.max(-640, x)) + side * (k * spacing + jitter) + 3 * Math.sin(x / 37.0 + k);
                    boolean in = insideWall(x, z, 22) && t.height(x, z) > 0.8 && !nearView(x, z, 8);
                    if (in) cur.add(new double[]{x, z});
                    else if (cur.size() > 3) { lanes.add(cur.toArray(new double[0][])); cur = new ArrayList<>(); }
                    else cur.clear();
                }
                if (cur.size() > 3) lanes.add(cur.toArray(new double[0][]));
            }
        // Quergassen (Nord-Süd) alle gut 70 m, vom Bach bis zum Wall
        List<double[][]> cross = new ArrayList<>();
        for (double x0 = -560 + r.nextDouble() * 20; x0 < -40; x0 += 68 + r.nextDouble() * 10) {
            if (x0 > -180 && x0 < -30) continue;    // die Höfe am Bach haben ihre eigenen Wege
            for (int side = -1; side <= 1; side += 2) {
                List<double[]> cur = new ArrayList<>();
                for (double d = 8; d < 460; d += 5) {
                    double x = x0 + 4 * Math.sin(d / 29.0 + x0), z = brookZ(x0) + side * d;
                    if (insideWall(x, z, 22) && t.height(x, z) > 0.8) cur.add(new double[]{x, z});
                    else break;
                }
                if (cur.size() > 3) cross.add(cur.toArray(new double[0][]));
            }
        }
        for (double[][] l : lanes) { bauwerke.walkway(l, 2.0, ground, r.nextLong()); markLine(l, 1.2, 2.2); gassen.add(l); wege.add(new Weg("GASSE", l, 2.0)); }
        for (double[][] l : cross) { bauwerke.walkway(l, 1.8, ground, r.nextLong()); markLine(l, 1.1, 2.0); gassen.add(l); wege.add(new Weg("GASSE", l, 1.8)); }

        // Grundstücke an jeder Gasse, auf beiden Seiten: Breite 12 bis 19 m, Tiefe bis zur halben Strecke zur nächsten Gasse
        int n = 0;
        for (double[][] l : lanes) {
            double along = 0;
            for (int i = 0; i + 1 < l.length; i++) {
                double x0 = l[i][0], z0 = l[i][1], x1 = l[i + 1][0], z1 = l[i + 1][1];
                double seg = Math.hypot(x1 - x0, z1 - z0);
                along += seg;
                if (along < 0) continue;
                // ein neues Grundstück alle 12–19 m
                while (along >= 0) {
                    double w = 11 + r.nextDouble() * 6;
                    along -= w;
                    double f = Math.max(0, Math.min(1, 1 + along / seg));
                    double px = x0 + (x1 - x0) * f, pz = z0 + (z1 - z0) * f;
                    double dx = (x1 - x0) / seg, dz = (z1 - z0) / seg;
                    for (int side = -1; side <= 1; side += 2) {
                        if (r.nextDouble() > 0.86) continue;             // freie Fläche, Gemüse, Vieh
                        n += plot(px, pz, dx, dz, side, w, r);
                    }
                }
            }
        }
    }

    private boolean nearView(double x, double z, double rr) {
        for (double[] v : Vegetation.VIEWS) if (Math.hypot(x - v[0], z - v[1]) < rr) return true;
        return Math.hypot(x - VOM_WALL[0], z - VOM_WALL[1]) < rr;
    }

    /**
     * Ein Grundstück an der Gasse bei (px, pz), Richtung der Gasse (dx, dz), auf der Seite side, Breite w: Haupthaus mit
     * dem Giebel zur Gasse, dahinter vielleicht ein Grubenhaus oder Schuppen, ein Garten, ein Zaun an einer Seite.
     * Gibt die Zahl der gesetzten Häuser.
     */
    private int plot(double px, double pz, double dx, double dz, int side, double w, java.util.SplittableRandom r) {
        double nx = -dz * side, nz = dx * side;                     // von der Gasse weg ins Grundstück
        double cx = px + nx * 10, cz = pz + nz * 10;
        double y = t.height(cx, cz);
        boolean ufer = y < 3.2 && cx > -170;
        boolean hang = y > 9;
        double ang = (Math.toDegrees(Math.atan2(cz - WALL_CZ, cx - WALL_CX)) + 360) % 360;
        // Phase 7: „nahe am Wall“ nach dem Abstand zur gemessenen Kammlinie (der Nordwesten liegt näher an der Mitte)
        boolean nahWall = wall != null ? wall.distance(cx, cz) < 75 : Math.hypot(cx - WALL_CX, cz - WALL_CZ) > 285;
        boolean feuer = ang > 195 && ang < 240 && nahWall && r.nextDouble() < 0.8;
        HouseType type;
        String rolle;
        double u = r.nextDouble();
        if (feuer) { type = u < 0.5 ? HouseType.SCHUPPEN : HouseType.GRUBENHAUS; rolle = u < 0.3 ? "Schmiede" : u < 0.6 ? "Glasmacher" : "Bronzegießer"; }
        else if (ufer) { type = u < 0.45 ? HouseType.UFERHAUS : HouseType.BOHLENHAUS; rolle = u < 0.45 ? "Uferhaus" : "Händler"; }
        else if (hang) { type = u < 0.4 ? HouseType.GRUBENHAUS : u < 0.8 ? HouseType.WOHNHAUS : HouseType.BOHLENHAUS; rolle = type == HouseType.GRUBENHAUS ? "Weberin im Grubenhaus" : "Wohnhaus"; }
        else {
            type = u < 0.05 ? HouseType.HALLE : u < 0.55 ? HouseType.WOHNHAUS : u < 0.85 ? HouseType.BOHLENHAUS : HouseType.GRUBENHAUS;
            rolle = type == HouseType.HALLE ? "Hof eines reichen Händlers" : type == HouseType.GRUBENHAUS ? "Grubenhaus" : r.nextDouble() < 0.3 ? "Handwerker" : "Wohnhaus";
        }
        double ls = 0.85 + r.nextDouble() * 0.3, ws = Math.min(1.15, Math.max(0.85, (w - 4) / (type.width + 2.5)));
        double len = type.length * ls, wid = type.width * ws;
        if (wid + 2 > w) ws = Math.max(0.8, (w - 2) / type.width);
        double gap = 2.5 + r.nextDouble() * 2.5;
        double hx = px + nx * (gap + len / 2 + 1.2), hz = pz + nz * (gap + len / 2 + 1.2);
        double heading = Math.toDegrees(Math.atan2(nx, -nz)) + (r.nextDouble() - 0.5) * 8;    // First quer zur Gasse
        double state = 0.45 + r.nextDouble() * 0.5;
        House h = new House(type, hx, 0, hz, heading, ls, ws, state, r.nextLong());
        if (!free(h)) return 0;
        h = onGround(h);
        if (!steadyGround(h)) return 0;
        addHouse(h, rolle);
        int count = 1;
        // dahinter: Grubenhaus oder Schuppen, sonst Garten
        double back = gap + len + 4;
        double v = r.nextDouble();
        if (v < 0.42 && type != HouseType.GRUBENHAUS) {
            HouseType bt = v < 0.2 && !ufer ? HouseType.GRUBENHAUS : HouseType.SCHUPPEN;
            double bl = bt.length * 0.9;
            House b2 = new House(bt, px + nx * (back + bl / 2) + dx * (r.nextDouble() - 0.5) * 4, 0, pz + nz * (back + bl / 2) + dz * (r.nextDouble() - 0.5) * 4,
                    heading + (r.nextBoolean() ? 90 : 0), 0.9, 0.9, state, r.nextLong());
            if (free(b2)) { b2 = onGround(b2); if (steadyGround(b2)) { addHouse(b2, bt == HouseType.GRUBENHAUS ? "Grubenhaus (Werkraum)" : "Schuppen"); count++; } }
        } else if (v < 0.8) {
            markGarden(px + nx * (back + 4), pz + nz * (back + 4), dx, dz, nx, nz, w * 0.4, 4);
        }
        // Zaun an der einen Seite des Grundstücks, vom Rand der Gasse nach hinten
        if (r.nextDouble() < 0.55) {
            double ex = px + dx * w / 2, ez = pz + dz * w / 2;
            double[][] fl = {{ex + nx * 2, ez + nz * 2}, {ex + nx * (back + 6), ez + nz * (back + 6)}};
            if (insideWall(fl[1][0], fl[1][1], 18) && !crossesHouse(fl)) { bauwerke.fence(fl, ground, r.nextLong()); markLine(fl, 0.5, 0.8); wege.add(new Weg("ZAUN", fl, 0.1)); }
        }
        return count;
    }

    private void addHouse(House h, String rolle) {
        haeuser.add(new Haus(rolle, rolle, h, false));
        houses.add(h);
        markHouse(h);
    }

    /** Frei für ein neues Haus: im Wall, auf Land, nicht im Bach, nicht auf Wegen oder an anderen Häusern, kein Standpunkt. */
    private boolean free(House h) {
        double rad = h.radius();
        if (!insideWall(h.x(), h.z(), 18 + rad)) return false;
        if (nearView(h.x(), h.z(), rad + 6)) return false;
        if (h.x() > -25) return false;                                   // Ufer und Hafen (Phase 8)
        for (House o : houses) if (Math.hypot(o.x() - h.x(), o.z() - h.z()) < (o.radius() + rad) * 0.82 + 1.0) return false;
        for (int i = -2; i <= 2; i++)
            for (int j = -2; j <= 2; j++) {
                double[] p = h.toWorld(i * h.length() / 4, 0, j * h.width() / 4);
                if (t.height(p[0], p[2]) < 0.8 || t.sourceAt(p[0], p[2]) == Terrain.BACH || blocked(p[0], p[2])) return false;
                if (Math.abs(p[2] - brookZ(p[0])) < 9) return false;
            }
        return true;
    }

    /** Hang unter dem Haus höchstens 1,2 m (Grubenhaus 1,6 m). */
    private boolean steadyGround(House h) {
        double lo = 99, hi = -99;
        for (int i = -2; i <= 2; i++)
            for (int j = -2; j <= 2; j++) {
                double[] p = h.toWorld(i * h.length() / 4, 0, j * h.width() / 4);
                double y = t.height(p[0], p[2]);
                lo = Math.min(lo, y); hi = Math.max(hi, y);
            }
        return hi - lo < (h.type() == HouseType.GRUBENHAUS ? 1.6 : 1.2);
    }

    private boolean crossesHouse(double[][] l) {
        for (double s = 0; s <= 1; s += 0.1) {
            double x = l[0][0] + (l[1][0] - l[0][0]) * s, z = l[0][1] + (l[1][1] - l[0][1]) * s;
            int k = idx(x, z);
            if (k >= 0 && (floor[k] & 255) > 0) return true;
        }
        return false;
    }

    private void markGarden(double cx, double cz, double dx, double dz, double nx, double nz, double halfW, double halfD) {
        for (double a = -halfW; a <= halfW; a += 0.5)
            for (double b = -halfD; b <= halfD; b += 0.5) put(garden, idx(cx + dx * a + nx * b, cz + dz * a + nz * b), 1);
        wege.add(new Weg("GARTEN", new double[][]{{cx - dx * halfW - nx * halfD, cz - dz * halfW - nz * halfD}, {cx + dx * halfW - nx * halfD, cz + dz * halfW - nz * halfD},
                {cx + dx * halfW + nx * halfD, cz + dz * halfW + nz * halfD}, {cx - dx * halfW + nx * halfD, cz - dz * halfW + nz * halfD}}, 0));
    }

    /** Zählung je Rolle: „Wohnhaus 120, Grubenhaus 40, …“ */
    public String roles() {
        java.util.Map<String, Integer> m = new java.util.TreeMap<>();
        for (Haus h : haeuser) if (!h.museum()) m.merge(h.rolle(), 1, Integer::sum);
        StringBuilder b = new StringBuilder();
        for (var e : m.entrySet()) b.append(b.length() > 0 ? ", " : "").append(e.getKey()).append(' ').append(e.getValue());
        return b.toString();
    }

    // ------------------------------------------------------------------ Speichern (Phase 6)

    /** {@code daten/siedlung.csv} neben dem Programm ({@code -Dhaithabu.daten=…} setzt den Ordner anders). */
    public static java.io.File file() {
        String d = System.getProperty("haithabu.daten");
        return new java.io.File(d != null ? d : "daten", "siedlung.csv");
    }

    /** Die gespeicherte Siedlung, sonst die mit dem Startwert 950. */
    public static Siedlung startup(Terrain t) {
        java.io.File f = file();
        if (f.isFile())
            try { return load(t, f); } catch (Exception e) { System.err.println("Haithabu: " + f + " nicht lesbar (" + e.getMessage() + "), Startwert 950"); }
        return haithabu(t);
    }

    /** Schreibt alle Häuser als CSV nach file (Name; Rolle; Typ; x; y; z; Richtung; Länge; Breite; Zustand; Zufall; Museum). */
    public void save(java.io.File file) throws java.io.IOException {
        java.io.File dir = file.getParentFile();
        if (dir != null) dir.mkdirs();
        try (java.io.PrintWriter w = new java.io.PrintWriter(file, java.nio.charset.StandardCharsets.UTF_8)) {
            w.println("# Siedlung Haithabu, Startwert " + seed + " (scene.Siedlung, Phase 6): Name; Rolle; Typ; x; y; z; Richtung; Länge; Breite; Zustand; Zufall; Museum");
            for (Haus h : haeuser) {
                House o = h.house();
                w.println(String.join(";", h.name(), h.rolle(), o.type().name(), f(o.x()), f(o.y()), f(o.z()), f(o.headingDeg()), f(o.lengthScale()), f(o.widthScale()), f(o.state()),
                        Long.toString(o.seed()), Boolean.toString(h.museum())));
            }
        }
    }

    private static String f(double v) { return String.format(java.util.Locale.ROOT, "%.3f", v); }

    /** Liest eine gespeicherte Siedlung (Häuser) und baut Wege, Zäune und Karten aus dem gespeicherten Startwert neu. */
    public static Siedlung load(Terrain t, java.io.File file) throws java.io.IOException {
        List<String> lines = java.nio.file.Files.readAllLines(file.toPath(), java.nio.charset.StandardCharsets.UTF_8);
        long sd = 950;
        if (!lines.isEmpty() && lines.get(0).contains("Startwert")) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("Startwert (-?\\d+)").matcher(lines.get(0));
            if (m.find()) sd = Long.parseLong(m.group(1));
        }
        Siedlung s = haithabu(t, sd);
        // gespeicherte Häuser ersetzen die erzeugten (die Wege bleiben aus dem Startwert)
        List<Haus> keep = new ArrayList<>();
        for (String l : lines) {
            if (l.startsWith("#") || l.isBlank()) continue;
            String[] c = l.split(";");
            House h = new House(HouseType.valueOf(c[2]), d(c[3]), d(c[4]), d(c[5]), d(c[6]), d(c[7]), d(c[8]), d(c[9]), Long.parseLong(c[10]));
            keep.add(new Haus(c[0], c[1], h, Boolean.parseBoolean(c[11])));
        }
        s.uebernehmen(keep, file.getName());
        return s;
    }

    private static double d(String v) { return Double.parseDouble(v.trim()); }

    /**
     * Phase 16: eine gespeicherte Siedlung aus Startwert und Häusern (aus der Datenbank oder einer Datei). Wege, Zäune
     * und Karten kommen aus dem Startwert, die Häuser aus der Liste (F27 A).
     */
    public static Siedlung mitHaeusern(Terrain t, long seed, List<Haus> keep, String woher) {
        Siedlung s = haithabu(t, seed);
        s.uebernehmen(keep, woher);
        return s;
    }

    /** Gespeicherte Häuser ersetzen die erzeugten; Häuser jenseits des gemessenen Walls fallen weg (Phase 7). */
    private void uebernehmen(List<Haus> keep, String woher) {
        keep = new ArrayList<>(keep);
        if (wall != null) {
            int before = keep.size();
            keep.removeIf(h -> !h.museum() && !wall.inside(h.house().x(), h.house().z(), 12 + h.house().radius()));
            if (keep.size() < before) System.out.println("Haithabu: " + (before - keep.size()) + " Häuser aus " + woher + " lagen auf oder vor dem Wall und fallen weg");
        }
        if (!keep.isEmpty()) {
            haeuser.clear();
            houses.clear();
            java.util.Arrays.fill(floor, (byte) 0);
            for (Haus h : keep) { haeuser.add(h); houses.add(h.house()); markHouse(h.house()); }
        }
    }

    // ------------------------------------------------------------------ Karte

    private int idx(double x, double z) {
        int i = (int) Math.floor((x - X0) / CELL), j = (int) Math.floor((z - Z0) / CELL);
        return i < 0 || j < 0 || i >= NX || j >= NZ ? -1 : j * NX + i;
    }

    private static void put(byte[] a, int k, double v) {
        if (k < 0) return;
        int c = (int) Math.round(255 * Math.max(0, Math.min(1, v)));
        if (c > (a[k] & 255)) a[k] = (byte) c;
    }

    private void markHouse(House h) {
        Timber.Box b = Timber.box(h);
        double hl = h.length() / 2, hw = h.width() / 2, r = Math.max(b.halfLength(), b.halfWidth()) + 6;
        for (double x = h.x() - r; x <= h.x() + r; x += CELL)
            for (double z = h.z() - r; z <= h.z() + r; z += CELL) {
                double cx = x + CELL / 2, cz = z + CELL / 2;
                double a = Math.toRadians(h.headingDeg());
                double dx = cx - h.x(), dz = cz - h.z();
                double u = dx * Math.sin(a) - dz * Math.cos(a), v = dx * Math.cos(a) + dz * Math.sin(a);
                double ou = Math.max(0, Math.abs(u) - hl), ov = Math.max(0, Math.abs(v) - hw), d = Math.hypot(ou, ov);
                int k = idx(cx, cz);
                if (d == 0) { put(floor, k, 1); put(block, k, 1); put(yard, k, 1); }
                else {
                    put(yard, k, Math.exp(-d / 2.6) * (0.75 + 0.25 * Vegetation.fbm(cx / 3.0, cz / 3.0)));
                    if (d < 0.8) put(block, k, 1);
                }
            }
    }

    private void markLine(double[][] l, double halfWidth, double trample) {
        for (int i = 0; i + 1 < l.length; i++) {
            double x0 = l[i][0], z0 = l[i][1], x1 = l[i + 1][0], z1 = l[i + 1][1];
            double len = Math.hypot(x1 - x0, z1 - z0);
            for (double s = 0; s <= len; s += 0.5) {
                double px = x0 + (x1 - x0) * s / len, pz = z0 + (z1 - z0) * s / len;
                for (double ox = -halfWidth - trample; ox <= halfWidth + trample; ox += 0.5)
                    for (double oz = -halfWidth - trample; oz <= halfWidth + trample; oz += 0.5) {
                        double d = Math.hypot(ox, oz);
                        if (d > halfWidth + trample) continue;
                        int k = idx(px + ox, pz + oz);
                        if (d <= halfWidth) put(block, k, 1);
                        put(yard, k, d <= halfWidth ? 0.9 : 0.9 * (1 - (d - halfWidth) / trample));
                    }
            }
        }
    }

    /** Phase 8: unter Plattformen und Brücken wächst kein Schilf. */
    void blockLine(double[][] l, double halfWidth) {
        for (int i = 0; i + 1 < l.length; i++) {
            double x0 = l[i][0], z0 = l[i][1], x1 = l[i + 1][0], z1 = l[i + 1][1];
            double len = Math.hypot(x1 - x0, z1 - z0);
            if (len < 1e-9) continue;
            double nx = -(z1 - z0) / len, nz = (x1 - x0) / len;
            for (double s = 0; s <= len; s += 0.5)
                for (double q = -halfWidth; q <= halfWidth; q += 0.5) put(block, idx(x0 + (x1 - x0) * s / len + nx * q, z0 + (z1 - z0) * s / len + nz * q), 1);
        }
    }

    private void markDisc(double x, double z, double r, double v) {
        for (double ox = -r; ox <= r; ox += 0.5)
            for (double oz = -r; oz <= r; oz += 0.5) {
                double d = Math.hypot(ox, oz);
                if (d <= r) put(yard, idx(x + ox, z + oz), v * (1 - d / r * 0.6));
            }
    }

    private void block(double x, double z, double r) {
        for (double ox = -r; ox <= r; ox += 0.5)
            for (double oz = -r; oz <= r; oz += 0.5) if (Math.hypot(ox, oz) <= r) put(block, idx(x + ox, z + oz), 1);
    }

    /** Garten 0..1 an (x, z) (Phase 6). */
    public double garden(double x, double z) { int k = idx(x, z); return k < 0 ? 0 : (garden[k] & 255) / 255.0; }

    /** Hofboden 0..1 an (x, z). */
    public double yard(double x, double z) { int k = idx(x, z); return k < 0 ? 0 : (yard[k] & 255) / 255.0; }
    /** Kein Halm, keine Bodendecke: Fußboden, Weg, Boot, Brunnen. */
    public boolean blocked(double x, double z) { int k = idx(x, z); return k >= 0 && (block[k] & 255) > 127; }

    /** „7 Häuser am Bach, 2 Bohlenwege, Brücke, 9 Zäune, Brunnen, 2 Fischgestelle, 3 Boote“ */
    public String describe() {
        long museum = haeuser.stream().filter(Haus::museum).count();
        return String.format(java.util.Locale.GERMAN, "Siedlung (Startwert %d): %d Häuser am Bach, %d weitere im Wall, %d Gassen · Bauwerke %,d Dreiecke fein",
                seed, museum, haeuser.size() - museum, gassen.size(), bauwerke.triangles(false));
    }
}
