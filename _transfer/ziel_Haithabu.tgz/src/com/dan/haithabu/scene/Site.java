package com.dan.haithabu.scene;

/**
 * Der Ort der Szene: Haithabu am Haddebyer Noor (F2 = A). Echter Maßstab: 1 Einheit = 1 m, x nach Osten, y nach oben,
 * Nord = −z. Ursprung am Bachmund auf dem Wasserspiegel des Noors um 950; der lag rund 1 m unter dem heutigen [G].
 * Lage nach SRID 8307 (WGS84).
 * <p>
 * Phase 2: Die Szene ist eine transversale Mercator-Abbildung mit dem Bachmund als Mittelpunkt ({@link #SCENE},
 * Maßstab 1, Ellipsoid GRS80); Strecken und Richtungen stimmen im ganzen Gelände. Der Bachmund selbst kommt aus den
 * Höhendaten: {@code tools.GelaendeImport} verfolgt den Bach bis an das Ufer von 950 und nennt seine Lage.
 * Die übrigen Maße stammen aus dem Werkbuch, Abschnitt 2.
 */
public final class Site {
    private Site() { }

    /**
     * Ursprung der Szene: der Bachmund am Ufer von 950, 54°29′28″ N, 9°34′13″ E. Phase 2 hat ihn aus den Höhendaten
     * bestimmt (Lauf des Bachs bis an das modellierte Ufer, {@code tools.GelaendeImport}); in Phase 1 lag er
     * geschätzt [G] rund 100 m weiter südwestlich.
     */
    public static final double LAT = 54.4910607, LON = 9.5697097;
    /** Mitte des Wallinneren, wie sie für Haithabu angegeben wird. */
    public static final double CENTER_LAT = 54 + 29 / 60.0 + 28 / 3600.0, CENTER_LON = 9 + 33 / 60.0 + 55 / 3600.0;
    public static final int SRID = 8307;
    /** Mittlerer Erdradius in m. */
    public static final double EARTH_R = 6_371_000;
    /** Wirksamer Radius für die Sicht mit normaler Lichtbrechung (k = 0,13). */
    public static final double EARTH_R_OPTICAL = EARTH_R / (1 - 0.13);

    /** Wasserspiegel des Noors um 950 gegenüber heute (m) [G]; y = 0 der Szene. */
    public static final double NOOR_950 = -1.0;
    /** Das Noor: Länge und Breite (m), mittlere und größte Tiefe (m). */
    public static final double NOOR_LENGTH = 1600, NOOR_WIDTH = 900, NOOR_DEPTH = 3.0, NOOR_DEPTH_MAX = 5.2;
    /** Halbkreiswall: Höhe (m), umschlossene Fläche (ha). */
    public static final double WALL_HEIGHT = 9, WALL_AREA_HA = 26;
    /** Hochburg: Moränenkuppe (m über dem Noor) [G: rund 25 m]. */
    public static final double HOCHBURG_HEIGHT = 25;
    /** Seitenlänge des Geländes der Szene (F3 = A, rund 3 × 3 km). */
    public static final double EXTENT = 3000;

    /** Radius eines Halbkreises mit der Fläche des Wallinneren (m): rund 407 m. Erste Näherung für die Bühne [G]. */
    public static double wallRadius() { return Math.sqrt(WALL_AREA_HA * 10_000 * 2 / Math.PI); }

    /** Absenkung der Oberfläche in d m Entfernung durch die Erdkrümmung: d²/2R. */
    public static double curvatureDrop(double d) { return d * d / (2 * EARTH_R); }

    /** Entfernung der Kimm für ein Auge h m über dem Wasser, mit normaler Lichtbrechung (m). */
    public static double horizon(double h) { return Math.sqrt(2 * EARTH_R_OPTICAL * Math.max(0, h)); }

    /** Die Abbildung der Szene: transversale Mercator mit Maßstab 1 um den Bachmund (Nordwert = −z). */
    public static final Geo.Tm SCENE = Geo.local(LAT, LON);

    /** Breite und Länge (Grad) eines Szenenpunkts. */
    public static double[] latLon(double x, double z) { return SCENE.inverse(x, -z); }

    /** Szenenpunkt (x, z) aus Breite und Länge (Grad, als {lat, lon}). */
    public static double[] xz(double[] latLon) { double[] en = SCENE.forward(latLon[0], latLon[1]); return new double[]{en[0], -en[1]}; }

    /** Breite eines Punkts auf der Nord-Süd-Achse durch den Bachmund, Länge eines Punkts auf der Ost-West-Achse. */
    public static double lat(double z) { return latLon(0, z)[0]; }
    public static double lon(double x) { return latLon(x, 0)[1]; }
    /** Ostabstand eines Meridians auf Höhe des Bachmunds, Südabstand eines Breitenkreises auf seinem Meridian. */
    public static double x(double lon) { return xz(new double[]{LAT, lon})[0]; }
    public static double z(double lat) { return xz(new double[]{lat, LON})[1]; }

    /** „54°29′26″ N · 9°34′08″ E“ */
    public static String dms(double lat, double lon) {
        return dms(lat, lat >= 0 ? "N" : "S") + " · " + dms(lon, lon >= 0 ? "E" : "W");
    }

    private static String dms(double v, String h) {
        v = Math.abs(v);
        int d = (int) v;
        double mm = (v - d) * 60;
        int m = (int) mm;
        int s = (int) Math.round((mm - m) * 60);
        if (s == 60) { s = 0; m++; }
        if (m == 60) { m = 0; d++; }
        return String.format("%d°%02d′%02d″ %s", d, m, s, h);
    }
}
