package com.dan.haithabu.tools;

import com.dan.haithabu.scene.Geo;
import com.dan.haithabu.scene.Site;
import com.dan.haithabu.scene.Terrain;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * Import der Höhendaten (Phase 2, F2 A): liest die DGM1-Kacheln von Schleswig-Holstein (ETRS89/UTM32, 1 m, XYZ-Text,
 * {@code templates/dgm/dgm1_32_EEE_NNNN_1_sh_JJJJ.xyz}, auch {@code .xyz.gz}) oder einen Ausschnitt als GeoTIFF aus dem
 * Downloadclient ({@code templates/dgm/*.tif}, ETRS89/UTM32 zu 1 m, gelesen von {@link GeoTiff}) und schreibt das
 * Gelände der Szene nach {@code daten/gelaende/} ({@link Terrain}). Ohne GDAL: die Umrechnung macht {@link Geo}.
 * <ol>
 * <li>Jede Zelle des Szenenrasters (4096 × 4096 m, Nord = −z) wird nach UTM32 umgerechnet und aus den Kacheln bilinear
 * gelesen. Zellen ohne Kachel werden modelliert [G]: das Noor dort als Ellipse um seine Mitte (E 537 250, N 6 038 600,
 * 660 × 1 600 m), das Land glatt aus den Rändern der gemessenen Daten fortgesetzt, mit leichtem Relief.</li>
 * <li>Das Noor heute: die tiefen, ebenen Flächen um seinen Spiegel (im DGM rund 0,1 m über NHN; die Schlei steht in
 * einer anderen Befliegung bis 0,5 m höher und zählt als Wasser, solange sie eben ist). Sein Bett kennt das
 * DGM nicht; es wird aus dem Abstand zum heutigen Ufer modelliert [G]: Tiefe = 5,2 m · (1 − e^(−s/110 m)), also im
 * Haddebyer Noor heute im Mittel um 3 m und höchstens gut 5 m wie in der Literatur.</li>
 * <li>Um 950 stand das Wasser rund 1 m tiefer [G] (Site.NOOR_950). y = 0 der Szene ist dieser Spiegel; das Ufer von
 * 950 liegt damit dort, wo das modellierte Bett heute 1 m unter Wasser liegt, rund 40 m vor dem heutigen Ufer.</li>
 * <li>Der Haithabu-Bach: entlang der Talsohle von der Lücke im Westwall bis an das Ufer von 950 verfolgt, als Rinne
 * von 2,4 bis 4 m Breite eingetieft, mit stetigem Gefälle. Wo er das Ufer erreicht, liegt der Bachmund, der Ursprung
 * der Szene; weicht er mehr als 3 m (mehr als das Rauschen beim Neurastern) von {@link Site#LAT}/{@link Site#LON} ab, nennt das Werkzeug die neuen Werte.</li>
 * </ol>
 * Aufruf: {@code GelaendeImport [templates/dgm] [daten/gelaende] [docs/status/Gelaende_Import.png]}
 */
public final class GelaendeImport {
    /** Wie tief das Noor unter dem Spiegel höchstens wird und wie schnell es zur Mitte hin abfällt [G]. */
    static final double DMAX = 5.2, LBATH = 110;
    /** Mitte und Halbachsen des Noors für fehlende Kacheln [G] (UTM32). */
    static final double NOOR_E = 537_250, NOOR_N = 6_038_600, NOOR_A = 330, NOOR_B = 800;
    /** Lücke im Westwall, durch die der Bach in die Siedlung kommt (UTM32, aus dem DGM gelesen). */
    static final double GAP_E = 536_330, GAP_N = 6_038_251;
    /**
     * F23 A: der heutige Damm von Bundesstraße und Bahn zwischen Noor und Schlei, über dem Wasser (UTM32, aus dem DGM
     * gelesen). Um 950 gab es ihn nicht; der Import setzt ihn in {@link #DAMM_BREITE} m Breite auf Wasser [G].
     */
    public static final double[][] DAMM = {{537_160, 6_039_366}, {537_290, 6_039_345}, {537_420, 6_039_362}, {537_560, 6_039_420}, {537_700, 6_039_458}};
    public static final double DAMM_BREITE = 70;
    static final int N = Terrain.N;

    final Map<Long, float[]> tiles = new HashMap<>();
    final List<String> tileNames = new ArrayList<>();
    double[] east, north;    // UTM je Zelle (aus dem Gitter alle 64 Zellen)
    float[] nhn;             // gelesene Höhe über NHN, NaN = keine Kachel
    byte[] src;
    float[] y;               // Höhe der Szene
    double noorToday;
    final List<String> notes = new ArrayList<>();

    public static void main(String[] a) throws Exception {
        File in = new File(a.length > 0 ? a[0] : "templates/dgm"), out = a.length > 1 ? new File(a[1]) : Terrain.defaultDir();
        File png = new File(a.length > 2 ? a[2] : "docs/status/Gelaende_Import.png");
        GelaendeImport g = new GelaendeImport();
        long t0 = System.nanoTime();
        Terrain t = g.run(in);
        t.save(out);
        writePreview(t, png);
        for (String n : g.notes) System.out.println(n);
        System.out.println("Gelände: " + t.describe());
        System.out.printf(Locale.GERMAN, "Geschrieben nach %s und %s in %.1f s%n", out, png, (System.nanoTime() - t0) / 1e9);
    }

    /** Alle Schritte; gibt das fertige Gelände zurück. */
    public Terrain run(File dir) throws IOException {
        readTiles(dir);
        mapCells();
        sample();
        today();
        fillMissing();
        bathymetry();
        toScene();
        double[][] brook = brook();
        Properties p = new Properties();
        p.setProperty("quelle", tileNames.isEmpty() ? "modelliert (keine DGM-Kacheln)" : "DGM1 Schleswig-Holstein, " + tileNames.size() + (tileNames.size() == 1 ? " km²" : " km²"));
        p.setProperty("kacheln", String.join(",", tileNames));
        p.setProperty("noor.heute", fmt(noorToday));
        p.setProperty("noor.950.absenkung", fmt(-Site.NOOR_950));
        p.setProperty("noor.tiefe.max", fmt(DMAX));
        p.setProperty("noor.tiefe.abfall", fmt(LBATH));
        p.setProperty("ursprung.lat", String.format(Locale.ROOT, "%.7f", Site.LAT));
        p.setProperty("ursprung.lon", String.format(Locale.ROOT, "%.7f", Site.LON));
        double[] m = brook.length > 0 ? brook[brook.length - 1] : new double[]{0, 0};
        p.setProperty("bachmund.x", fmt(m[0]));
        p.setProperty("bachmund.z", fmt(m[1]));
        p.setProperty("erstellt", LocalDate.now().toString());
        double[] ll = Site.latLon(m[0], m[1]);
        p.setProperty("bachmund.lat", String.format(Locale.ROOT, "%.7f", ll[0]));
        p.setProperty("bachmund.lon", String.format(Locale.ROOT, "%.7f", ll[1]));
        short[] hs = new short[N * N];
        for (int i = 0; i < hs.length; i++) hs[i] = Terrain.encode(y[i]);
        Terrain t = new Terrain(hs, src, brook, p);
        double dev = Math.hypot(m[0], m[1]);
        notes.add(String.format(Locale.GERMAN, "Bachmund bei x = %.1f m, z = %.1f m (%s), %.1f m vom Ursprung der Szene",
                m[0], m[1], Site.dms(ll[0], ll[1]), dev));
        if (dev > 3 && brook.length > 0)
            notes.add(String.format(Locale.ROOT, "HINWEIS: neuer Ursprung für Site: LAT = %.7f, LON = %.7f (dann neu importieren)", ll[0], ll[1]));
        return t;
    }

    // ------------------------------------------------------------------ Kacheln

    static final Pattern NAME = Pattern.compile("dgm1_32_(\\d{3})_(\\d{4})_1_sh_(\\d{4})\\.xyz(\\.gz)?");

    void readTiles(File dir) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        java.util.Arrays.sort(fs);
        // zuerst Ausschnitte als GeoTIFF, danach einzelne XYZ-Kacheln (die gehen vor, wo beides da ist)
        for (File f : fs) {
            String low = f.getName().toLowerCase(Locale.ROOT);
            if (f.isFile() && (low.endsWith(".tif") || low.endsWith(".tiff"))) readGeoTiff(f);
        }
        for (File f : fs) {
            Matcher m = NAME.matcher(f.getName());
            if (!m.matches()) continue;
            int ek = Integer.parseInt(m.group(1)), nk = Integer.parseInt(m.group(2));
            float[] v = new float[1000 * 1000];
            java.util.Arrays.fill(v, Float.NaN);
            int count = 0;
            try (InputStream raw = new FileInputStream(f);
                 BufferedReader r = new BufferedReader(new InputStreamReader(m.group(4) != null ? new GZIPInputStream(raw, 1 << 16) : raw, StandardCharsets.US_ASCII), 1 << 16)) {
                String line;
                while ((line = r.readLine()) != null) {
                    int s1 = line.indexOf(' '), s2 = line.indexOf(' ', s1 + 1);
                    if (s1 < 0 || s2 < 0) continue;
                    double e = Double.parseDouble(line.substring(0, s1)), n = Double.parseDouble(line.substring(s1 + 1, s2));
                    double hgt = Double.parseDouble(line.substring(s2 + 1).trim());
                    int col = (int) Math.floor(e - ek * 1000.0), row = (int) Math.floor(n - nk * 1000.0);
                    if (col < 0 || row < 0 || col >= 1000 || row >= 1000) continue;
                    v[row * 1000 + col] = (float) hgt;
                    count++;
                }
            }
            float[] old = tiles.get(key(ek, nk));
            if (old != null) for (int i = 0; i < v.length; i++) if (Float.isNaN(v[i])) v[i] = old[i];
            tiles.put(key(ek, nk), v);
            if (!tileNames.contains(ek + "_" + nk)) tileNames.add(ek + "_" + nk);
            notes.add(String.format(Locale.GERMAN, "Kachel %s: %,d Punkte", f.getName(), count));
        }
    }

    /** Ein Ausschnitt als GeoTIFF (ETRS89/UTM32, 1 m) wird in Kilometerkacheln zerlegt. */
    void readGeoTiff(File f) throws IOException {
        GeoTiff g = GeoTiff.read(f);
        if (g.epsg != 0 && g.epsg != 25832) { notes.add("ÜBERSPRUNGEN " + f.getName() + ": Bezugssystem EPSG " + g.epsg + " statt 25832 (ETRS89/UTM32)"); return; }
        if (Math.abs(g.sizeX - 1) > 1e-6 || Math.abs(g.sizeY - 1) > 1e-6 || g.east0 != Math.rint(g.east0) || g.north0 != Math.rint(g.north0)) {
            notes.add("ÜBERSPRUNGEN " + f.getName() + ": nur Raster zu 1 m auf ganzen Metern (" + g + ")");
            return;
        }
        int e0 = (int) g.east0, nTop = (int) g.north0, count = 0;
        java.util.Set<Long> touched = new java.util.LinkedHashSet<>();
        for (int r = 0; r < g.height; r++) {
            int gn = nTop - 1 - r;   // Zeile r deckt Nord gn … gn + 1
            for (int c = 0; c < g.width; c++) {
                float v = g.data[r * g.width + c];
                if (Float.isNaN(v)) continue;
                int ge = e0 + c;
                long k = key(Math.floorDiv(ge, 1000), Math.floorDiv(gn, 1000));
                float[] t = tiles.get(k);
                if (t == null) { t = new float[1000 * 1000]; java.util.Arrays.fill(t, Float.NaN); tiles.put(k, t); }
                t[Math.floorMod(gn, 1000) * 1000 + Math.floorMod(ge, 1000)] = v;
                touched.add(k);
                count++;
            }
        }
        for (long k : touched) { String nm = (k >> 32) + "_" + (int) k; if (!tileNames.contains(nm)) tileNames.add(nm); }
        notes.add(String.format(Locale.GERMAN, "Ausschnitt %s: %s, %,d Punkte in %d Kilometerkacheln", f.getName(), g, count, touched.size()));
    }

    static long key(int ek, int nk) { return ((long) ek << 32) | (nk & 0xffffffffL); }

    /** DGM-Höhe an der Zellmitte (ge + 0,5, gn + 0,5) in ganzen Metern (UTM), NaN ohne Kachel. */
    float dgm(int ge, int gn) {
        float[] t = tiles.get(key(Math.floorDiv(ge, 1000), Math.floorDiv(gn, 1000)));
        if (t == null) return Float.NaN;
        return t[Math.floorMod(gn, 1000) * 1000 + Math.floorMod(ge, 1000)];
    }

    // ------------------------------------------------------------------ Umrechnung und Lesen

    /** UTM32 je Zelle: genau auf einem Gitter alle 64 Zellen, dazwischen bilinear (Fehler unter 1 mm). */
    void mapCells() {
        int step = 64, m = N / step + 1;
        double[] ge = new double[m * m], gn = new double[m * m];
        for (int b = 0; b < m; b++)
            for (int a = 0; a < m; a++) {
                double x = Terrain.X0 + a * step + 0.5, z = Terrain.Z0 + b * step + 0.5;
                double[] ll = Site.latLon(x, z);
                double[] en = Geo.UTM32.forward(ll[0], ll[1]);
                ge[b * m + a] = en[0];
                gn[b * m + a] = en[1];
            }
        east = new double[N * N];
        north = new double[N * N];
        for (int j = 0; j < N; j++) {
            int b = Math.min(m - 2, j / step);
            double fz = (j - b * step) / (double) step;
            for (int i = 0; i < N; i++) {
                int a = Math.min(m - 2, i / step);
                double fx = (i - a * step) / (double) step;
                int k = b * m + a;
                east[j * N + i] = lerp2(ge[k], ge[k + 1], ge[k + m], ge[k + m + 1], fx, fz);
                north[j * N + i] = lerp2(gn[k], gn[k + 1], gn[k + m], gn[k + m + 1], fx, fz);
            }
        }
    }

    static double lerp2(double a, double b, double c, double d, double fx, double fz) {
        return (a * (1 - fx) + b * fx) * (1 - fz) + (c * (1 - fx) + d * fx) * fz;
    }

    void sample() {
        nhn = new float[N * N];
        src = new byte[N * N];
        for (int k = 0; k < N * N; k++) {
            double u = east[k] - 0.5, v = north[k] - 0.5;
            int ge = (int) Math.floor(u), gn = (int) Math.floor(v);
            double fx = u - ge, fz = v - gn;
            float a = dgm(ge, gn), b = dgm(ge + 1, gn), c = dgm(ge, gn + 1), d = dgm(ge + 1, gn + 1);
            if (Float.isNaN(a) || Float.isNaN(b) || Float.isNaN(c) || Float.isNaN(d)) {
                // am Kachelrand ohne Nachbarn: nächster gemessener Punkt, sonst nichts
                float near = dgm((int) Math.round(u), (int) Math.round(v));
                nhn[k] = near;
                src[k] = Float.isNaN(near) ? Terrain.MODELLIERT : Terrain.GEMESSEN;
                continue;
            }
            nhn[k] = (float) ((a * (1 - fx) + b * fx) * (1 - fz) + (c * (1 - fx) + d * fx) * fz);
            src[k] = Terrain.GEMESSEN;
        }
    }

    // ------------------------------------------------------------------ Noor heute, fehlende Kacheln

    boolean[] water;

    /** Spiegel des Noors heute (Median der ebenen tiefen Flächen) und die Wassermaske. */
    void today() {
        List<Float> low = new ArrayList<>();
        for (int k = 0; k < N * N; k += 7) if (!Float.isNaN(nhn[k]) && nhn[k] > -0.5 && nhn[k] < 0.3) low.add(nhn[k]);
        java.util.Collections.sort(low);
        noorToday = low.isEmpty() ? 0.06 : low.get(low.size() / 2);
        if (low.size() < 1000) noorToday = 0.06;
        // Wasser: tief, oder bis 0,5 m über dem Spiegel und eben (andere Befliegungen messen die Schlei höher)
        float[] sd = localStd(nhn, 2);
        water = new boolean[N * N];
        for (int k = 0; k < N * N; k++) {
            if (Float.isNaN(nhn[k])) water[k] = inNoorEllipse(east[k], north[k]);
            else water[k] = nhn[k] <= noorToday + 0.15 || (nhn[k] <= noorToday + 0.5 && sd[k] < 0.05);
        }
        // Nähte zwischen Befliegungen (Stufe im Wasser, also nicht eben): schmale tiefe Streifen zwischen Wasser schließen
        double[] toWater = edt(not(water));
        boolean[] grown = new boolean[N * N];
        for (int k = 0; k < N * N; k++) grown[k] = water[k] || toWater[k] <= 36;
        double[] toDry = edt(grown);
        for (int k = 0; k < N * N; k++) if (!water[k] && toDry[k] > 36 && nhn[k] <= noorToday + 0.5) water[k] = true;
        keepLargest(water, 20_000);
        // Messrauschen im Wasser: kleine Landinseln ganz im Wasser werden Wasser
        boolean[] land = new boolean[N * N];
        for (int k = 0; k < N * N; k++) land[k] = !water[k];
        keepLargest(land, 600);
        for (int k = 0; k < N * N; k++) water[k] = !land[k];
        int dam = removeDam();
        if (dam > 0) notes.add(String.format(Locale.GERMAN, "Damm zwischen Noor und Schlei entfernt (F23 A): %,d m² wieder Wasser [G]", dam));
        notes.add(String.format(Locale.GERMAN, "Noor heute: Spiegel %.2f m über NHN, %.2f km² Wasser im Raster", noorToday, count(water) / 1e6));
    }

    /** Zellen im Dammkorridor unter 5 m NHN werden Wasser; gibt die Zahl zurück. */
    int removeDam() {
        int n = 0;
        double hw = DAMM_BREITE / 2;
        for (int k = 0; k < N * N; k++) {
            if (water[k] || Float.isNaN(nhn[k]) || nhn[k] > 5) continue;
            double e = east[k], no = north[k];
            if (e < DAMM[0][0] || e > DAMM[DAMM.length - 1][0]) continue;   // nur zwischen den Ufern
            for (int i = 0; i + 1 < DAMM.length; i++) {
                double ax = DAMM[i][0], ay = DAMM[i][1], bx = DAMM[i + 1][0], by = DAMM[i + 1][1];
                double dx = bx - ax, dy = by - ay, t = Math.max(0, Math.min(1, ((e - ax) * dx + (no - ay) * dy) / (dx * dx + dy * dy)));
                if (Math.hypot(e - ax - t * dx, no - ay - t * dy) <= hw) { water[k] = true; nhn[k] = (float) noorToday; n++; break; }
            }
        }
        return n;
    }

    /** Standardabweichung im Fenster (2r+1)² (NaN zählt nicht). */
    static float[] localStd(float[] h, int r) {
        float[] out = new float[N * N];
        java.util.stream.IntStream.range(0, N).parallel().forEach(j -> {
            for (int i = 0; i < N; i++) {
                double s = 0, s2 = 0;
                int n = 0;
                for (int b = Math.max(0, j - r); b <= Math.min(N - 1, j + r); b++)
                    for (int a = Math.max(0, i - r); a <= Math.min(N - 1, i + r); a++) {
                        float v = h[b * N + a];
                        if (Float.isNaN(v)) continue;
                        s += v; s2 += v * v; n++;
                    }
                out[j * N + i] = n < 2 ? 1f : (float) Math.sqrt(Math.max(0, s2 / n - (s / n) * (s / n)));
            }
        });
        return out;
    }

    static boolean inNoorEllipse(double e, double n) {
        double qx = (e - NOOR_E) / NOOR_A, qz = (n - NOOR_N) / NOOR_B;
        return qx * qx + qz * qz < 1;
    }

    static boolean[] not(boolean[] m) { boolean[] r = new boolean[m.length]; for (int k = 0; k < m.length; k++) r[k] = !m[k]; return r; }

    static int count(boolean[] m) { int c = 0; for (boolean b : m) if (b) c++; return c; }

    /** Behält nur Wasserflächen ab minCells Zellen (Gräben und Pfützen fallen weg). */
    static void keepLargest(boolean[] m, int minCells) {
        int[] label = new int[N * N];
        int[] stack = new int[N * N];
        int next = 0;
        List<Integer> sizes = new ArrayList<>();
        for (int k = 0; k < N * N; k++) {
            if (!m[k] || label[k] != 0) continue;
            next++;
            int sp = 0, size = 0;
            stack[sp++] = k;
            label[k] = next;
            while (sp > 0) {
                int c = stack[--sp];
                size++;
                int i = c % N, j = c / N;
                if (i > 0 && m[c - 1] && label[c - 1] == 0) { label[c - 1] = next; stack[sp++] = c - 1; }
                if (i < N - 1 && m[c + 1] && label[c + 1] == 0) { label[c + 1] = next; stack[sp++] = c + 1; }
                if (j > 0 && m[c - N] && label[c - N] == 0) { label[c - N] = next; stack[sp++] = c - N; }
                if (j < N - 1 && m[c + N] && label[c + N] == 0) { label[c + N] = next; stack[sp++] = c + N; }
            }
            sizes.add(size);
        }
        for (int k = 0; k < N * N; k++) if (m[k] && sizes.get(label[k] - 1) < minCells) m[k] = false;
    }

    /**
     * Fehlende Zellen: Wasser im angenommenen Noor auf den Spiegel, Land glatt fortgesetzt (Relaxation auf einem
     * 8-m-Gitter von den gemessenen Rändern aus, frei am Rand des Rasters) mit leichtem Relief [G].
     */
    void fillMissing() {
        int c = 8, m = N / c;
        double[] g = new double[m * m];
        boolean[] fixed = new boolean[m * m];
        List<Float> land = new ArrayList<>();
        for (int b = 0; b < m; b++)
            for (int a = 0; a < m; a++) {
                double sum = 0;
                int n = 0, w = 0;
                for (int j = b * c; j < b * c + c; j++)
                    for (int i = a * c; i < a * c + c; i++) {
                        int k = j * N + i;
                        if (water[k]) w++;
                        else if (!Float.isNaN(nhn[k])) { sum += nhn[k]; n++; }
                    }
                if (w > c * c / 2) { g[b * m + a] = noorToday; fixed[b * m + a] = true; }
                else if (n > c * c / 2) { g[b * m + a] = sum / n; fixed[b * m + a] = true; land.add((float) (sum / n)); }
            }
        java.util.Collections.sort(land);
        double median = land.isEmpty() ? 8 : land.get(land.size() / 2);
        for (int k = 0; k < g.length; k++) if (!fixed[k]) g[k] = median;
        // Relaxation von grob nach fein: erst auf 64 m, dann 32, 16, 8
        for (int lvl = 8; lvl >= 1; lvl /= 2) {
            for (int it = 0; it < 400; it++)
                for (int b = 0; b < m; b += lvl)
                    for (int a = 0; a < m; a += lvl) {
                        int k = b * m + a;
                        if (fixed[k]) continue;
                        double s = 0;
                        int n = 0;
                        if (a >= lvl) { s += g[k - lvl]; n++; }
                        if (a + lvl < m) { s += g[k + lvl]; n++; }
                        if (b >= lvl) { s += g[k - lvl * m]; n++; }
                        if (b + lvl < m) { s += g[k + lvl * m]; n++; }
                        g[k] = s / n;
                    }
            // Zwischenpunkte der nächsten Stufe aus der groben Lösung
            if (lvl > 1) for (int b = 0; b < m; b++)
                for (int a = 0; a < m; a++) {
                    int k = b * m + a;
                    if (fixed[k] || (a % lvl == 0 && b % lvl == 0)) continue;
                    int a0 = a / lvl * lvl, b0 = b / lvl * lvl, a1 = Math.min(m - 1, a0 + lvl), b1 = Math.min(m - 1, b0 + lvl);
                    double fx = a1 == a0 ? 0 : (a - a0) / (double) (a1 - a0), fz = b1 == b0 ? 0 : (b - b0) / (double) (b1 - b0);
                    g[k] = lerp2(g[b0 * m + a0], g[b0 * m + a1], g[b1 * m + a0], g[b1 * m + a1], fx, fz);
                }
        }
        int filled = 0;
        for (int j = 0; j < N; j++)
            for (int i = 0; i < N; i++) {
                int k = j * N + i;
                if (!Float.isNaN(nhn[k])) continue;
                filled++;
                if (water[k]) { nhn[k] = (float) noorToday; continue; }
                double u = Math.max(0, Math.min(m - 1.001, (i + 0.5) / c - 0.5)), v = Math.max(0, Math.min(m - 1.001, (j + 0.5) / c - 0.5));
                int a = (int) u, b = (int) v;
                double base = lerp2(g[b * m + a], g[b * m + a + 1], g[(b + 1) * m + a], g[(b + 1) * m + a + 1], u - a, v - b);
                double relief = 1.6 * (fbm(east[k] / 180, north[k] / 180) - 0.5) + 0.5 * (fbm(east[k] / 45, north[k] / 45) - 0.5);
                nhn[k] = (float) Math.max(noorToday + 0.4, base + relief);
            }
        if (filled > 0) notes.add(String.format(Locale.GERMAN, "Ohne Kachel modelliert: %.0f %% des Rasters [G]", 100.0 * filled / (N * N)));
    }

    // ------------------------------------------------------------------ Bett des Noors

    float[] depthToday;

    void bathymetry() {
        double[] d2 = edt(water);
        depthToday = new float[N * N];
        double sum = 0, max = 0;
        int n = 0;
        for (int k = 0; k < N * N; k++) {
            if (!water[k]) continue;
            double s = Math.sqrt(d2[k]);
            double wobble = 1 + 0.12 * (fbm(east[k] / 260, north[k] / 260) - 0.5);
            double d = DMAX * (1 - Math.exp(-s / LBATH)) * wobble;
            depthToday[k] = (float) d;
            nhn[k] = (float) (noorToday - d);
            src[k] = Terrain.NOORBETT;
            double d950 = d + Site.NOOR_950;
            if (d950 > 0) { sum += d950; n++; max = Math.max(max, d950); }
        }
        notes.add(String.format(Locale.GERMAN, "Noorbett [G]: um 950 im Mittel %.1f m, höchstens %.1f m tief, %.2f km² Wasser", n == 0 ? 0 : sum / n, max, n / 1e6));
    }

    /** Quadrat des Abstands jeder Wasserzelle zur nächsten Landzelle (exakt, Felzenszwalb und Huttenlocher). */
    static double[] edt(boolean[] inside) {
        double INF = 1e12;
        double[] f = new double[N * N];
        for (int k = 0; k < N * N; k++) f[k] = inside[k] ? INF : 0;
        double[] col = new double[N], out = new double[N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) col[j] = f[j * N + i];
            edt1(col, out);
            for (int j = 0; j < N; j++) f[j * N + i] = out[j];
        }
        for (int j = 0; j < N; j++) {
            System.arraycopy(f, j * N, col, 0, N);
            edt1(col, out);
            System.arraycopy(out, 0, f, j * N, N);
        }
        return f;
    }

    static void edt1(double[] f, double[] d) {
        int n = f.length;
        int[] v = new int[n];
        double[] z = new double[n + 1];
        int k = 0;
        v[0] = 0;
        z[0] = Double.NEGATIVE_INFINITY;
        z[1] = Double.POSITIVE_INFINITY;
        for (int q = 1; q < n; q++) {
            double s = ((f[q] + (double) q * q) - (f[v[k]] + (double) v[k] * v[k])) / (2.0 * q - 2.0 * v[k]);
            while (s <= z[k]) {
                k--;
                s = ((f[q] + (double) q * q) - (f[v[k]] + (double) v[k] * v[k])) / (2.0 * q - 2.0 * v[k]);
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = Double.POSITIVE_INFINITY;
        }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            double dq = q - v[k];
            d[q] = dq * dq + f[v[k]];
        }
    }

    // ------------------------------------------------------------------ Szene und Bach

    void toScene() {
        y = new float[N * N];
        double off = noorToday + Site.NOOR_950;   // Spiegel von 950 über NHN
        for (int k = 0; k < N * N; k++) y[k] = (float) (nhn[k] - off);
    }

    /**
     * Verfolgt den Bach von der Lücke im Westwall entlang der Talsohle bis an das Ufer von 950 und schneidet ihn als
     * Rinne ein. Ergebnis: je Punkt x, z, Sohle, Spiegel, halbe Breite.
     */
    double[][] brook() {
        double[] gap = Site.xz(utmToLat(GAP_E, GAP_N));
        if (!inside(gap[0], gap[1]) || src[cell(gap[0], gap[1])] == Terrain.MODELLIERT) {
            notes.add("Bach: die Lücke im Westwall liegt nicht in gemessenen Daten, kein Bach");
            return new double[0][];
        }
        float[] sm = blur(y, 8);
        List<double[]> pts = new ArrayList<>();
        // stromab: das Wasser läuft bergab. Schritte von 2 m gegen das Gefälle des geglätteten Geländes, mit Schwung,
        // damit kleine Mulden und Wege den Lauf nicht ablenken; wo es eben wird, geht es in der alten Richtung weiter.
        double px = gap[0], pz = gap[1], dx = 1, dz = 0;
        pts.add(new double[]{px, pz});
        for (int s = 0; s < 1500; s++) {
            double gx = (sample(sm, px + 2, pz) - sample(sm, px - 2, pz)) / 4, gz = (sample(sm, px, pz + 2) - sample(sm, px, pz - 2)) / 4;
            double g = Math.hypot(gx, gz);
            if (g > 0.012) {   // in Ebenen (der heutige Museumsplatz) geradeaus weiter
                dx = 0.8 * dx - 0.2 * gx / g;
                dz = 0.8 * dz - 0.2 * gz / g;
                double l = Math.hypot(dx, dz);
                dx /= l;
                dz /= l;
            }
            px += dx * 2;
            pz += dz * 2;
            if (!inside(px, pz)) break;
            pts.add(new double[]{px, pz});
            if (sample(y, px, pz) <= 0) break;
        }
        // stromauf: von der Lücke nach Westen das Tal hinauf, solange gemessen (höchstens 300 m)
        List<double[]> up = new ArrayList<>();
        px = gap[0]; pz = gap[1]; dx = -1; dz = 0;
        for (int s = 0; s < 100; s++) {
            double bx = 0, bz = 0, best = Double.MAX_VALUE;
            for (int o = -6; o <= 6; o++) {
                double cx = px + dx * 3 - dz * o, cz = pz + dz * 3 + dx * o;
                if (!inside(cx, cz) || src[cell(cx, cz)] != Terrain.GEMESSEN) continue;
                double v = sample(sm, cx, cz) + 0.05 * Math.abs(o);
                if (v < best) { best = v; bx = cx; bz = cz; }
            }
            if (best == Double.MAX_VALUE) break;
            double ndx = bx - px, ndz = bz - pz, l = Math.hypot(ndx, ndz);
            dx = 0.85 * dx + 0.15 * ndx / l;
            dz = 0.85 * dz + 0.15 * ndz / l;
            l = Math.hypot(dx, dz);
            dx /= l;
            dz /= l;
            if (dx > -0.5) break;   // nicht umkehren
            px += dx * 3;
            pz += dz * 3;
            up.add(0, new double[]{px, pz});
        }
        up.addAll(pts);
        // glätten (gleitendes Mittel über 7 Punkte, Enden fest)
        int n = up.size();
        double[][] p = new double[n][];
        for (int i = 0; i < n; i++) {
            double sx = 0, sz = 0;
            int c = 0;
            for (int k = Math.max(0, i - 3); k <= Math.min(n - 1, i + 3); k++) { sx += up.get(k)[0]; sz += up.get(k)[1]; c++; }
            p[i] = i == 0 || i == n - 1 ? up.get(i) : new double[]{sx / c, sz / c};
        }
        // Sohle: tiefster Boden in 3 m um die Linie, stromab nie steigend, mindestens 0,05 % Gefälle; Mündung unter 0
        double[][] r = new double[n][5];
        double total = 0;
        double[] s = new double[n];
        for (int i = 1; i < n; i++) { total += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]); s[i] = total; }
        double prev = Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            double lo = Double.MAX_VALUE;
            for (int o = -3; o <= 3; o++)
                for (int q = -3; q <= 3; q++) lo = Math.min(lo, sample(sm, p[i][0] + o, p[i][1] + q));
            double bed = lo - 0.55;
            if (i > 0) bed = Math.min(bed, prev - 0.0005 * (s[i] - s[i - 1]));
            prev = bed;
            double t = s[i] / Math.max(1, total);
            double half = 1.2 + 0.8 * t * t;
            double level = Math.max(bed + 0.30 + 0.05 * t, 0);
            r[i] = new double[]{p[i][0], p[i][1], bed, level, half};
        }
        // die letzten Punkte: Sohle läuft unter den Spiegel des Noors aus, Spiegel = 0
        double[] last = r[n - 1];
        last[2] = Math.min(last[2], -0.35);
        last[3] = 0;
        carve(r);
        notes.add(String.format(Locale.GERMAN, "Bach: %d Punkte, %.0f m von x = %.0f bis zur Mündung, Gefälle %.1f ‰", n, total, r[0][0],
                total <= 0 ? 0 : (r[0][2] - r[n - 1][2]) / total * 1000));
        return r;
    }

    /** Schneidet die Rinne ein: Sohle in der Mitte, Böschung über 4 m zum alten Boden; nur abtragen, nie aufschütten. */
    void carve(double[][] r) {
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (double[] q : r) { minX = Math.min(minX, q[0]); maxX = Math.max(maxX, q[0]); minZ = Math.min(minZ, q[1]); maxZ = Math.max(maxZ, q[1]); }
        int i0 = Math.max(0, cellI(minX - 8)), i1 = Math.min(N - 1, cellI(maxX + 8)), j0 = Math.max(0, cellJ(minZ - 8)), j1 = Math.min(N - 1, cellJ(maxZ + 8));
        for (int j = j0; j <= j1; j++)
            for (int i = i0; i <= i1; i++) {
                double x = Terrain.X0 + i + 0.5, z = Terrain.Z0 + j + 0.5;
                double best = Double.MAX_VALUE, bed = 0, level = 0, half = 1;
                for (int k = 0; k + 1 < r.length; k++) {
                    double[] a = r[k], b = r[k + 1];
                    double ex = b[0] - a[0], ez = b[1] - a[1], l2 = ex * ex + ez * ez;
                    double t = l2 <= 0 ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * ex + (z - a[1]) * ez) / l2));
                    double d = Math.hypot(a[0] + t * ex - x, a[1] + t * ez - z);
                    if (d < best) { best = d; bed = a[2] + t * (b[2] - a[2]); level = a[3] + t * (b[3] - a[3]); half = a[4] + t * (b[4] - a[4]); }
                }
                if (best > half + 4) continue;
                double target;
                if (best <= half) {
                    double u = best / half;
                    target = bed + (level + 0.15 - bed) * u * u;
                } else {
                    double u = (best - half) / 4;
                    double bank = level + 0.15;
                    double old = y[j * N + i];
                    target = bank + (old - bank) * u * u * (3 - 2 * u);
                }
                int k = j * N + i;
                if (target < y[k]) {
                    y[k] = (float) target;
                    if (best <= half) src[k] = Terrain.BACH;
                }
            }
    }

    // ------------------------------------------------------------------ Helfer

    static double[] utmToLat(double e, double n) { return Geo.UTM32.inverse(e, n); }
    static boolean inside(double x, double z) { int i = cellI(x), j = cellJ(z); return i >= 1 && j >= 1 && i < N - 1 && j < N - 1; }
    static int cellI(double x) { return (int) Math.floor((x - Terrain.X0) / Terrain.CELL); }
    static int cellJ(double z) { return (int) Math.floor((z - Terrain.Z0) / Terrain.CELL); }
    static int cell(double x, double z) { return cellJ(z) * N + cellI(x); }

    static double sample(float[] a, double x, double z) {
        double u = (x - Terrain.X0) - 0.5, v = (z - Terrain.Z0) - 0.5;
        int i = Math.max(0, Math.min(N - 2, (int) Math.floor(u))), j = Math.max(0, Math.min(N - 2, (int) Math.floor(v)));
        double fx = Math.max(0, Math.min(1, u - i)), fz = Math.max(0, Math.min(1, v - j));
        int k = j * N + i;
        return lerp2(a[k], a[k + 1], a[k + N], a[k + N + 1], fx, fz);
    }

    /** Kastenfilter mit Radius r (zweimal, also fast ein Gauß). */
    static float[] blur(float[] in, int r) {
        float[] a = in.clone(), b = new float[N * N];
        for (int pass = 0; pass < 2; pass++) {
            for (int j = 0; j < N; j++) {
                double s = 0;
                int c = 0;
                for (int i = -r; i <= r; i++) if (i >= 0 && i < N) { s += a[j * N + i]; c++; }
                for (int i = 0; i < N; i++) {
                    b[j * N + i] = (float) (s / c);
                    int out = i - r, in2 = i + r + 1;
                    if (out >= 0) { s -= a[j * N + out]; c--; }
                    if (in2 < N) { s += a[j * N + in2]; c++; }
                }
            }
            for (int i = 0; i < N; i++) {
                double s = 0;
                int c = 0;
                for (int j = -r; j <= r; j++) if (j >= 0 && j < N) { s += b[j * N + i]; c++; }
                for (int j = 0; j < N; j++) {
                    a[j * N + i] = (float) (s / c);
                    int out = j - r, in2 = j + r + 1;
                    if (out >= 0) { s -= b[out * N + i]; c--; }
                    if (in2 < N) { s += b[in2 * N + i]; c++; }
                }
            }
        }
        return a;
    }

    static double hash(int x, int y) {
        long h = x * 374761393L + y * 668265263L;
        h = (h ^ (h >>> 13)) * 1274126177L;
        return ((h ^ (h >>> 16)) & 0xffffff) / (double) 0x1000000;
    }

    static double vnoise(double x, double y) {
        int i = (int) Math.floor(x), j = (int) Math.floor(y);
        double fx = x - i, fy = y - j;
        fx = fx * fx * (3 - 2 * fx);
        fy = fy * fy * (3 - 2 * fy);
        return lerp2(hash(i, j), hash(i + 1, j), hash(i, j + 1), hash(i + 1, j + 1), fx, fy);
    }

    static double fbm(double x, double y) { return 0.57 * vnoise(x, y) + 0.29 * vnoise(x * 2.03 + 7.1, y * 2.03 - 3.3) + 0.14 * vnoise(x * 4.1 - 1.7, y * 4.1 + 5.2); }

    static String fmt(double v) { return String.format(Locale.ROOT, "%.3f", v); }

    // ------------------------------------------------------------------ Vorschau

    /** Schummerung mit Wasser, Herkunft und Bach, 1024 × 1024 (4 m je Punkt), Norden oben. */
    static void writePreview(Terrain t, File png) throws IOException {
        int s = 1024, f = N / s;
        BufferedImage im = new BufferedImage(s, s, BufferedImage.TYPE_INT_RGB);
        for (int b = 0; b < s; b++)
            for (int a = 0; a < s; a++) {
                int i = a * f + f / 2, j = b * f + f / 2;
                double hgt = t.at(i, j), dzx = (t.at(i + f, j) - t.at(i - f, j)) / (2 * f), dzz = (t.at(i, j + f) - t.at(i, j - f)) / (2 * f);
                double nx = -dzx, nz = -dzz, l = Math.sqrt(nx * nx + 1 + nz * nz);
                double shade = Math.max(0, (-0.5 * nx + 0.7 + 0.5 * nz) / l / 1.0);
                int rr, gg, bb;
                byte sr = t.src[j * N + i];
                if (hgt < 0) {
                    double d = Math.min(1, -hgt / 5);
                    rr = (int) (70 - 50 * d); gg = (int) (120 - 60 * d); bb = (int) (150 - 40 * d);
                } else {
                    double c = Math.min(1, hgt / 25);
                    rr = (int) ((120 + 70 * c) * shade); gg = (int) ((135 + 40 * c) * shade); bb = (int) ((90 + 30 * c) * shade);
                    if (sr == Terrain.MODELLIERT) { rr = (rr + 160) / 2; gg = (gg + 140) / 2; bb = (bb + 120) / 2; }
                }
                if (sr == Terrain.BACH) { rr = 40; gg = 110; bb = 200; }
                im.setRGB(a, b, (Math.max(0, Math.min(255, rr)) << 16) | (Math.max(0, Math.min(255, gg)) << 8) | Math.max(0, Math.min(255, bb)));
            }
        java.awt.Graphics2D g = im.createGraphics();
        g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new java.awt.Color(226, 122, 46));
        int ox = (int) ((0 - Terrain.X0) / f), oz = (int) ((0 - Terrain.Z0) / f);
        g.drawOval(ox - 5, oz - 5, 10, 10);
        g.drawLine(ox, oz - 5, ox, oz - 18);
        g.setColor(java.awt.Color.WHITE);
        g.drawString("Bachmund (Ursprung)", ox + 8, oz - 8);
        g.drawString(t.describe(), 8, s - 10);
        g.drawString("N ↑ · 4 m je Punkt · " + t.source, 8, 16);
        g.dispose();
        if (png.getParentFile() != null) png.getParentFile().mkdirs();
        javax.imageio.ImageIO.write(im, "png", png);
    }

    private GelaendeImport() { }
}
