package com.dan.haithabu.tools;

import com.dan.haithabu.camera.Ansichten;
import com.dan.haithabu.scene.Feuer;
import com.dan.haithabu.scene.Flotte;
import com.dan.haithabu.scene.Klang;
import com.dan.haithabu.scene.Leben;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.scene.Vegetation;
import com.dan.haithabu.scene.Versammlungshaus;
import com.dan.haithabu.wiring.Beaufort;
import com.dan.ocean.Ocean;
import com.dan.soundscape.Blaze;
import com.dan.soundscape.Soundscape;
import com.dan.soundscape.Wav;
import com.dan.timber.House;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Phase 14: die Hörproben der Abnahme als WAV, ohne Lautsprecher gerechnet mit der Szene selbst (Vögel, Haustiere,
 * Schiffe, Feuer, Werkstätten, Markt, Wetter): „Hafen am Morgen“, „Gasse am Mittag“, „Im Haus am Abend“ und „Die Nacht
 * von 1050“. Je 30 s nach 20 s Vorlauf (das Ohr passt sich an, die Werkstätten kommen in Takt), 32 kHz Stereo, dazu ein
 * Blatt mit den Spektrogrammen.
 * <p>
 * Die Nacht von 1050 ist hier nur ihr Klang: Drei Häuser am Bach brennen, Balken stürzen, Hunde bellen, Schweine
 * quieken, Möwen schreien, ein Langschiff rudert in den Hafen. Die Szene dazu (Regiebuch mit dem Brander) baut Phase 15.
 * <pre>
 * Hoerproben [ordner]     schreibt nach docs/hoerproben (oder in den Ordner)
 * </pre>
 */
public final class Hoerproben {
    private Hoerproben() { }

    /** Eine Hörprobe: Datei (ohne Endung), Titel, Pegel am Ende, Ton, Abtastrate. */
    public record Probe(String file, String title, String levels, float[] audio, int sampleRate) { }

    public static void main(String[] a) throws IOException {
        File dir = new File(a.length > 0 ? a[0] : "docs/hoerproben");
        Terrain t = Terrain.load(Terrain.defaultDir());
        Siedlung s = Siedlung.startup(t);
        write(t, s, new Vegetation(t), dir, System.out::println);
    }

    /** Alle vier rechnen und schreiben (WAV und Blatt); gibt die Dateien zurück. */
    public static List<File> write(Terrain t, Siedlung s, Vegetation v, File dir, Consumer<String> progress) throws IOException {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Ordner " + dir + " lässt sich nicht anlegen");
        List<Probe> ps = all(t, s, v, 30, progress);
        List<File> out = new ArrayList<>();
        for (Probe p : ps) {
            File f = new File(dir, p.file + ".wav");
            Wav.write(f, p.audio, p.sampleRate);
            out.add(f);
            progress.accept("WAV: " + f.getPath() + " · " + p.levels);
        }
        File img = new File(dir, "Hoerproben.png");
        ImageIO.write(sheet(ps, 1800), "png", img);
        out.add(img);
        progress.accept("Blatt: " + img.getPath());
        return out;
    }

    /** Die vier Hörproben zu je seconds s. */
    public static List<Probe> all(Terrain t, Siedlung s, Vegetation v, double seconds, Consumer<String> progress) {
        List<Probe> l = new ArrayList<>();
        progress.accept("Hörprobe 1/4: Hafen am Morgen");
        l.add(hafen(t, s, v, seconds));
        progress.accept("Hörprobe 2/4: Gasse am Mittag");
        l.add(gasse(t, s, v, seconds));
        progress.accept("Hörprobe 3/4: Im Haus am Abend");
        l.add(haus(t, s, v, seconds));
        progress.accept("Hörprobe 4/4: Die Nacht von 1050");
        l.add(nacht(t, s, v, seconds));
        return l;
    }

    // ------------------------------------------------------------------ die Szene ohne Bild

    /** Eine Szene zum Hören: Uhr, Wetter, Wasser, alle Packages, das Ohr. */
    public static final class Stage {
        public final Terrain t;
        public final SceneClock clock;
        public final Feuer feuer;
        public final Leben leben;
        public final Flotte flotte;
        public final Klang klang;
        public final Ocean ocean;
        public final double windSpeed, windFrom, rain;
        public final LocalDate date;
        public final double hour0;
        public double[] eye;
        public double yaw;
        public boolean inHall;
        public double time;
        /** Was je Stück zusätzlich geschieht (Sekunden seit Beginn der Aufnahme, negativ im Vorlauf). */
        public Script script = (st, sec) -> { };

        public Stage(Terrain t, Siedlung s, Vegetation v, LocalDate date, double hour, int bft, double windFrom, double rain) {
            this.t = t;
            this.date = date;
            this.hour0 = hour;
            clock = new SceneClock(date, hour);
            feuer = Feuer.of(t, s);
            leben = Leben.of(t, s);
            flotte = Flotte.of(t, s.hafen);
            klang = Klang.of(t, s, feuer, leben, flotte, v);
            ocean = Ocean.noor(Math.max(1, bft));
            windSpeed = Beaufort.mid(bft);
            this.windFrom = windFrom;
            this.rain = rain;
            klang.scape.autoGain = true;
            double[] sun = clock.sun();
            feuer.step(1, hour, sun[0]);
            if (feuer.hall != null) feuer.hall.settle(hour, sun[0]);
        }

        /** Um dt weiter (Szene und Klang) und dt Sekunden Ton rechnen. */
        public float[] run(double dt) {
            clock.set(date, hour0 + time / 3600);
            double alt = clock.sun()[0];
            double hour = hour0 + time / 3600;
            double lux = Math.max(0, Math.sin(Math.toRadians(alt))) * 100_000 + Math.max(0, alt + 6) * 60;
            double ws = windSpeed * com.dan.haithabu.wiring.Wiring.LAND_WIND;
            ocean.windSpeed = windSpeed;
            ocean.step(dt);
            if (flotte != null) flotte.step(dt, ocean, windFrom, ws);
            feuer.step(dt, hour, alt);
            List<double[]> boats = new ArrayList<>();
            if (flotte != null) for (var sh : flotte.ships) if (sh.mode != com.dan.longship.Longship.Mode.FEST) boats.add(new double[]{sh.x, 0.5, sh.z});
            leben.waterHeight = ocean::heightAt;
            leben.step(dt, eye, alt, lux, ws, windFrom, rain, 0, date.getDayOfYear(), ocean.waterLevel, 0, boats);
            Ocean.State os = ocean.state();
            klang.feed(dt, eye, yaw, inHall, hour, alt, ws, windFrom, 0.2, rain, 9, os.totalHs(), os.peakPeriod, ocean.waterLevel, false);
            script.at(this, time);
            time += dt;
            return klang.scape.render(dt);
        }

        /** Vorlauf (Ton verworfen), dann die Aufnahme. */
        public Probe record(String file, String title, double pre, double seconds) {
            time = -pre;
            int sr = klang.scape.sampleRate();
            double chunk = 512.0 / sr;
            while (time < 0) run(chunk);
            int n = (int) (seconds * sr);
            float[] out = new float[2 * n];
            int done = 0;
            while (done < n) {
                float[] b = run(chunk);
                int m = Math.min(b.length / 2, n - done);
                System.arraycopy(b, 0, out, 2 * done, 2 * m);
                done += m;
            }
            return new Probe(file, title, klang.describe(), out, sr);
        }
    }

    public interface Script { void at(Stage st, double sec); }

    static final LocalDate TAG = LocalDate.of(950, 10, 16);

    static Probe hafen(Terrain t, Siedlung s, Vegetation v, double seconds) {
        Stage st = new Stage(t, s, v, TAG, 7.5, 2, 230, 0);
        Ansichten.Ansicht a = Ansichten.byName("Hafen");
        st.eye = new double[]{a.x(), Math.max(t.height(a.x(), a.z()), 0.9) + a.eyeAboveGround(), a.z()};
        st.yaw = a.heading();
        // die Knorr läuft ein: vorspulen bis kurz vor die Durchfahrt (Rah nieder, sie rudert)
        if (st.flotte != null) {
            st.flotte.einlaufen(230, Beaufort.mid(2) * 0.8);
            for (int i = 0; i < 9000 && !st.flotte.einlaeufer.rowing(); i++) { st.ocean.step(0.2); st.flotte.step(0.2, st.ocean, 230, Beaufort.mid(2) * 0.8); }
        }
        return st.record("1_Hafen_am_Morgen", "Hafen am Morgen (16.10.950, 7:30, Bft 2): Möwen, Enten, Wasser an den Pfählen, die Knorr rudert ein, Hahn und Hund an Land, Bootsbauer am Strand",
                20, seconds);
    }

    static Probe gasse(Terrain t, Siedlung s, Vegetation v, double seconds) {
        Stage st = new Stage(t, s, v, TAG, 11.5, 3, 245, 0);
        st.eye = gassePunkt(t, s, st.feuer.hall);
        st.yaw = 88;
        return st.record("2_Gasse_am_Mittag", "Gasse am Mittag (11:30, Bft 3): Hühner, Kammmacher sägt, Schmieden fern, Markt am Umschlagplatz, Reet im Wind", 20, seconds);
    }

    static Probe haus(Terrain t, Siedlung s, Vegetation v, double seconds) {
        Stage st = new Stage(t, s, v, TAG, 19, 4, 250, 1.5);
        double[] p = st.feuer.hall != null ? st.feuer.hall.imHaus() : new double[]{-120, 3, 0, 0, 0};
        st.eye = new double[]{p[0], p[1], p[2]};
        st.yaw = p[3];
        st.inHall = true;
        if (st.feuer.hall != null) st.feuer.hall.herdMode = 1;
        return st.record("3_Im_Haus_am_Abend", "Im Versammlungshaus am Abend (19 Uhr, Bft 4, leichter Regen): der Herd knistert, Wind und Regen auf dem Reet, draußen gedämpft", 20, seconds);
    }

    static Probe nacht(Terrain t, Siedlung s, Vegetation v, double seconds) {
        Stage st = new Stage(t, s, v, LocalDate.of(1050, 10, 16), 2.0, 4, 265, 0);
        st.eye = gassePunkt(t, s, st.feuer.hall);
        st.yaw = 88;
        // drei Häuser in 25 bis 90 m brennen
        List<House> burn = new ArrayList<>();
        for (House h : s.houses) {
            double d = Math.hypot(h.x() - st.eye[0], h.z() - st.eye[2]);
            if (d > 25 && d < 90 && burn.size() < 3 && (burn.isEmpty() || Math.hypot(h.x() - burn.get(burn.size() - 1).x(), h.z() - burn.get(burn.size() - 1).z()) > 12)) burn.add(h);
        }
        double[] size = {1.0, 0.8, 0.55};
        List<Blaze> fires = new ArrayList<>();
        for (int i = 0; i < burn.size(); i++) {
            House h = burn.get(i);
            Blaze b = new Blaze("Brand " + (i + 1), h.x(), h.y() + 3, h.z(), size[i], false);
            fires.add(b);
            st.klang.scape.blazes.add(b);
        }
        double[] port = s.hafen != null && s.hafen.durchfahrt != null ? s.hafen.durchfahrt : new double[]{60, -60};
        java.util.Random r = new java.util.Random(1050);
        double[] next = {0, 2, 4, 1};
        st.script = (x, sec) -> {
            Soundscape sc = x.klang.scape;
            if (sec < 0) return;
            // Balken stürzen
            for (double tc : new double[]{7, 16.5, 25}) if (sec >= tc && sec < tc + 0.02 && !fires.isEmpty()) {
                Blaze b = fires.get((int) (tc / 9) % fires.size());
                sc.event(Soundscape.Kind.EINSTURZ, b.x, b.y, b.z, 0.9, 0.5);
            }
            // Hunde, Schweine, Möwen in Aufruhr
            if (sec >= next[0]) { next[0] = sec + 1.5 + 3 * r.nextDouble(); sc.event(Soundscape.Kind.HUND, x.eye[0] + 40 * (r.nextDouble() - 0.5), 0.6, x.eye[2] + 50 * (r.nextDouble() - 0.5), 1, 0.5); }
            if (sec >= next[1]) { next[1] = sec + 4 + 6 * r.nextDouble(); sc.event(Soundscape.Kind.QUIEKEN, x.eye[0] - 60, 2, x.eye[2] + 40, 1, 0.5); }
            if (sec >= next[2]) { next[2] = sec + 2 + 4 * r.nextDouble(); sc.event(Soundscape.Kind.MOEWE, x.eye[0] + 80 * r.nextDouble(), 25, x.eye[2] - 40 + 80 * r.nextDouble(), 1); }
            if (sec >= next[3]) { next[3] = sec + 3 + 5 * r.nextDouble(); sc.event(Soundscape.Kind.HAHN, x.eye[0] - 30, 1, x.eye[2] - 25, 0.9, 0.5); }
            // ein Langschiff rudert von der Durchfahrt herein (0,42 Schläge je s)
            double k = Math.floor(sec * 0.42), prev = Math.floor((sec - 512.0 / sc.sampleRate()) * 0.42);
            if (k != prev) {
                double f = Math.min(1, sec / 30);
                double bx = port[0] + (x.eye[0] + 70 - port[0]) * f * 0.9, bz = port[1] + (x.eye[2] - 30 - port[1]) * f * 0.9;
                sc.event(Soundscape.Kind.RUDER, bx, 0.6, bz, 1, 12);
            }
        };
        return st.record("4_Die_Nacht_von_1050", "Die Nacht von 1050 (2 Uhr, Bft 4): Häuser am Bach brennen, Balken stürzen, Hunde, Schweine, Möwen, ein Langschiff rudert herein",
                12, seconds);
    }

    /** Auf dem Bohlenweg zwischen Versammlungshaus und Kammmacher. */
    public static double[] gassePunkt(Terrain t, Siedlung s, Versammlungshaus h) {
        if (h == null) return new double[]{-95, Math.max(0, t.height(-95, s.brookZ(-95) - 4.6)) + 1.7, s.brookZ(-95) - 4.6};
        double[][] g = h.gasse(s, t);
        double[] best = g[0];
        for (double[] q : g) if (Math.abs(q[0] + 95) < Math.abs(best[0] + 95)) best = q;
        return new double[]{best[0], best[1], best[2]};
    }

    // ------------------------------------------------------------------ Blatt

    static BufferedImage sheet(List<Probe> ps, int w) {
        int rowH = 240, head = 40;
        BufferedImage img = new BufferedImage(w, ps.size() * (rowH + head) + 50, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(new Color(16, 22, 19));
        g.fillRect(0, 0, img.getWidth(), img.getHeight());
        g.setColor(new Color(232, 230, 222));
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("Haithabu · Hörproben Phase 14 · je 30 s, 32 kHz Stereo · Spektrogramm 30 Hz bis 16 kHz", 12, 28);
        int y = 44, axis = 64;
        for (Probe p : ps) {
            g.setColor(new Color(232, 230, 222));
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
            g.drawString(p.title, 10, y + 16);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            g.setColor(new Color(152, 162, 154));
            String lv = p.levels.length() > 230 ? p.levels.substring(0, 230) + " …" : p.levels;
            g.drawString(lv, 10, y + 32);
            int top = y + head;
            com.dan.soundscape.demo.Analysis.spectrogram(g, p.audio, p.sampleRate, axis, top, w - axis - 10, rowH - 8, -40);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
            for (double f : new double[]{50, 100, 200, 500, 1000, 2000, 5000, 10_000}) {
                double fy = 1 - Math.log(f / 30) / Math.log(16_000 / 30.0);
                int yy = top + (int) (fy * (rowH - 9));
                g.drawString(f >= 1000 ? String.format(Locale.GERMAN, "%.0f kHz", f / 1000) : String.format(Locale.GERMAN, "%.0f Hz", f), 6, yy + 4);
            }
            y += rowH + head;
        }
        g.dispose();
        return img;
    }
}
