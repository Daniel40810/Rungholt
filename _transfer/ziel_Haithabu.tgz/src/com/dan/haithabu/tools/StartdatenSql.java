package com.dan.haithabu.tools;

import com.dan.haithabu.data.Startdaten;
import com.dan.haithabu.scene.Feuer;
import com.dan.haithabu.scene.Flotte;
import com.dan.haithabu.scene.Siedlung;
import com.dan.haithabu.scene.Terrain;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Phase 16: schreibt {@code db/sql/04_startdaten.sql} aus {@link Startdaten} und der Szene (Gelände aus
 * {@code daten/gelaende}, Siedlung mit Startwert 950, Flotte, Fahrt „Durch die Gasse“). Aufruf:
 * {@code StartdatenSql [daten/gelaende] [db/sql/04_startdaten.sql]}. Die Prüfung vergleicht die Datei mit dem, was
 * dieses Werkzeug jetzt schreiben würde.
 */
public final class StartdatenSql {
    public static void main(String[] a) throws Exception {
        File dir = new File(a.length > 0 ? a[0] : "daten/gelaende");
        File out = new File(a.length > 1 ? a[1] : "db/sql/04_startdaten.sql");
        String sql = erzeugen(dir);
        Files.writeString(out.toPath(), sql, StandardCharsets.UTF_8);
        System.out.println(out + ": " + sql.length() / 1024 + " kB, " + sql.lines().filter(l -> l.startsWith("-- ZAHLEN")).findFirst().orElse(""));
    }

    /** Das Skript aus dem Gelände in dir. */
    public static String erzeugen(File dir) {
        return com.dan.haithabu.data.StartdatenSql.sql(szene(dir));
    }

    /** Die Szene der Startdaten: Siedlung 950, Flotte, Fahrt „Durch die Gasse“. */
    public static Startdaten.Szene szene(File dir) {
        Terrain t = Terrain.load(dir);
        Siedlung s = Siedlung.haithabu(t);
        Flotte f = Flotte.of(t, s.hafen);
        Feuer fe = Feuer.of(t, s);
        com.dan.haithabu.camera.Fahrt g = fe.hall == null ? null : new com.dan.haithabu.camera.Fahrt("Durch die Gasse", fe.hall.gasse(s, t), 75, 0, 3);
        if (g != null) { g.endHeading = fe.hall.imHaus()[3]; g.endTurn = 6; }
        return Startdaten.szene(t, s, f, Startdaten.punkte(g), dir);
    }

    private StartdatenSql() { }
}
