package com.dan.haithabu.tools;

import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.wiring.Beaufort;
import com.dan.haithabu.wiring.Wiring;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLDrawableFactory;
import com.jogamp.opengl.GLOffscreenAutoDrawable;
import com.jogamp.opengl.GLProfile;

import java.io.File;
import java.time.LocalDate;
import java.util.Locale;

/**
 * Tempo-Probe und Standbild ohne Fenster (aus Lighthouse). Rechnet die Szene unsichtbar in fester Größe, misst die
 * Wanduhr je Bild bis glFinish und die Zeit jedes Durchgangs auf der Grafikkarte und schreibt auf Wunsch ein PNG. So
 * lässt sich jede Phase vorher und nachher vergleichen und im Leistungsbudget (Werkbuch, Abschnitt 10) eintragen.
 * <pre>
 * Tempo [bilder] [breite] [höhe] [png|-] [NIEDRIG|MITTEL|HOCH|ULTRA] [uhrzeit] [datum JJJJ-MM-TT] [beaufort]
 * Tempo 120 1920 1080 docs/status/Tempo_Phase1.png MITTEL 17.5 0950-10-16 3
 * Umgebung: OHNE_HUD, OHNE_MARKEN, ANSICHT=oben oder der Name einer Ansicht (Hochburg, AmBach, VomWall, …),
 * GELAENDE=ordner (statt daten/gelaende), VORLAUF=s (die See und die Halme laufen erst so lange);
 * ab Phase 3: REGIE=nebelmorgen|sturmtag|nebeltag|frei (die Wetterregie läuft vom Beginn des Regiebuchs bis zur
 * Uhrzeit), sonst von Hand WOLKEN=Achtel, WOLKENART=CUMULUS|STRATUS|…, REGEN=mm/h, NEBEL=0..1, GEWITTER=0..4, SICHT=km;
 * ab Phase 2b: OHNE_WALD, KAMERA=x,z,Richtung,Neigung,Höhe (frei stehend); ab Phase 5: OHNE_HAEUSER
 * </pre>
 */
public final class Tempo {
    private Tempo() { }

    public static void main(String[] a) throws Exception {
        int frames = a.length > 0 ? Integer.parseInt(a[0]) : 120;
        int w = a.length > 1 ? Integer.parseInt(a[1]) : 1920, h = a.length > 2 ? Integer.parseInt(a[2]) : 1080;
        File png = a.length > 3 && !a[3].equals("-") ? new File(a[3]) : null;
        Quality q = a.length > 4 ? Quality.valueOf(a[4]) : Quality.MITTEL;
        double hour = a.length > 5 ? Double.parseDouble(a[5].replace(',', '.')) : SceneClock.START_HOUR;
        LocalDate day = a.length > 6 && !a[6].equals("-") ? LocalDate.parse(a[6]) : SceneClock.START_DATE;
        int bft = a.length > 7 ? Integer.parseInt(a[7]) : 3;

        GLProfile prof = GLProfile.get(GLProfile.GL4);
        GLCapabilities caps = new GLCapabilities(prof);
        caps.setOnscreen(false);
        caps.setFBO(true);
        caps.setDepthBits(24);
        GLOffscreenAutoDrawable d = GLDrawableFactory.getFactory(prof).createOffscreenAutoDrawable(null, caps, null, w, h);
        d.setAutoSwapBufferMode(false);
        SceneClock clock = new SceneClock(day, hour);
        clock.lapse = 0;
        Wiring wiring = new Wiring(clock);
        wiring.wind.speed = Beaufort.mid(bft);
        String regie = System.getenv("REGIE");
        if (regie != null) {
            com.dan.weather.Scenario sc = switch (regie.toLowerCase(Locale.ROOT)) {
                case "nebelmorgen" -> com.dan.weather.Scenario.autumnFogMorning();
                case "sturmtag" -> com.dan.weather.Scenario.stormDay();
                case "nebeltag" -> com.dan.weather.Scenario.fogDay();
                default -> null;
            };
            wiring.regie = true;
            if (sc != null) {
                clock.set(day, sc.startHour());
                wiring.start(sc);
                clock.set(day, hour);
            } else wiring.startFree(com.dan.weather.Weather.Phase.KLAR);
            wiring.feedWeather(0);
        } else {
            String v;
            if ((v = System.getenv("WOLKEN")) != null) wiring.oktas = Double.parseDouble(v);
            if ((v = System.getenv("WOLKENART")) != null) wiring.cloudType = com.dan.cloud.CloudType.valueOf(v);
            if ((v = System.getenv("REGEN")) != null) wiring.rainRate = Double.parseDouble(v);
            if ((v = System.getenv("NEBEL")) != null) wiring.fogAmount = Double.parseDouble(v);
            if ((v = System.getenv("GEWITTER")) != null) wiring.thunderstorm = com.dan.lightning.Lightning.Level.values()[Integer.parseInt(v)];
            if ((v = System.getenv("SICHT")) != null) wiring.visibilityKm = Double.parseDouble(v);
        }
        java.io.File gd = System.getenv("GELAENDE") != null ? new java.io.File(System.getenv("GELAENDE")) : com.dan.haithabu.scene.Terrain.defaultDir();
        Renderer r = new Renderer(clock, wiring, com.dan.haithabu.scene.Terrain.load(gd));
        r.frozen = true;
        r.setQuality(q);
        r.autoScale = false;
        if (System.getenv("OHNE_HUD") != null) r.showHud = false;
        if (System.getenv("OHNE_MARKEN") != null) r.showMarks = false;
        if (System.getenv("OHNE_NEBEL") != null) r.showFog = false;
        if (System.getenv("OHNE_WALD") != null) r.showForest = false;
        if (System.getenv("OHNE_HAEUSER") != null) r.showHouses = false;
        String an = System.getenv("ANSICHT");
        if ("oben".equals(an)) { r.camera.lookAt(-100, 0, -100, 0, 89, 2600); r.camera.snap(); }
        else if (an != null && com.dan.haithabu.camera.Ansichten.byName(an) != null)
            com.dan.haithabu.camera.Ansichten.apply(com.dan.haithabu.camera.Ansichten.byName(an), r.camera, r.terrain);
        String kam = System.getenv("KAMERA");   // x,z,Richtung,Neigung,Höhe über Grund (frei)
        if (kam != null) {
            String[] k = kam.split(",");
            double kx = Double.parseDouble(k[0]), kz = Double.parseDouble(k[1]);
            r.camera.place(kx, Math.max(0, r.terrain.height(kx, kz)) + Double.parseDouble(k[4]), kz, Double.parseDouble(k[2]), Double.parseDouble(k[3]));
        }
        d.addGLEventListener(r);
        d.display();
        if (r.error() != null) { System.err.println("FEHLER: " + r.error()); System.exit(2); }
        // Phase 2b: warten, bis der Wald gebacken ist, und alle Kacheln um die Kamera bepflanzen
        for (int i = 0; i < 1200 && !r.forestReady() && r.showForest; i++) { Thread.sleep(50); d.display(); }
        r.forest.completeNow(r.camera.eye);
        double vor = System.getenv("VORLAUF") != null ? Double.parseDouble(System.getenv("VORLAUF")) : 0;
        for (int i = 0; i < 10 + (int) (vor * 10); i++) { r.step(1 / 60.0); d.display(); Thread.sleep(vor > 0 ? 20 : 0); }
        double best = Double.MAX_VALUE, sum = 0;
        for (int i = 0; i < frames; i++) {
            long t0 = System.nanoTime();
            r.step(1 / 60.0);
            d.display();
            d.getContext().makeCurrent();
            d.getGL().glFinish();
            d.getContext().release();
            double ms = (System.nanoTime() - t0) / 1e6;
            best = Math.min(best, ms);
            sum += ms;
        }
        System.out.println(r.glInfo());
        System.out.println(r.compute() == null ? "Compute-Test: nicht gelaufen" : r.compute().line());
        System.out.printf(Locale.GERMAN, "%d×%d %s, %s: bestes Bild %.2f ms, Mittel %.2f ms (%.0f Bilder/s)%n", w, h, q.label, clock.label(), best, sum / frames, 1000 / (sum / frames));
        System.out.println("Durchgänge (ms): " + r.passTimes());
        for (String l : r.hudLines()) System.out.println("  " + l);
        if (png != null) {
            File dir = png.getAbsoluteFile().getParentFile();
            if (dir != null) dir.mkdirs();
            final java.awt.image.BufferedImage[] img = new java.awt.image.BufferedImage[1];
            d.invoke(true, x -> { img[0] = r.grab(x); return true; });
            javax.imageio.ImageIO.write(img[0], "png", png);
            System.out.println("Bild: " + png.getPath());
        }
        d.destroy();
        System.exit(0);
    }
}
