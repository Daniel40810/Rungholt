package com.dan.haithabu.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Das Programmsymbol (F18 A): ein Langschiff vor Reetdächern mit Rauch, Abendhimmel, Goldkante wie heidelberg.ico.
 * Seit Phase 17 liegen die PNGs im Jar unter {@code com/dan/haithabu/ui/icon/haithabu_NN.png} und als
 * {@code icon/haithabu.ico} für die Verknüpfung (beides schreibt {@code tools.Symbol}); fehlt eine Größe, malt die App sie selbst.
 */
public final class AppIcon {
    public static final int[] SIZES = {16, 24, 32, 48, 64, 128, 256};

    private AppIcon() { }

    public static List<Image> images() {
        List<Image> l = new ArrayList<>();
        for (int s : SIZES) l.add(load(s));
        return l;
    }

    public static BufferedImage load(int size) {
        try (InputStream in = AppIcon.class.getResourceAsStream("icon/haithabu_" + size + ".png")) {
            if (in != null) {
                BufferedImage b = javax.imageio.ImageIO.read(in);
                if (b != null) return b;
            }
        } catch (java.io.IOException e) { /* gemaltes Symbol */ }
        return paint(size);
    }

    /** Das Symbol, in jeder Größe neu gemalt. */
    public static BufferedImage paint(int s) {
        BufferedImage im = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        double r = s * 0.18, inset = Math.max(1, s * 0.035);
        // Goldkante
        g.setPaint(new GradientPaint(0, 0, new Color(240, 210, 120), s, s, new Color(150, 105, 30)));
        g.fill(new RoundRectangle2D.Double(0, 0, s, s, r * 2, r * 2));
        RoundRectangle2D inner = new RoundRectangle2D.Double(inset, inset, s - 2 * inset, s - 2 * inset, r * 1.7, r * 1.7);
        // Abendhimmel: oben Nacht, unten Glut
        g.setPaint(new GradientPaint(0, 0, new Color(22, 30, 46), 0, (float) (s * 0.62), new Color(196, 98, 42)));
        g.fill(inner);
        g.setClip(inner);
        // Sonne knapp über dem Ufer
        g.setPaint(new RadialGradientPaint((float) (s * 0.70), (float) (s * 0.56), (float) (s * 0.22),
                new float[]{0f, 0.25f, 1f}, new Color[]{new Color(255, 214, 140, 255), new Color(255, 170, 80, 170), new Color(255, 140, 60, 0)}));
        g.fill(new Ellipse2D.Double(s * 0.48, s * 0.34, s * 0.44, s * 0.44));
        double shore = s * 0.60;
        // Rauch aus den Firsten, vom Wind nach rechts getragen
        if (s >= 24) {
            g.setStroke(new BasicStroke((float) Math.max(1, s * 0.035), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int k = 0; k < 3; k++) {
                double x0 = s * (0.18 + 0.22 * k), y0 = shore - s * (0.17 + 0.03 * (k % 2));
                Path2D p = new Path2D.Double();
                p.moveTo(x0, y0);
                p.curveTo(x0 - s * 0.03, y0 - s * 0.08, x0 + s * 0.05, y0 - s * 0.12, x0 + s * 0.12, y0 - s * 0.19);
                g.setColor(new Color(200, 205, 205, 120));
                g.draw(p);
            }
        }
        // Reetdächer als dunkle Giebel am Ufer
        Color dach = new Color(34, 26, 20);
        double[][] haus = {{0.02, 0.30, 0.16}, {0.26, 0.24, 0.13}, {0.47, 0.28, 0.17}, {0.73, 0.30, 0.13}};
        for (double[] hz : haus) {
            double x = s * hz[0], w = s * hz[1], hgt = s * hz[2];
            Path2D p = new Path2D.Double();
            p.moveTo(x, shore);
            p.lineTo(x + w * 0.12, shore - hgt * 0.45);
            p.lineTo(x + w * 0.5, shore - hgt);
            p.lineTo(x + w * 0.88, shore - hgt * 0.45);
            p.lineTo(x + w, shore);
            p.closePath();
            g.setColor(dach);
            g.fill(p);
            // Glut in der Tür
            if (s >= 32) {
                g.setColor(new Color(255, 150, 60, 220));
                g.fill(new java.awt.geom.Rectangle2D.Double(x + w * 0.45, shore - hgt * 0.24, w * 0.1, hgt * 0.24));
            }
        }
        // Noor
        g.setPaint(new GradientPaint(0, (float) shore, new Color(70, 64, 60), 0, s, new Color(14, 26, 30)));
        g.fill(new java.awt.geom.Rectangle2D.Double(0, shore, s, s - shore));
        // Glitzerpfad der Sonne
        if (s >= 24) {
            g.setColor(new Color(255, 190, 110, 120));
            for (int i = 0; i < 4; i++) {
                double y = shore + s * (0.04 + 0.05 * i), w = s * (0.10 - 0.015 * i);
                g.fill(new java.awt.geom.Rectangle2D.Double(s * 0.70 - w / 2, y, w, Math.max(1, s * 0.012)));
            }
        }
        // Langschiff mit Rahsegel und hohen Steven
        double bx = s * 0.12, bw = s * 0.70, by = shore + s * 0.17, bh = s * 0.075;
        Path2D hull = new Path2D.Double();
        hull.moveTo(bx, by - bh * 1.9);
        hull.curveTo(bx + bw * 0.02, by - bh * 0.6, bx + bw * 0.10, by + bh * 0.5, bx + bw * 0.28, by + bh * 0.55);
        hull.lineTo(bx + bw * 0.72, by + bh * 0.55);
        hull.curveTo(bx + bw * 0.90, by + bh * 0.5, bx + bw * 0.98, by - bh * 0.6, bx + bw, by - bh * 1.9);
        hull.curveTo(bx + bw * 0.93, by - bh * 0.3, bx + bw * 0.85, by - bh * 0.15, bx + bw * 0.72, by - bh * 0.1);
        hull.lineTo(bx + bw * 0.28, by - bh * 0.1);
        hull.curveTo(bx + bw * 0.15, by - bh * 0.15, bx + bw * 0.07, by - bh * 0.3, bx, by - bh * 1.9);
        hull.closePath();
        g.setColor(new Color(20, 14, 10));
        g.fill(hull);
        double mx = bx + bw * 0.5;
        g.setStroke(new BasicStroke((float) Math.max(1, s * 0.022)));
        g.draw(new java.awt.geom.Line2D.Double(mx, by - bh * 0.1, mx, by - s * 0.27));
        Path2D sail = new Path2D.Double();
        sail.moveTo(mx - s * 0.15, by - s * 0.25);
        sail.lineTo(mx + s * 0.15, by - s * 0.25);
        sail.curveTo(mx + s * 0.17, by - s * 0.16, mx + s * 0.15, by - s * 0.10, mx + s * 0.14, by - s * 0.06);
        sail.lineTo(mx - s * 0.14, by - s * 0.06);
        sail.curveTo(mx - s * 0.15, by - s * 0.10, mx - s * 0.17, by - s * 0.16, mx - s * 0.15, by - s * 0.25);
        sail.closePath();
        g.setColor(new Color(150, 44, 32));
        g.fill(sail);
        if (s >= 48) {
            g.setColor(new Color(225, 205, 170));
            g.setStroke(new BasicStroke((float) Math.max(1, s * 0.03)));
            for (int i = 1; i < 3; i++) {
                double x = mx - s * 0.15 + s * 0.3 * i / 3;
                g.draw(new java.awt.geom.Line2D.Double(x, by - s * 0.245, x, by - s * 0.065));
            }
            // Schilde am Bord
            for (int i = 0; i < 7; i++) {
                double x = bx + bw * (0.27 + 0.075 * i);
                g.setColor(i % 2 == 0 ? new Color(217, 180, 90) : new Color(170, 50, 36));
                g.fill(new Ellipse2D.Double(x - s * 0.018, by - bh * 0.35, s * 0.036, s * 0.036));
            }
        }
        g.dispose();
        return im;
    }

    /** Setzt das Symbol am Fenster und, wo unterstützt, in der Taskleiste. */
    public static void install(java.awt.Window w) {
        List<Image> l = images();
        w.setIconImages(l);
        try {
            if (java.awt.Taskbar.isTaskbarSupported()) {
                java.awt.Taskbar tb = java.awt.Taskbar.getTaskbar();
                if (tb.isSupported(java.awt.Taskbar.Feature.ICON_IMAGE)) tb.setIconImage(l.get(l.size() - 1));
            }
        } catch (Exception | Error ignored) {
            // Windows nimmt ohnehin die Fenstersymbole
        }
    }
}
