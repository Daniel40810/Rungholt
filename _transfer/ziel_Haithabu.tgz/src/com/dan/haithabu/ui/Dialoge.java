package com.dan.haithabu.ui;

import com.dan.fbutton.FButton;
import com.dan.foptionpane.FOptionPane;
import com.dan.ftextarea.FTextArea;
import com.dan.haithabu.data.Daten;
import com.dan.haithabu.data.Datenseite;
import com.dan.haithabu.data.Startdaten;
import com.dan.haithabu.scene.Regie;
import com.dan.store.Ablage;
import com.dan.store.Dienst;
import com.dan.store.Protokoll;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Window;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/** Die Fenster des Bedienfelds: Regiebuch bearbeiten (F31 A) und „Was ist belegt?“ (F34 A). */
final class Dialoge {
    private Dialoge() { }

    static String frage(Component owner, String frage, String titel) {
        String s = FOptionPane.showInputDialog(owner, frage, titel, FOptionPane.QUESTION_MESSAGE);
        return s == null || s.isBlank() ? null : s.strip();
    }

    static void fehler(Component owner, String titel, String text) {
        SwingUtilities.invokeLater(() -> FOptionPane.showMessageDialog(owner, text, titel, FOptionPane.ERROR_MESSAGE));
    }

    private static JDialog fenster(Component owner, String titel) {
        Window w = owner == null ? null : SwingUtilities.getWindowAncestor(owner);
        JDialog d = new JDialog(w, titel, java.awt.Dialog.ModalityType.MODELESS);
        AppIcon.install(d);
        return d;
    }

    /**
     * Ein Regiebuch als Text bearbeiten: „Prüfen“ liest es wie beim Start (Befehle, Zeiten, Wetterblock), „Speichern
     * unter …“ legt es als eigenes Regiebuch ab (ein mitgeliefertes bleibt, wie es ist), „Starten“ spielt den Text
     * gleich ab, ohne zu speichern.
     */
    static void regiebuch(Component owner, Daten.Regiebuch rb, Consumer<Daten.Regiebuch> gespeichert, Consumer<Regie.Book> starten) {
        JDialog d = fenster(owner, "Regiebuch · " + rb.name());
        FTextArea text = new FTextArea(32, 92);
        text.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        text.setText(rb.text());
        text.setCaretPosition(0);
        JLabel status = ControlPanel.small(" ");
        status.setBorder(BorderFactory.createEmptyBorder(6, 2, 6, 2));
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setBackground(Theme.bg());
        p.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        p.add(ControlPanel.small("<html><body style='width:640px'>Kopf: <tt>Regiebuch:</tt>, <tt>Beschreibung:</tt>, <tt>Länge: m:ss</tt>, wahlweise <tt>Wetter:</tt> mit "
                + "Schritten <tt>hh:mm | Raffer</tt> und <tt>Schritt: …</tt>. Dann je Zeile <tt>m:ss befehl argumente | Text im HUD</tt>. Befehle: "
                + String.join(", ", Regie.BEFEHLE) + ".</body></html>"), BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(text);
        sp.setPreferredSize(new Dimension(820, 520));
        p.add(sp, BorderLayout.CENTER);
        JPanel unten = new JPanel(new BorderLayout());
        unten.setOpaque(false);
        unten.add(status, BorderLayout.CENTER);
        JPanel k = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        k.setOpaque(false);
        FButton pruefen = new FButton("Prüfen"), start = new FButton("Starten"), speichern = new FButton("Speichern unter …"), zu = new FButton("Schließen");
        k.add(pruefen);
        k.add(start);
        k.add(speichern);
        k.add(zu);
        unten.add(k, BorderLayout.EAST);
        p.add(unten, BorderLayout.SOUTH);
        pruefen.addActionListener(e -> {
            try {
                Regie.Book b = Regie.parse(text.getText());
                status.setText(String.format(Locale.GERMAN, "In Ordnung: „%s“, %s lang, %d Stichworte%s.", b.name(), Regie.zeit(b.length()), b.cues().size(),
                        b.weather() != null ? ", mit eigenem Wetter" : ""));
            } catch (RuntimeException ex) {
                status.setText("<html><body style='width:520px'><b>Fehler</b>: " + ex.getMessage() + "</body></html>");
            }
        });
        start.addActionListener(e -> {
            try { starten.accept(Regie.parse(text.getText())); } catch (RuntimeException ex) { status.setText("Fehler: " + ex.getMessage()); }
        });
        speichern.addActionListener(e -> {
            Regie.Book b;
            try { b = Regie.parse(text.getText()); } catch (RuntimeException ex) { status.setText("Fehler: " + ex.getMessage()); return; }
            String vorschlag = Daten.MITGELIEFERT.equals(rb.herkunft()) ? b.name() + " (eigen)" : b.name();
            String name = frage(d, "Name des Regiebuchs (Vorschlag: " + vorschlag + ")", "Regiebuch speichern");
            if (name == null) name = vorschlag;
            if (Daten.MITGELIEFERT.equals(rb.herkunft()) && name.equals(rb.name())) { status.setText("Ein mitgeliefertes Regiebuch bleibt; bitte einen anderen Namen."); return; }
            // der Name im Text folgt dem Namen in der Liste
            String t = text.getText().replaceFirst("(?m)^Regiebuch:.*$", "Regiebuch: " + java.util.regex.Matcher.quoteReplacement(name));
            Daten.Regiebuch neu = new Daten.Regiebuch(name, t, b.about(), Daten.EIGEN);
            Dienst.spaeter(() -> {
                try {
                    Datenseite.speicher().speichern(neu);
                    Protokoll.info("Regiebuch", "„" + neu.name() + "“ gespeichert in " + Datenseite.speicher().wo());
                    SwingUtilities.invokeLater(() -> { text.setText(t); status.setText("Gespeichert: „" + neu.name() + "“ in " + Datenseite.speicher().wo()); gespeichert.accept(neu); });
                } catch (Ablage.Fehler ex) {
                    SwingUtilities.invokeLater(() -> status.setText("Nicht gespeichert: " + ex.getMessage()));
                }
            });
        });
        zu.addActionListener(e -> d.dispose());
        d.setContentPane(p);
        d.pack();
        d.setLocationRelativeTo(owner);
        d.setVisible(true);
    }

    /** Ein Fenster mit Text zum Lesen (Ergebnis des Einrichters). */
    static void text(Component owner, String titel, JLabel inhalt) {
        inhalt.setForeground(Theme.ink());
        inhalt.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Theme.bg());
        p.add(inhalt, BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(p);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.setPreferredSize(new Dimension(640, 460));
        JDialog d = fenster(owner, "Haithabu · " + titel);
        d.setContentPane(sp);
        d.pack();
        d.setLocationRelativeTo(owner);
        d.setVisible(true);
    }

    /** „Was ist belegt?“: alle Befunde nach Thema, mit Quellen; dazu die Zahl je Art. */
    static void befunde(Component owner) {
        List<Daten.Befund> l;
        List<Daten.Quelle> q;
        try { l = Datenseite.speicher().befunde(); q = Datenseite.speicher().quellen(); } catch (Ablage.Fehler e) { l = Startdaten.befunde(); q = Startdaten.quellen(); }
        if (l.isEmpty()) { l = Startdaten.befunde(); q = Startdaten.quellen(); }
        Map<String, List<Daten.Befund>> nach = new LinkedHashMap<>();
        Map<String, Integer> art = new LinkedHashMap<>();
        art.put("BELEGT", 0);
        art.put("GEMESSEN", 0);
        art.put("GESTALTET", 0);
        for (Daten.Befund b : l) {
            nach.computeIfAbsent(b.thema(), k -> new ArrayList<>()).add(b);
            art.merge(b.befund(), 1, Integer::sum);
        }
        StringBuilder h = new StringBuilder("<html><body style='width:700px;font-family:sans-serif;font-size:11px'>");
        h.append(String.format(Locale.GERMAN, "<p>%d Befunde: <b>%d belegt</b> (aus Literatur und Fund), <b>%d gemessen</b> (aus dem Gelände), <b>%d gestaltet</b> (begründete Annahme der Szene, im Werkbuch [G]).</p>",
                l.size(), art.get("BELEGT"), art.get("GEMESSEN"), art.get("GESTALTET")));
        for (Map.Entry<String, List<Daten.Befund>> e : nach.entrySet()) {
            h.append("<h3 style='margin:10px 0 2px 0'>").append(e.getKey()).append("</h3><table cellspacing=0 cellpadding=2>");
            for (Daten.Befund b : e.getValue()) {
                String farbe = switch (b.befund()) { case "BELEGT" -> "#7fb37f"; case "GEMESSEN" -> "#7fa8c8"; default -> "#c8a46a"; };
                h.append("<tr><td valign=top width=150><b>").append(b.gegenstand()).append("</b></td><td valign=top width=80 style='color:").append(farbe).append("'>")
                        .append(b.befund().toLowerCase(Locale.GERMAN)).append("</td><td valign=top>").append(b.text());
                if (!b.quellen().isEmpty()) h.append(" <i>(").append(String.join(", ", b.quellen())).append(")</i>");
                h.append("</td></tr>");
            }
            h.append("</table>");
        }
        h.append("<h3 style='margin:12px 0 2px 0'>Quellen</h3>");
        for (Daten.Quelle x : q) h.append("<b>").append(x.kurz()).append("</b>: ").append(x.titel()).append(x.url() != null ? " · " + x.url() : "").append("<br>");
        h.append("</body></html>");
        JLabel inhalt = new JLabel(h.toString());
        inhalt.setForeground(Theme.ink());
        inhalt.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Theme.bg());
        p.add(inhalt, BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(p);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.setPreferredSize(new Dimension(780, 620));
        JDialog d = fenster(owner, "Haithabu · Was ist belegt?");
        d.setContentPane(sp);
        d.pack();
        d.setLocationRelativeTo(owner);
        d.setVisible(true);
    }
}
