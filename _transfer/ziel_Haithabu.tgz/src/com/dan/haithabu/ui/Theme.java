package com.dan.haithabu.ui;

import com.dan.fstyle.FTheme;

import java.awt.Color;

/**
 * Die Farben der Oberfläche aus FTheme (Bedienelemente in FTheme-Farben, die Szene hat ihren eigenen Look; aus
 * Lighthouse). Liefert das Thema keine dunklen Farben, nimmt die App ihre Torfnacht, damit der Rand um die Szene
 * nicht hell aufleuchtet. Dazu die Farben des Werkbuchs: Glut, Reet, Schleiwasser, Eichenholz.
 */
public final class Theme {
    private Theme() { }

    public static final Color TORF = new Color(15, 19, 17), GLUT = new Color(226, 122, 46), REET = new Color(217, 180, 90),
            SCHLEI = new Color(91, 163, 168), HOLZ = new Color(176, 127, 69), RAUCH = new Color(184, 194, 196), HELL = new Color(232, 230, 222);

    public static Color bg() { return pick(FTheme::getBackground, TORF, Role.DARK); }
    public static Color surface() { return pick(FTheme::getSurface, new Color(23, 29, 25), Role.DARK); }
    public static Color ink() { return pick(FTheme::getText, HELL, Role.LIGHT); }
    public static Color muted() { return pick(FTheme::getTextMuted, new Color(152, 162, 154), Role.LIGHT); }
    public static Color accent() { return pick(FTheme::getAccent, GLUT, Role.ANY); }
    public static Color status() { return new Color(10, 13, 11); }
    public static Color line() { return new Color(42, 52, 45); }

    private enum Role { DARK, LIGHT, ANY }

    private static Color pick(java.util.function.Function<FTheme, Color> f, Color fallback, Role role) {
        try {
            Color c = f.apply(FTheme.getInstance());
            if (c == null) return fallback;
            int lum = (c.getRed() * 3 + c.getGreen() * 6 + c.getBlue()) / 10;
            if (role == Role.DARK && lum > 70) return fallback;
            if (role == Role.LIGHT && lum < 120) return fallback;
            return c;
        } catch (RuntimeException | Error e) {
            return fallback;
        }
    }
}
