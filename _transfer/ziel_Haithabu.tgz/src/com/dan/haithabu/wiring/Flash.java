package com.dan.haithabu.wiring;

/** Ein Blitz. Gibt: {@code lightning} (Phase 3). Nimmt: cloud, ocean, weathering, sky, hearth (Einschlag in Reet), soundscape. */
@FunctionalInterface
public interface Flash {
    /** Ort des Kanals (Mitte), Stärke 0..1, Szenenzeit in s, Dauer in s. */
    void flash(double x, double y, double z, double strength, double time, double duration);
}
