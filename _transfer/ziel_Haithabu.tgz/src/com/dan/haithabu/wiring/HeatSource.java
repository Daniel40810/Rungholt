package com.dan.haithabu.wiring;

/**
 * Eine Wärmequelle, aus der Rauch aufsteigt: Herdfeuer unter dem First, Feuerstelle am Ufer, Schmiede, ein
 * brennendes Haus. Gibt: hearth (Phase 10), timber nennt die Rauchlöcher (Phase 4). Nimmt: {@code smoke}.
 */
public interface HeatSource {
    /** Austritt des Rauchs (Rauchloch, Firstöffnung, offene Glut) in m der Szene. */
    double[] position();

    /** Wärmeleistung in kW (Herdfeuer rund 10, Brand eines Hauses einige tausend). */
    double heatKw();

    /** Rauchmenge 0..1 und Schwärze 0..1 (0 = weißer Holzrauch, 1 = schwarzer Rauch aus Reet und Teer). */
    double smoke();
    default double blackness() { return 0; }
}
