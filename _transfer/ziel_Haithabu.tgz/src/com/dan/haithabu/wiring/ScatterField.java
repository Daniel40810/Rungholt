package com.dan.haithabu.wiring;

/**
 * Streudichte der Luft am Ort: Nebel, Regen, Rauch. Gibt: fog, rain, smoke. Nimmt: die Lichtstrahlen im
 * Versammlungshaus (Phase 11) und der Nebel-Durchgang. Die App addiert die Felder aller Geber.
 */
@FunctionalInterface
public interface ScatterField {
    /** Streukoeffizient in 1/m am Ort (x, y, z). */
    double density(double x, double y, double z);
}
