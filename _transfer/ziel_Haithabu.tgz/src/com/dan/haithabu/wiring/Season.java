package com.dan.haithabu.wiring;

/**
 * Die Jahreszeit als Zahlen. Gibt: {@code season} (Phase 12). Nimmt: forest (Laub), reed (Halme), timber und ground
 * (Schnee auf Reet, Wall und Boden), ocean (Eisrand), weather (passende Lagen).
 */
public interface Season {
    /** Anteil des Laubs am Baum 0..1 und seine Färbung 0 = grün … 1 = braun. */
    double foliage();
    double autumn();

    /** Schneehöhe in m auf ebenem Boden und Eisgrenze am Ufer (m vom Ufer ins Noor, 0 = offen). */
    double snowDepth();
    double iceReach();
}
