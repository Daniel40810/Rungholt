package com.dan.haithabu.wiring;

/**
 * Ein Ereignis für den Klang. Gibt: longship (Ruderschlag, Dollen), hearth (Knistern, Einsturz), flock, lightning,
 * die Tiere und Gewerke der Siedlung. Nimmt: {@code soundscape} (Phase 14, F20 A).
 */
@FunctionalInterface
public interface SoundEvent {
    enum Kind { RUDERSCHLAG, DOLLE, HAMMER, SAEGE, FEUER, EINSTURZ, MOEWE, KRAEHE, ENTE, HUHN, ZIEGE, HUND, DONNER, STIMMEN, GLOCKE }

    void sound(Kind kind, double x, double y, double z, double strength);
}
