package com.dan.haithabu.wiring;

/**
 * Ein Einschlag auf einer Fläche: Regentropfen, Riemenschlag, Funke. Gibt: rain, longship, hearth. Nimmt:
 * {@code ocean.addImpulse}, {@code weathering.wet}, hearth (Funke auf Reet). Die App verteilt nach dem, was
 * getroffen wurde.
 */
@FunctionalInterface
public interface SurfaceHit {
    enum Kind { TROPFEN, RIEMEN, FUNKE }

    /** Ort, Masse in kg, Geschwindigkeit in m/s, Art. */
    void hit(double x, double y, double z, double massKg, double vx, double vy, double vz, Kind kind);
}
