package com.dan.haithabu.wiring;

/**
 * Wasserspiegel des Noors in m über dem Mittelwasser von 950 (y = 0 der Szene). Das Noor hat keine Tide; es steigt
 * und fällt mit dem Windstau (F7 A). Gibt: {@code weather} über die App (Phase 3). Nimmt: ocean, buoyancy, weathering,
 * longship, reed, Kamera.
 */
@FunctionalInterface
public interface WaterLevel {
    double level();
}
