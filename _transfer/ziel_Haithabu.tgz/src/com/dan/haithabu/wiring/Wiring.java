package com.dan.haithabu.wiring;

import com.dan.cloud.CloudType;
import com.dan.cloud.Clouds;
import com.dan.fog.Fog;
import com.dan.haithabu.scene.SceneClock;
import com.dan.lightning.Lightning;
import com.dan.ocean.Ocean;
import com.dan.rain.Rain;
import com.dan.reed.Reed;
import com.dan.season.Year;
import com.dan.sky.Sky;
import com.dan.weather.Scenario;
import com.dan.weather.Weather;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Die Verdrahtung der App (Paketvertrag Punkt 4): Hier und nur hier reden die Packages miteinander. Jedes Package
 * bietet Eingänge an und meldet Ereignisse über die kleinen Schnittstellen dieses Pakets; die Phasen 2 bis 15 hängen
 * ihre Verbindungen hier ein. Wo ein Package eine eigene Kopie einer Schnittstelle mitbringt (gleicher Name, gleiche
 * Form), übersetzt {@code wiring} mit einer Zeile.
 * <p>
 * Phase 1: Uhr, Wind von Hand, fester Wasserstand; alle Schnittstellen stehen. Phase 2: das Gelände aus den
 * Höhendaten als {@link Terrain}; das Noor ({@code com.dan.ocean}) bekommt Wind und Wasserstand und das Gelände als
 * Grund; Schilf, Binsen und Gras ({@code com.dan.reed}) bekommen Wind, Böigkeit und Jahreszeit.
 * <p>
 * Phase 3 (wie Lighthouse): die Wetterregie ({@code com.dan.weather}) setzt je Bild Wind, Böen, Bedeckung, Wolkenart,
 * Regen, Sicht, Nebel, Gewitter und Temperatur; Handregler überschreiben einzelne Größen. Daraus bekommen Himmel
 * ({@code sky}), Wolken ({@code cloud}), Regen ({@code rain}), Nebel ({@code fog}), Blitz ({@code lightning}), Noor
 * und Halme ihre Eingänge. Anders als am Roten Sand: der Wind der Regie gilt über See, am Noor weht er im Windschatten
 * der Hänge schwächer ({@link #LAND_WIND}) [G]; der Nebel ist Strahlungsnebel, flach über Wasser und Niederung, und
 * hebt sich am Morgen, wenn die Sonne steigt ({@link #feed(Fog, double)}); Blitze schlagen ins Gelände.
 * {@link #planned()} zeigt, was nach dem Phasenplan kommt, {@link #links()} was schon verbunden ist.
 */
public final class Wiring {
    /** Eine Verbindung: von wem, an wen, über welche Schnittstelle, in welcher Phase. */
    public record Link(String from, String to, String via, int phase) {
        @Override public String toString() { return from + " → " + to + " (" + via + ", Phase " + phase + ")"; }
    }

    /** Wind: von Hand oder (ab Phase 3) aus der Regie. Start: Bft 3 aus Westsüdwest [G]. */
    public static final class ManualWind implements Wind {
        public volatile double speed = Beaufort.mid(3), fromDeg = 245, gust = 0.2;
        @Override public double speed() { return speed; }
        @Override public double fromDeg() { return fromDeg; }
        @Override public double gustiness() { return gust; }
    }

    /** Wasserspiegel von Hand (Windstau; das Noor hat keine Tide). */
    public static final class ManualLevel implements WaterLevel {
        public volatile double level;
        @Override public double level() { return level; }
    }

    /**
     * Phase 3: Anteil des Winds der Regie (Werte über See) am Noor: im Windschatten der Hänge und über rauem Land
     * rund 80 % [G].
     */
    public static final double LAND_WIND = 0.8;

    public final Clock clock;
    public final ManualWind wind = new ManualWind();
    public final ManualLevel waterLevel = new ManualLevel();
    private final List<Link> links = new ArrayList<>();

    /**
     * Was der Phasenplan an Verbindungen vorsah und noch offen ist (Abgleich in Phase 16): Rauch, Feuerlicht, Kielwasser,
     * Streufeld und Klang sind seit Phase 9 bis 14 verbunden ({@link #links()}); die Pfähle stehen seit Phase 8 im Noor.
     * Offen bleibt nur der Regen, der unter Dächern und Plattformen nicht fallen soll.
     */
    private static final List<Link> PLANNED = List.of(
            new Link("timber", "rain", "Collider (kein Regen unter Dächern und Plattformen)", 4));

    /** Phase 2: das Gelände (die App setzt es, sobald es geladen ist). */
    public volatile Terrain terrain;
    /**
     * Phase 2: Jahreszeit 0..1 für die Halme, von Hand (0 Sommer, 0,75 Mitte Oktober, 1 Winter). Seit Phase 12 nur
     * noch, solange {@link #yearOn} aus ist; sonst kommt sie aus {@code com.dan.season}.
     */
    public volatile double season = 0.75;

    // ------------------------------------------------------------------ Phase 12: das Jahr
    /** Das Jahr am Noor (Schnee, Eis, Reif, Pflanzen) aus dem Klima von Schleswig und dem Wetter des Augenblicks. */
    public final Year year = new Year();
    /** Ob das Jahr die Eingänge setzt (die App schaltet es ein; Werkzeuge und Prüfungen setzen die Felder selbst). */
    public volatile boolean yearOn;
    /** Stand des Jahrs zuletzt (null bis zum ersten Schritt). */
    public volatile Year.State yearState;
    /** Niederschlag der Regie (mm/h, Schneewasserwert) und sein Anteil als Schnee; rainRate ist nur der Regen. */
    public volatile double precipRate, snowRate;

    // ------------------------------------------------------------------ Phase 3: Wetter
    /** Die Wetterregie; Szenenzeit aus der Uhr, Tagesgang der Temperatur in MEZ. */
    public final Weather weather = new Weather();
    /** Ob die Regie die Eingänge setzt (die App schaltet sie ein; Werkzeuge und Prüfungen setzen die Felder selbst). */
    public volatile boolean regie;
    /** Wind in der laufenden Böe (m/s), Luftdruck (hPa) und Tendenz, Lufttemperatur (°C). */
    public volatile double gustNow = Beaufort.mid(3), pressureHPa = 1013, pressureTendency, airTempC = 11;
    /** Sicht in km (Dunst), Regen in mm/h unter den dichtesten Wolken, Bedeckung in Achteln, hohe Schicht 0..1. */
    public volatile double visibilityKm = 25, rainRate = 0, oktas = 3, highCover = 0;
    public volatile CloudType cloudType = CloudType.CUMULUS;
    /** Gewitter 0..4 wie {@link Lightning.Level}. */
    public volatile Lightning.Level thunderstorm = Lightning.Level.OFF;
    /** Nebel 0..1 aus der Regie; Nebel zeichnen (Schalter im Bedienfeld). */
    public volatile double fogAmount;
    public volatile boolean fogOn = true;
    /** Lage nach einem Schauer für einen Regenbogen (0..1); Regenbogen von Hand, negativ = aus der Regie. */
    public volatile double showerEnd, rainbowHand = -1;
    /** Zeichnet die App echte Wolken? Dann bekommt der Himmel keinen Schleier mehr. */
    public volatile boolean cloudsDrawn;
    /** Untergrenze des Nebels zuletzt (m über dem Wasser; für HUD und Prüfung). */
    public volatile double fogBase, fogTop;

    public Wiring(Clock clock) {
        this.clock = clock;
        weather.zone = SceneClock.ZONE;
        link("App (Hand)", "ocean (Noor)", "Wind, WaterLevel", 2);
        link("Gelände", "ocean (Noor)", "Grund als Höhentextur (Uferdämpfung, Grundsicht)", 2);
        link("Gelände", "reed", "Terrain (Dichte, Boden)", 2);
        link("App (Hand)", "reed", "Wind, Jahreszeit", 2);
        link("Gelände", "Kamera", "Terrain", 2);
        link("Gelände", "forest (Wald, Erlenbruch)", "Terrain (Dichte je Art, Boden)", 2);
        link("Gelände", "ground (Bodendecke)", "Terrain (Bedeckung, Boden)", 2);
        link("Uhr, App (Hand)", "forest, ground", "Clock (Tag im Jahr: Laub), Wind", 2);
        link("forest", "Gelände, ground", "Sonnenschatten (eine Kaskade)", 2);
        link("Gelände", "timber (Höfe am Bach)", "Terrain (Häuser auf dem Boden, Wege und Zäune folgen ihm)", 5);
        link("timber", "reed, ground, Gelände", "Höfe frei (Fußböden, Wege, Boote), Hofboden", 5);
        link("timber", "Gelände, forest, ground", "Sonnenschatten der Häuser", 5);
        link("rain", "weathering", "Regen → Nässe, Trocknung mit Wind und Sonne", 5);
        link("weathering", "timber, forest", "Nässe (dunkler, Glanz)", 5);
        link("Uhr", "sky", "Clock → Zeit, Breite, Länge (Sonne, Mond, Sterne von 950)", 3);
        link("sky", "Gelände, ocean, reed, cloud, fog, rain", "Lighting (Sonne, Mond, Himmel, Dunst, vorbelichtet)", 3);
        link("sky, cloud", "Nachbearbeitung", "Augenanpassung, Stäbchensehen", 3);
        link("weather", "Wind, WaterLevel → ocean, reed, rain, fog, cloud", "Wind (80 % über Land), Böe", 3);
        link("weather", "cloud, rain, fog, sky, lightning", "Bedeckung, Art, Regen, Sicht, Nebel, Gewitter", 3);
        link("cloud", "Gelände, ocean", "Schattenkarte", 3);
        link("cloud", "rain, lightning", "Regenfeld, Durchlässigkeit", 3);
        link("rain", "ocean", "Ringe auf dem Noor (feine Störung)", 3);
        link("lightning", "cloud, ocean, Gelände", "Flash (Lichtpunkte)", 3);
        link("Gelände", "lightning", "Terrain (Einschlag am Boden)", 3);
        link("Hafen (timber)", "ocean", "ObstacleField (Brandungsring an den Pfählen)", 8);
        link("ocean", "buoyancy → longship", "Höhe des Noors an den Säulen des Rumpfs (Tauchen, Stampfen, Rollen)", 9);
        link("longship", "ocean", "Kielwasser und Riemenschläge (Ringwellen), Umriss in der Wasserlinie (HullMask)", 9);
        link("longship", "spray", "Riemenspritzer beim Einsetzen der Blätter (F22)", 9);
        link("Wind (80 % über Land)", "longship", "Segel, Rah, Wahl zwischen Segel und Riemen", 9);
        link("timber (Rauchlöcher), hearth", "smoke", "HeatSource (Herde, Essen, Feuerstelle)", 10);
        link("hearth", "timber, Gelände, smoke", "FireLight (bis 8 Punktlichter, vorbelichtet)", 10);
        link("weather, sky", "smoke, hearth", "Wind (80 % über Land), Stabilität (Abendinversion aus Sonne, Wind, Bedeckung)", 10);
        link("timber (Interior.Room)", "smoke (RoomSmoke), timber", "Raum: Hülle und Öffnungen (Sonne und Himmel nur durch Tür und Rauchloch)", 11);
        link("hearth (Herd, Glut, Lampen)", "smoke (RoomSmoke)", "HeatSource im Haus (Zwei-Zonen-Modell: Schicht, Abfluss durch die Rauchlöcher)", 11);
        link("smoke (RoomSmoke)", "timber, Lichtstrahlen im Haus", "ScatterField (die Rauchschicht dämpft Sonne, Himmel und Herdlicht)", 11);
        link("hearth, Versammlungshaus", "Nachbearbeitung", "Augenanpassung an Feuer und an das Licht im Haus", 11);
        weather.climate = year.climate.temp.clone();
        link("season (Klima)", "weather", "Jahreszeit: Temperatur der Lagen nach dem Tag, Gewitter im Sommer, Seenebel im Herbst, Stürme im Winter", 12);
        link("weather", "season", "Temperatur, Niederschlag, Bedeckung, Wind → Schnee, Schmelze, Eis, Reif", 12);
        link("season", "weather", "Abweichung des gewürfelten Tags vom Klima (kalter Winter, milder Herbst)", 12);
        link("season", "Gelände, timber, forest, ground, reed", "Schneehöhe je Fläche (Boden, Dächer, Kronen), Reif, Farbfaktoren (Gras, Felder, Laub, Schilf)", 12);
        link("season", "ocean, Eis", "Eisgrenze (Wassertiefe), Eis dämpft den Wind auf dem Noor", 12);
        link("season", "rain, Schneefall", "Niederschlag unter 0,5 °C als Schnee, über 2,5 °C als Regen", 12);
        link("season", "sky", "Rückstrahlung des Bodens (Schnee hellt den Himmel auf)", 12);
        link("Gelände, ocean, season (Eis)", "flock", "Water: offenes Wasser (tiefer als 25 cm, ohne Eis), Höhe der Wellen", 13);
        link("Hafen, timber", "flock", "Sitzplätze: Pfähle der Palisade, Brückenköpfe, Firste", 13);
        link("weather, sky, season", "flock", "Wind, Helligkeit, Tag im Jahr (Schwalben nur im Sommer)", 13);
        link("Auge, Hunde (herd), fahrende Schiffe", "flock", "Störer (Fluchtdistanz je Art)", 13);
        link("Gelände, Siedlung, Hafen", "herd", "Boden, Häuser gesperrt, Gehege, Decks der Plattformen", 13);
        link("Auge, sky, rain, season", "herd", "Störer, Tag und Nacht, Stall bei Regen und tiefem Schnee", 13);
        link("Hafen", "longship, buoyancy", "drei Fischerboote dümpeln an den Brücken", 13);
        // Phase 14: der Klang (F20 A)
        link("flock, herd", "soundscape", "SoundEvent: Rufe je Art (Krähe, Ente, Erpel, Schwalbe, Kormoran, Huhn, Hahn, Ziege, Schwein, Hund), Schwingen der Schwäne", 14);
        link("longship (Flotte)", "soundscape", "SoundEvent: Ruderschlag mit den Blättern im Wasser", 14);
        link("hearth (Feuer)", "soundscape", "Feuer nach ihrem Stand: Essen, Strand, Fackeln, Herd im Versammlungshaus (nur drinnen)", 14);
        link("Siedlung (Rollen)", "soundscape", "Werkstätten: Schmiede, Bronzegießer, Kammmacher, Säger, Zimmerleute, Bootsbauer; Arbeitszeit", 14);
        link("Hafen", "soundscape", "Pfähle (Glucksen der Wellen), Markt am Umschlagplatz nach der Tageszeit", 14);
        link("lightning", "soundscape", "SoundEvent: Donner vom Kanal (Abstände, Gewichte, Schläge)", 14);
        link("weather, ocean, reed, Versammlungshaus, Auge", "soundscape", "Wind, Regen, Wellen, Schilf und Reet, Raum Langhaus, Ohr", 14);
        // Phase 15: Regiebücher und Ereignisse (F13 A)
        link("Regie (Regiebücher)", "Uhr, weather, Kamera, Flotte", "Stichworte in echten Sekunden: Zeit, Zeitraffer, Wetter, Ansichten, Schiffe, Fotos", 15);
        link("Tagesregie", "Flotte", "die Knorr läuft um 15:30 aus und um 8 Uhr wieder ein", 15);
        link("Flotte (Brander)", "hearth (Blaze)", "der Brander zündet die Häuser am Ufer", 15);
        link("hearth (Blaze)", "timber", "Timber.burn: verkohlt, eingestürzt", 15);
        link("hearth (Blaze)", "smoke, Licht, HearthGl", "Rauch, Licht und Flammen der brennenden Häuser und des Branders", 15);
        link("hearth (Blaze)", "soundscape", "Brausen der Häuser, Einsturz, Aufruhr der Tiere", 15);
        // Phase 16: Oberfläche und Datenbank (F25–F36 A)
        link("store (Datenbank HAITHABU oder daten/)", "Siedlung, Hauskarte", "Häuser als Zeilen; Wege, Karten und Lageplan aus dem Startwert", 16);
        link("store", "Regie, weather", "Regiebücher als Text, Wetterlagen als Werte der Regie", 16);
        link("alle Packages (öffentliche Felder)", "store", "Zustand alle 2 min und beim Ende; Presets je Package; gemerkte Ansichten", 16);
        link("store", "Uhr, Kamera, weather, Regie, hearth, Flotte", "Weiter wie zuletzt: Szenenzeit, Ansicht, Regie, Regiebuch an seiner Stelle, Brand, Schiffe", 16);
    }

    // ------------------------------------------------------------------ Phase 12

    /** Datum der Uhr: Jahr, Tag im Jahr (1..365), Stunde (MEZ). */
    public int[] date() {
        var z = java.time.Instant.ofEpochMilli((long) Math.floor(clock.epochMillis())).atZone(SceneClock.ZONE);
        return new int[]{z.getYear(), Math.min(365, z.getDayOfYear()), z.getHour() * 3600 + z.getMinute() * 60 + z.getSecond()};
    }

    /**
     * Das Jahr einen Schritt weiter (je Bild, nach der Regie): Datum aus der Uhr, Wetter aus der Regie; ein Sprung im
     * Kalender rechnet vor. Setzt die Abweichung des Tags an die Regie.
     */
    public Year.State feedYear(double sceneDtS, double sunAltDeg) {
        int[] d = date();
        double hour = d[2] / 3600.0;
        weather.anomaly = year.anomaly(d[0], d[1]);
        Year.State st = year.step(sceneDtS, d[0], d[1], hour, airTempC, precipRate, sunAltDeg, oktas, wind.speed());
        yearState = st;
        return st;
    }

    /** Die Jahreszeit als Schnittstelle (Season) für andere Packages. */
    public Season seasonView() {
        return new Season() {
            Year.State st() { Year.State s = yearState; return s != null ? s : year.state(); }
            @Override public double foliage() { return st().foliage(); }
            @Override public double autumn() { return st().autumn(); }
            @Override public double snowDepth() { return st().snowDepth(); }
            @Override public double iceReach() { return st().iceDepth(); }
        };
    }

    // ------------------------------------------------------------------ Phase 2

    /** Je Bild: Wind und Wasserstand an das Noor. Der Windstau hebt den Spiegel in Lee (hier als ein Wert für das Noor). */
    public void feed(Ocean o) {
        // das Noor baut sein Spektrum bei jeder Änderung neu: Wind in Schritten von 0,5 m/s und 5° (wie Lighthouse)
        double ws = Math.min(wind.speed(), 17.1), wd = wind.fromDeg();   // F7 A: höchstens Bft 7
        Year.State ys = yearState;
        if (yearOn && ys != null) ws *= 1 - 0.92 * ys.iceCover();       // Phase 12: unter dem Eis keine Wellen
        if (Math.abs(ws - o.windSpeed) >= 0.5 || (ws < 0.5) != (o.windSpeed < 0.5)) o.windSpeed = Math.round(ws * 2) / 2.0;
        if (Math.abs(((wd - o.windFromDeg) % 360 + 540) % 360 - 180) >= 5) o.windFromDeg = Math.round(wd / 5) * 5.0 % 360;
        o.waterLevel = waterLevel.level();
    }

    /** Je Bild: Wind, Böigkeit und Jahreszeit an die Halme (mit der Böe des Augenblicks, wenn die Regie läuft). */
    public void feed(Reed r) {
        r.windSpeed = regie ? gustNow : wind.speed();
        r.windFromDeg = wind.fromDeg();
        r.gust = wind.gustiness() + 0.1;
        Year.State ys = yearState;
        r.season = yearOn && ys != null ? ys.reedSeason() : season;
        r.snowDepth = yearOn && ys != null ? ys.snowDepth() * ys.snowCover() : 0;
        r.frost = yearOn && ys != null ? ys.frost() * (1 - ys.snowCover()) : 0;
        r.wetness = Math.min(1, rainRate / 4);
    }

    // ------------------------------------------------------------------ Phase 3

    /** Die Regie einen Schritt weiter (Szenenzeit aus der Uhr, Böen in Echtzeit) und ihre Werte übernehmen. */
    public Weather.Snapshot feedWeather(double realDt) {
        if (yearOn) {
            // Phase 12: die Abweichung des gewürfelten Tags vor dem Schritt der Regie (sonst hinkt sie ein Bild nach)
            int[] d = date();
            weather.anomaly = year.anomaly(d[0], d[1]);
        }
        Weather.Snapshot s = weather.update(clock.epochMillis() / 1000.0, realDt);
        apply(s);
        return s;
    }

    /** Handregler: eine Größe der Regie sofort setzen und halten, bis „Regie weiter“. */
    public void hand(Weather.Var v, double value) {
        weather.set(v, value);
        Weather.Snapshot s = weather.snapshot();
        if (s != null) apply(s);
    }

    /** „Regie weiter“: alle Handregler lösen. */
    public void resumeRegie() {
        weather.release();
        rainbowHand = -1;
    }

    /** Ein Regiebuch zur jetzigen Szenenzeit starten (die App stellt die Uhr vorher auf seinen Beginn). */
    public void start(Scenario s) {
        weather.start(s, clock.epochMillis() / 1000.0);
        apply(weather.update(clock.epochMillis() / 1000.0, 0));
    }

    /** Freie Regie ab jetzt, beginnend mit einer Lage. */
    public void startFree(Weather.Phase p) {
        weather.startFree(clock.epochMillis() / 1000.0, p);
        apply(weather.update(clock.epochMillis() / 1000.0, 0));
    }

    private void apply(Weather.Snapshot s) {
        if (s == null) return;
        wind.speed = s.wind() * LAND_WIND;
        wind.fromDeg = s.fromDeg();
        wind.gust = s.gustiness();
        gustNow = s.gustNow() * LAND_WIND;
        oktas = s.oktas();
        highCover = s.high();
        cloudType = CloudType.valueOf(s.cloud().name());
        precipRate = Math.max(0, s.rain());
        double rf = Year.rainFraction(s.temperature());
        rainRate = precipRate * rf;
        snowRate = precipRate * (1 - rf);
        visibilityKm = Math.max(0.2, s.visibilityKm());
        // Phase 12: Schneefall nimmt die Sicht viel stärker als Regen gleicher Menge (1 mm/h: gut 1 km) [G]
        if (snowRate > 0.05) visibilityKm = Math.max(0.2, Math.min(visibilityKm, 1.3 * Math.pow(snowRate, -0.7)));
        fogAmount = s.fog();
        thunderstorm = Lightning.Level.values()[Math.max(0, Math.min(4, s.thunder()))];
        airTempC = s.temperature();
        pressureHPa = s.pressure();
        pressureTendency = s.tendency();
        showerEnd = s.showerEnd() * rf;
    }

    /** Dunst als Auslöschung je m aus der Sicht (Koschmieder). */
    public double hazePerM() { return 2.996 / (Math.max(0.5, visibilityKm) * 1000); }

    /** Dem Himmel Zeit, Ort, Augenhöhe, Sicht und Bedeckung (je Bild, vor {@code sky.step}). */
    public void feed(Sky sky, double eyeHeight) {
        sky.epochMillis = clock.epochMillis();
        sky.latDeg = clock.latDeg();
        sky.lonDeg = clock.lonDeg();
        sky.eyeHeight = Math.max(1, eyeHeight);
        sky.visibilityKm = visibilityKm;
        Year.State ys = yearState;
        sky.groundAlbedo = yearOn && ys != null ? ys.groundAlbedo() : 0.12;   // Wiesen, Wald, das Noor [G]; Schnee heller
        sky.cloudCover = cloudsDrawn ? 0 : oktas / 8;
        sky.cloudVeil = !cloudsDrawn;
        double low = smooth(1, 6, sunAltDeg(sky)) * (1 - smooth(36, 42, sunAltDeg(sky)));
        sky.rainbow = rainbowHand >= 0 ? rainbowHand : 0.85 * showerEnd * low;
    }

    private static double sunAltDeg(Sky sky) {
        Sky.State st = sky.state();
        return st != null ? st.sunAlt : 10;
    }

    /** Den Wolken Bedeckung, Art, hohe Schicht und den Wind in Wolkenhöhe (über Land 1,8-fach, 25° rechtsdrehend) [G]. */
    public void feed(Clouds c) {
        c.oktas = oktas;
        c.type = cloudType;
        c.highCover = highCover;
        c.windSpeed = Math.max(3, wind.speed() * 1.8);
        c.windFromDeg = (wind.fromDeg() + 25) % 360;
    }

    /**
     * Dem Regen Rate, Wind, Wolkenuntergrenze, Wasserspiegel und Auge; mit gezeichneten Wolken regnet es nur unter
     * ihren dichten Stellen (wie Lighthouse). Gibt den Wolken den Niederschlag zurück.
     */
    public void feed(Rain r, Clouds c, Clouds.Snapshot cs, boolean cloudsShown, double[] eye) {
        double rate = Math.max(0, rainRate), all = Math.max(rate, precipRate);
        c.precipitation = all > 0 ? Math.min(1, 0.35 + all / 25) : 0;
        r.rate = rate;
        r.windSpeed = regie ? gustNow : wind.speed();
        r.windFromDeg = wind.fromDeg();
        r.gust = wind.gustiness();
        r.waterLevel = waterLevel.level();
        r.cloudBase = cs.type().base;
        r.eyeX = eye[0];
        r.eyeY = eye[1];
        r.eyeZ = eye[2];
        if (!cloudsShown || rate <= 0) { r.curtain = null; return; }
        double p = Math.max(1e-3, cs.precipitation());
        r.curtain = (x, z) -> Math.min(1, Clouds.rain(cs, x, z) / p * 2);
    }

    /**
     * Dem Gewitter Stärke, Wolken, Boden und Ohr (je Bild, vor {@code lightning.step}). Die Blitze entstehen im Umkreis
     * von 16 km um das Auge unter den dichten Stellen der Wolken und schlagen ins Gelände ein (Hochburg, Wall).
     */
    public void feed(Lightning l, Clouds.Snapshot cs, boolean cloudsShown, double[] eye) {
        if (l.level() != thunderstorm) l.setLevel(thunderstorm);
        l.cx = eye[0];
        l.cz = eye[2];
        l.radius = 16_000;
        l.listenerX = eye[0];
        l.listenerY = eye[1];
        l.listenerZ = eye[2];
        l.groundLevel = waterLevel.level();
        Terrain t = terrain;
        double lv = waterLevel.level();
        l.ground = t == null ? null : (x, z) -> Math.max(lv, t.height(x, z));
        l.temperatureC = airTempC;
        if (cloudsShown && cs != null) {
            double base = cs.type().base, top = base + cs.type().maxThickness;
            l.cloudBase = base;
            l.cells = (x, z) -> Math.max(Clouds.rain(cs, x, z) * 1.5, Clouds.coverage(cs, x, z) * 0.35);
            l.occlusion = (px, py, pz, ex, ey, ez) -> cloudTransmittance(cs, px, py, pz, ex, ey, ez, base, top);
        } else {
            l.cloudBase = 1200;
            l.cells = null;
            l.occlusion = null;
        }
    }

    /** Durchlässigkeit der Wolken zwischen Kanal und Auge (wie Lighthouse: zehn Proben in der Schicht, halbe Auslöschung). */
    static double cloudTransmittance(Clouds.Snapshot cs, double px, double py, double pz, double ex, double ey, double ez, double base, double top) {
        double dx = ex - px, dy = ey - py, dz = ez - pz, len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1) return 1;
        double t0 = 0, t1 = 1;
        if (Math.abs(dy) > 1e-6) {
            double ta = (base - py) / dy, tb = (top - py) / dy;
            t0 = Math.max(0, Math.min(ta, tb));
            t1 = Math.min(1, Math.max(ta, tb));
        } else if (py < base || py > top) return 1;
        if (t1 <= t0) return 1;
        double tau = 0, step = (t1 - t0) / 10;
        for (int i = 0; i < 10; i++) {
            double t = t0 + (i + 0.5) * step;
            tau += Clouds.density(cs, px + dx * t, py + dy * t, pz + dz * t, false) * step * len;
            if (tau > 20) break;
        }
        return Math.exp(-0.5 * tau);
    }

    /**
     * Dem Nebel Menge, Sicht, Bedeckung, Höhe und Untergrenze. Strahlungsnebel [G]: Nebel n (0..1) gibt die Menge (ab
     * 0,02 bis 0,6 voll), die Sicht in der Bank 3 km · (50/3000)^(n^0,6), die Bedeckung 0,5 + 0,6 n und die
     * Obergrenze 4 + 16 n² m über dem Noor; die Hochburg (27 m) ragt aus dichtem Nebel heraus. Steigt die Sonne über
     * 2°, hebt sich der Nebel: bis 16° wächst die Untergrenze auf 85 % der Obergrenze, die Obergrenze selbst um 60 %.
     * Wind über 5 m/s reißt ihn auf (bei 10 m/s ist er fort).
     */
    public void feed(Fog f, double sunAltDeg) {
        double n = Math.max(0, Math.min(1, fogAmount));
        double windCut = 1 - smooth(5, 10, wind.speed());
        double lift = smooth(2, 16, sunAltDeg);
        double top = (4 + 16 * n * n) * (1 + 0.6 * lift);
        f.amount = fogOn ? smooth(0.02, 0.6, n) * windCut : 0;
        f.visibilityM = 3000 * Math.pow(50 / 3000.0, Math.pow(n, 0.6));
        f.coverage = Math.min(1, 0.5 + 0.6 * n);
        f.top = top;
        f.base = 0.85 * top * lift;
        f.bankSize = 900;
        f.wisps = 0.45;
        f.windSpeed = wind.speed();
        f.windFromDeg = wind.fromDeg();
        f.waterLevel = waterLevel.level();
        f.hazeVisibilityM = visibilityKm * 1000;
        fogTop = top;
        fogBase = f.base;
    }

    /** Licht des Himmels als Schnittstelle für andere Packages (Lighting). */
    public static Lighting lighting(Sky sky) {
        return new Lighting() {
            Sky.State st() { Sky.State s = sky.state(); return s != null ? s : sky.update(); }
            @Override public double[] sunDir() { return st().sunDir.clone(); }
            @Override public double[] moonDir() { return st().moonDir.clone(); }
            @Override public double[] sunColor() { return st().sunColor.clone(); }
            @Override public double[] moonColor() { return st().moonColor.clone(); }
            @Override public double[] skyAmbient() { return st().skyIrradiance.clone(); }
            @Override public double haze() { return st().groundExtinction; }
        };
    }

    /** „Bft 3 aus 245° (Regie, Nebelmorgen: Der Nebel steigt)“ */
    public String weatherLine() {
        Weather.Snapshot s = weather.snapshot();
        String src = !regie || s == null ? "von Hand" : (s.scenario().isEmpty() ? "freie Regie, " + s.phase().label : s.scenario() + ": " + s.stepText())
                + (s != null && regie && weather.overrides() > 0 ? ", " + weather.overrides() + " von Hand" : "");
        return String.format(java.util.Locale.GERMAN, "Wind Bft %d aus %03.0f° (%.1f m/s, Böe %.1f) · %s", wind.beaufort(), wind.fromDeg(), wind.speed(),
                regie ? gustNow : wind.speed(), src);
    }

    static double smooth(double a, double b, double x) {
        double t = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }

    /** Eine Verbindung eintragen (die Phasen rufen das, wenn sie verdrahten). */
    public synchronized void link(String from, String to, String via, int phase) { links.add(new Link(from, to, via, phase)); }

    /** Was verbunden ist. */
    public synchronized List<Link> links() { return Collections.unmodifiableList(new ArrayList<>(links)); }

    /** Was nach dem Phasenplan kommt. */
    public static List<Link> planned() { return PLANNED; }

    /** „68 verbunden · 1 offen“ */
    public String summary() { return links().size() + " verbunden · " + PLANNED.size() + " offen"; }
}
