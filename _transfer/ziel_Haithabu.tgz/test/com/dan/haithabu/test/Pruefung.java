package com.dan.haithabu.test;

import com.dan.haithabu.camera.Camera;
import com.dan.haithabu.gl.ComputeProbe;
import com.dan.haithabu.gl.Mat4;
import com.dan.haithabu.gl.Quality;
import com.dan.haithabu.gl.Renderer;
import com.dan.haithabu.gl.Shader;
import com.dan.haithabu.camera.Ansichten;
import com.dan.haithabu.scene.Brook;
import com.dan.haithabu.scene.Geo;
import com.dan.haithabu.scene.SceneClock;
import com.dan.haithabu.scene.Terrain;
import com.dan.haithabu.scene.Vegetation;
import com.dan.ocean.Ocean;
import com.dan.reed.Reed;
import com.dan.haithabu.scene.Site;
import com.dan.haithabu.scene.Sun;
import com.dan.haithabu.ui.AppIcon;
import com.dan.haithabu.wiring.Beaufort;
import com.dan.haithabu.wiring.Collider;
import com.dan.haithabu.wiring.Wiring;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Prüfprogramm der App ohne Grafikkarte und ohne Datenbank (aus Lighthouse). In NetBeans: Rechtsklick → „Run File“,
 * oder Ant-Target {@code pruefung}. Endet mit „ERGEBNIS: alles in Ordnung“ oder mit der Liste der Verstöße
 * (Rückgabewert 1). Wächst mit jeder Phase. Die Packages haben zusätzlich je ihre eigene Prüfklasse in {@code .demo}.
 */
public final class Pruefung {
    private static int ok, bad;

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();
        mathe();
        ort();
        sonne();
        uhr();
        kamera();
        qualitaet();
        shader();
        verdrahtung();
        gelaende();
        noor();
        halme();
        himmel();
        wetter();
        jahr();
        symbol();
        pakete();
        isolation();
        System.out.printf(Locale.GERMAN, "%n%d Prüfungen, %d Verstöße, %.1f s%n", ok + bad, bad, (System.nanoTime() - t0) / 1e9);
        System.out.println(bad == 0 ? "ERGEBNIS: alles in Ordnung" : "ERGEBNIS: " + bad + " Verstöße");
        System.exit(bad == 0 ? 0 : 1);
    }

    static void check(boolean cond, String what) {
        if (cond) ok++; else bad++;
        System.out.println((cond ? "  ok    " : "  FEHLER ") + what);
    }

    static void mathe() {
        System.out.println("Matrizen");
        float[] v = Mat4.lookAt(10, 20, 30, 0, 14, 0);
        float[] p = Mat4.perspective(55, 16 / 9.0, 0.2, 60000, true);
        float[] vp = Mat4.mul(p, v), id = Mat4.mul(vp, Mat4.invert(vp));
        double err = 0;
        for (int i = 0; i < 16; i++) err = Math.max(err, Math.abs(id[i] - (i % 5 == 0 ? 1 : 0)));
        check(err < 1e-4, String.format(Locale.GERMAN, "Projektion·Blick mal Inverse = Einheit (Fehler %.1e)", err));
        float[] look = Mat4.lookAt(0, 0, 0, 0, 0, -1);
        double[] c = Mat4.apply(Mat4.mul(p, look), 0, 0, -100);
        check(Math.abs(c[2] / c[3] - 0.2 / 100) < 1e-6, "Umgekehrte Tiefe: Punkt in 100 m hat Tiefe Nahebene/100");
        double[] far = Mat4.apply(Mat4.mul(p, look), 0, 0, -3000);
        check(far[2] / far[3] > 0 && far[2] / far[3] < 1e-3, "Gegenufer in 3 km liegt zwischen 0 und Nahebene, vor dem Unendlichen");
    }

    static void ort() {
        System.out.println("Ort und Maßstab");
        check(Site.dms(Site.LAT, Site.LON).equals("54°29′28″ N · 9°34′11″ E"), "Bachmund (aus den Höhendaten) in Grad, Minuten, Sekunden: " + Site.dms(Site.LAT, Site.LON));
        double[] u = Geo.UTM32.forward(54, 9);
        check(Math.abs(u[0] - 500_000) < 1e-6, "UTM32: Mittelmeridian 9° E liegt bei 500 000 m Ost");
        double[] ll = Geo.UTM32.inverse(536_330, 6_038_251), back = Geo.UTM32.forward(ll[0], ll[1]);
        check(Math.abs(back[0] - 536_330) < 1e-4 && Math.abs(back[1] - 6_038_251) < 1e-4, "UTM32 hin und zurück unter 0,1 mm (Krüger-Reihe)");
        double x = 1234, z = -2345;
        double[] xz = Site.xz(Site.latLon(x, z));
        check(Math.abs(xz[0] - x) < 1e-6 && Math.abs(xz[1] - z) < 1e-6, "Szene ↔ Breite/Länge hin und zurück");
        check(Site.lat(-1000) > Site.LAT && Site.lon(1000) > Site.LON, "Nord ist −z, Ost ist +x");
        double cx = Site.x(Site.CENTER_LON), cz = Site.z(Site.CENTER_LAT);
        check(cx < -150 && cx > -450 && Math.abs(cz) < 150, String.format(Locale.GERMAN, "Mitte des Wallinneren liegt %.0f m westlich, %.0f m nördlich des Bachmunds", -cx, -cz));
        double wr = Site.wallRadius();
        check(Math.abs(Math.PI * wr * wr / 2 / 10_000 - Site.WALL_AREA_HA) < 1e-9 && wr > 400 && wr < 415,
                String.format(Locale.GERMAN, "Halbkreis mit 26 ha hat %.0f m Radius, Bogen %.2f km (Werkbuch: rund 1,3 km)", wr, Math.PI * wr / 1000));
        check(Math.abs(Site.curvatureDrop(3000) - 0.706) < 0.01, String.format(Locale.GERMAN, "Erdkrümmung über das Noor (3 km): %.2f m", Site.curvatureDrop(3000)));
    }

    static void sonne() {
        System.out.println("Sonne am Noor");
        // Bezug: 16.10.2026 am Bachmund, Aufgang 07:52, Untergang 18:21 MESZ (NOAA-Formeln), also 06:52 und 17:21 MEZ
        LocalDate d = LocalDate.of(2026, 10, 16);
        double day0 = d.atStartOfDay(SceneClock.ZONE).toInstant().toEpochMilli();
        double upH = hourOf(Sun.crossing(day0, Site.LAT, Site.LON, true)), downH = hourOf(Sun.crossing(day0, Site.LAT, Site.LON, false));
        check(Math.abs(upH - (6 + 52 / 60.0)) < 0.1, "16.10.2026 Aufgang " + hm(upH) + " MEZ (erwartet rund 06:52)");
        check(Math.abs(downH - (17 + 21 / 60.0)) < 0.1, "16.10.2026 Untergang " + hm(downH) + " MEZ (erwartet rund 17:21)");
        // um 950: dieselbe Jahreszeit, ähnliche Zeiten (gregorianisch rückgerechnet)
        LocalDate d950 = SceneClock.START_DATE;
        double s0 = d950.atStartOfDay(SceneClock.ZONE).toInstant().toEpochMilli();
        double up950 = hourOf(Sun.crossing(s0, Site.LAT, Site.LON, true)), down950 = hourOf(Sun.crossing(s0, Site.LAT, Site.LON, false));
        check(Math.abs(down950 - downH) < 0.25 && Math.abs(up950 - upH) < 0.25,
                "16.10.950 Aufgang " + hm(up950) + ", Untergang " + hm(down950) + " MEZ: wie heute auf ±15 min");
        double[] at = Sun.position(new SceneClock().epochMillis(), Site.LAT, Site.LON);
        check(at[0] < 0 && at[0] > -6 && at[1] > 235 && at[1] < 265,
                String.format(Locale.GERMAN, "Start 16.10.950 17:30: Sonne %.1f° unter der Kimm im Westsüdwesten (%03.0f°), bürgerliche Dämmerung", -at[0], at[1]));
        LocalDate mid = LocalDate.of(950, 6, 21);
        double m0 = mid.atStartOfDay(SceneClock.ZONE).toInstant().toEpochMilli();
        double len = (Sun.crossing(m0, Site.LAT, Site.LON, false) - Sun.crossing(m0, Site.LAT, Site.LON, true)) / 3.6e6;
        check(len > 17.0 && len < 17.5, String.format(Locale.GERMAN, "Mittsommer 950: Tag %.2f h (54,5° N: gut 17 h)", len));
    }

    static void uhr() {
        System.out.println("Uhr");
        SceneClock c = new SceneClock();
        check(c.label().equals("16.10.950 17:30 MEZ"), "Start: " + c.label());
        check(c.epochMillis() < 0, "Szenenzeit vor 1970 (negativ)");
        c.lapse = 60;
        c.step(30);
        check(c.label().equals("16.10.950 18:00 MEZ"), "Zeitraffer 1 min/s, 30 s → " + c.label());
        c.lapse = 1e9;
        double e0 = c.epochMillis();
        c.step(1);
        check(Math.abs(c.epochMillis() - e0 - SceneClock.MAX_LAPSE * 1000) < 1e-3, "Zeitraffer höchstens 3600-fach");
        c.shiftDays(1);
        check(c.dateLabel().equals("17.10.950"), "Tag weiter: " + c.dateLabel());
        c.set(LocalDate.of(950, 12, 31), 23.99);
        c.lapse = 3600;
        c.step(0.1);
        check(c.dateLabel().equals("1.1.951"), "Jahreswechsel 950 → 951: " + c.label());
        SceneClock s = new SceneClock();
        s.lapse = 0;
        s.step(2.5);
        check(Math.abs(s.t() - 2.5) < 1e-9 && s.label().equals("16.10.950 17:30 MEZ"), "Uhr steht, Laufzeit läuft weiter (Rauch und Wellen bewegen sich)");
    }

    static void kamera() {
        System.out.println("Kamera");
        Camera cam = new Camera();
        check(cam.eye[0] > 300 && Math.abs(cam.eye[2]) < 100 && cam.heading() > 260 && cam.heading() < 280,
                String.format(Locale.GERMAN, "Grundansicht „Vom Noor“: Auge %.0f m östlich über dem Wasser, Blick %03.0f° nach Westen", cam.eye[0], cam.heading()));
        cam.lookAt(0, 0, 0, 0, -60, 50);
        cam.snap();
        check(cam.eye[1] >= Camera.MIN_EYE - 1e-9, String.format(Locale.GERMAN, "Auge bleibt über dem Boden (%.2f m)", cam.eye[1]));
        cam.waterLevel = 0.8;
        cam.place(10, 0, 10, 90, 0);
        check(cam.eye[1] >= 0.8 + Camera.MIN_EYE - 1e-9, "Frei: Auge bleibt über dem Windstau");
        cam.setMode(Camera.Mode.KREISEN);
        check(cam.mode == Camera.Mode.KREISEN && cam.dist > 1, "Wechsel Frei → Kreisen behält die Ansicht");
        double y0 = cam.yaw;
        cam.autoOrbit = true;
        cam.step(1);
        check(Math.abs(cam.yaw - y0 - cam.orbitSpeed) < 1e-9, "Von selbst kreisen: " + cam.orbitSpeed + "°/s");
    }

    static void qualitaet() {
        System.out.println("Qualität und Auflösung");
        Quality[] q = Quality.values();
        boolean mono = true;
        for (int i = 1; i < q.length; i++) mono &= q[i].renderScale >= q[i - 1].renderScale && q[i].budgetMs() > q[i - 1].budgetMs();
        check(mono, "Stufen Niedrig → Ultra steigen an");
        check(Math.abs(Quality.MITTEL.budgetMs() - 15.9) < 1e-9, "„Mittel“ hat das Budget aus Abschnitt 10: 15,9 ms");
        Renderer r = new Renderer();
        check(r.quality() == Quality.MITTEL, "Start auf „Mittel“ (F16 A)");
        r.regulateForTest(30, 2_000_000_000L);
        check(r.renderScale < Quality.MITTEL.renderScale, String.format(Locale.GERMAN, "Grafikkarte 30 ms: Auflösung sinkt auf %.0f %%", r.renderScale * 100));
        r.regulateForTest(30, 4_000_000_000L);
        r.regulateForTest(30, 6_000_000_000L);
        r.regulateForTest(30, 8_000_000_000L);
        check(r.renderScale >= Renderer.MIN_SCALE - 1e-9, "… aber nicht unter 50 %");
        for (int i = 0; i < 20; i++) r.regulateForTest(4, 10_000_000_000L + i * 2_000_000_000L);
        check(Math.abs(r.renderScale - Quality.MITTEL.renderScale) < 1e-9, "Mit Luft steigt sie zurück bis zur Stufe");
    }

    static void shader() {
        System.out.println("Shader");
        for (String[] prog : Renderer.shaderFiles()) {
            for (String f : prog) {
                boolean found;
                String text = "";
                try {
                    text = Shader.source(f, null).text;
                    found = text.startsWith("#version 430 core");
                } catch (RuntimeException e) {
                    found = false;
                }
                check(found, "Shader " + f + " gefunden und Bausteine eingesetzt (" + text.split("\n").length + " Zeilen)");
            }
        }
        String ter = Shader.source("terrain.vert", null).text;
        check(ter.contains("uLodRange") && ter.contains("morph"), "Gelände-Shader: Übergang zwischen den Stufen (Geomorphing)");
        String tf = Shader.source("terrain.frag", null).text;
        check(tf.contains("uCloudShadow") && tf.contains("moonLight()") && tf.contains("uSkyAmb"), "Gelände-Shader: Wolkenschatten, Mond und Himmelslicht aus com.dan.sky");
        check(ComputeProbe.expected(0, 63) == 64 * 65 / 2 && ComputeProbe.expected(1, 0) == 65, "Compute-Test: Erwartungswerte der Präfixsumme");
    }

    /** Phase 12: das Jahr (com.dan.season) in der Verdrahtung. */
    static void jahr() {
        System.out.println("Das Jahr (Phase 12)");
        SceneClock clk = new SceneClock(LocalDate.of(950, 1, 16), 12);
        Wiring w = new Wiring(clk);
        w.regie = true;
        w.yearOn = true;
        w.startFree(com.dan.weather.Weather.Phase.KLAR);
        w.feedWeather(0);
        double tJan = w.airTempC;
        com.dan.season.Year.State st = w.feedYear(0, clk.sun()[0]);
        check(st.snowDepth() > 0.08 && st.ice() > 0.04 && st.groundAlbedo() > 0.4 && tJan < 2,
                String.format(Locale.GERMAN, "16.1.950 12 Uhr: %s, Luft %.1f °C, Rückstrahlung des Bodens %.2f", st.describe(), tJan, st.groundAlbedo()));
        Reed r = new Reed();
        w.feed(r);
        Ocean o = new Ocean();
        w.wind.speed = 8;
        w.feed(o);
        check(r.season == 1 && r.snowDepth > 0.08 && o.windSpeed < 2,
                String.format(Locale.GERMAN, "Halme: Winter (%.2f), stehen %.0f cm im Schnee; das Noor unter dem Eis ohne Wellen (Wind %.1f statt 8 m/s)", r.season, r.snowDepth * 100, o.windSpeed));
        com.dan.haithabu.wiring.Season sv = w.seasonView();
        check(sv.foliage() == 0 && sv.snowDepth() > 0.08 && sv.iceReach() > 1, String.format(Locale.GERMAN, "Schnittstelle Season: Laub %.0f %%, Schnee %.0f cm, Eisgrenze %.1f m Wassertiefe",
                sv.foliage() * 100, sv.snowDepth() * 100, sv.iceReach()));
        // Niederschlag: unter 0,5 °C Schnee, die Sicht sinkt
        w.hand(com.dan.weather.Weather.Var.TEMPERATURE, -3);
        w.hand(com.dan.weather.Weather.Var.RAIN, 2);
        check(w.rainRate == 0 && Math.abs(w.snowRate - 2) < 1e-9 && w.visibilityKm < 1.0,
                String.format(Locale.GERMAN, "2 mm/h bei −3 °C fallen als Schnee (Regen %.1f mm/h), Sicht %.1f km", w.rainRate, w.visibilityKm));
        w.hand(com.dan.weather.Weather.Var.TEMPERATURE, 8);
        check(Math.abs(w.rainRate - 2) < 1e-9 && w.snowRate == 0, "Bei 8 °C fällt derselbe Niederschlag als Regen");
        w.resumeRegie();
        // die Regie kennt die Jahreszeit: Juli wärmer als Januar um das Klima, Gewitter im Sommer
        clk.set(LocalDate.of(950, 7, 16), 12);
        w.feedWeather(0);
        double tJul = w.airTempC;
        check(tJul - tJan > 10, String.format(Locale.GERMAN, "Regie Mitte Juli %.1f °C, Mitte Januar %.1f °C", tJul, tJan));
        com.dan.weather.Weather wx = new com.dan.weather.Weather();
        wx.climate = com.dan.season.Climate.schleswig().temp;
        double t0 = java.time.ZonedDateTime.of(951, 1, 1, 0, 0, 0, 0, SceneClock.ZONE).toEpochSecond();
        wx.startFree(t0, com.dan.weather.Weather.Phase.KLAR);
        int winter = 0, summer = 0;
        for (com.dan.weather.Weather.Segment sg : wx.segments(t0, t0 + 365 * 86400.0)) {
            if (sg.phase() != com.dan.weather.Weather.Phase.GEWITTER) continue;
            int m = java.time.Instant.ofEpochSecond((long) sg.t0()).atZone(SceneClock.ZONE).getMonthValue();
            if (m == 12 || m <= 2) winter++;
            if (m >= 6 && m <= 8) summer++;
        }
        check(summer > 3 * Math.max(1, winter), "Freie Regie über ein Jahr: Gewitter im Sommer " + summer + ", im Winter " + winter);
        // ein Sprung in den Juli: das Jahr rechnet vor, kein Schnee mehr
        com.dan.season.Year.State js = w.feedYear(0, clk.sun()[0]);
        check(js.snowDepth() == 0 && js.ice() == 0 && js.foliage() == 1 && js.reedSeason() == 0, "Sprung in den Juli: " + js.describe() + ", Laub voll, Schilf grün");
        String tf = Shader.source("terrain.frag", null).text;
        check(tf.contains("uSeason") && tf.contains("uSnow") && tf.contains("cropAt"), "Gelände-Shader: Gras, Felder, Laub und Schilf nach dem Jahr, Schnee und Reif");
    }

    static void verdrahtung() {
        System.out.println("Verdrahtung");
        Wiring w = new Wiring(new SceneClock());
        long p2 = w.links().stream().filter(l -> l.phase() == 2).count(), p3 = w.links().stream().filter(l -> l.phase() == 3).count();
        long p5 = w.links().stream().filter(l -> l.phase() == 5).count();
        long p89 = w.links().stream().filter(l -> l.phase() >= 8 && l.phase() <= 10).count(), p11 = w.links().stream().filter(l -> l.phase() == 11).count();
        long p12 = w.links().stream().filter(l -> l.phase() == 12).count(), p13 = w.links().stream().filter(l -> l.phase() == 13).count();
        long p14 = w.links().stream().filter(l -> l.phase() == 14).count(), p15 = w.links().stream().filter(l -> l.phase() == 15).count();
        check(p2 == 9 && p3 == 10 && p5 == 5 && p89 == 8 && p11 == 4 && p12 == 7 && p13 == 7 && p14 == 7 && p15 == 6 && w.links().stream().filter(l -> l.phase() == 16).count() == 4 && w.links().size() == 67, "Phase 2: " + p2 + " Verbindungen (Noor, Halme, Kamera, Wald, Bodendecke), Phase 3: " + p3
                + " (Himmel, Wetter, Wolken, Regen, Nebel, Blitz), Phase 5: " + p5 + " (Höfe, Nässe), Phase 8 bis 10: " + p89 + " (Pfähle, Schiffe, Feuer und Rauch), Phase 11: " + p11 + " (Raum, Rauch im Haus, Augenanpassung)"
                + ", Phase 12: " + p12 + " (Jahr: Klima, Schnee, Eis, Reif, Pflanzen), Phase 13: " + p13 + " (Vögel, Haustiere, Fischerboote), Phase 14: " + p14 + " (Klang), Phase 15: " + p15 + " (Regie, Brand), Phase 16: 4 (Datenbank)");
        List<Wiring.Link> p = Wiring.planned();
        check(p.size() == 1 && p.get(0).via().startsWith("Collider"), "Abgleich der geplanten Verbindungen: " + w.summary() + " (Regen unter Dächern)");
        String[] names = {"Clock", "Wind", "WaterLevel", "Terrain", "Lighting", "Flash", "HeatSource", "Collider", "SurfaceHit", "FireLight", "ScatterField", "Season", "SoundEvent"};
        int found = 0;
        for (String n : names) {
            try {
                Class<?> c = Class.forName("com.dan.haithabu.wiring." + n);
                if (c.isInterface()) found++;
            } catch (ClassNotFoundException e) { /* fehlt */ }
        }
        check(found == names.length, found + " von " + names.length + " Schnittstellen stehen als Interface");
        check(Beaufort.of(Beaufort.mid(3)) == 3 && Beaufort.of(w.wind.speed()) == 3, "Wind von Hand: Bft 3 (" + Beaufort.NAME[3] + ")");
        double[] to = w.wind.toVector();
        check(to[0] > 0.8 && to[2] < -0.3, "Wind aus 245° weht nach Ostnordost auf das Noor");
        Collider pfahl = Collider.cylinder(5, 5, 0.15, -3, 1.5);
        check(pfahl.distance(5, 0, 5) < 0 && Math.abs(pfahl.distance(6, 0, 5) - 0.85) < 1e-9, "Collider: Pfahl der Landebrücke als Zylinder");
    }

    static void gelaende() {
        System.out.println("Gelände (Phase 2)");
        check(Math.abs(Terrain.decode(Terrain.encode(12.345)) - 12.345) < 0.001, "Höhe in 16 Bit: Stufe unter 1 mm");
        Terrain t = Terrain.load(Terrain.defaultDir());
        boolean real = t.brook.length > 2;
        if (!real) { System.out.println("  (kein Import in " + Terrain.defaultDir() + ", nur das flache Ersatzgelände geprüft)"); }
        check(t.height(0, 0) > -1 && t.height(0, 0) < 1, String.format(Locale.GERMAN, "Bachmund liegt am Spiegel von 950 (%.2f m)", t.height(0, 0)));
        double[] r = new double[2];
        t.range(-512, -512, 1024, r);
        boolean in = true;
        for (int i = 0; i < 200; i++) { double x = -512 + (i * 37 % 1024), z = -512 + (i * 101 % 1024); double h = t.height(x, z); in &= h >= r[0] - 0.01 && h <= r[1] + 0.01; }
        check(in, String.format(Locale.GERMAN, "Min/Max-Pyramide umfasst das Gelände (%.1f … %.1f m)", r[0], r[1]));
        if (!real) return;
        check(t.height(-200, -700) > 24, String.format(Locale.GERMAN, "Hochburg %.1f m über dem Noor (DGM1: rund 28 m)", t.height(-200, -700)));
        check(t.waterDepth(300, -300) > 2, String.format(Locale.GERMAN, "Noor 300 m östlich, 300 m nördlich %.1f m tief [G]", t.waterDepth(300, -300)));
        double[] first = t.brook[0], last = t.brook[t.brook.length - 1];
        boolean down = true;
        for (int i = 1; i < t.brook.length; i++) down &= t.brook[i][2] <= t.brook[i - 1][2] + 1e-9;
        check(down && first[2] > last[2], String.format(Locale.GERMAN, "Bachsohle fällt stetig (%.2f → %.2f m)", first[2], last[2]));
        check(Math.hypot(last[0], last[1]) < 5, String.format(Locale.GERMAN, "Bach mündet am Ursprung (%.1f m daneben)", Math.hypot(last[0], last[1])));
        Brook b = Brook.of(t);
        check(b != null && b.meanSpeed > 0.1 && b.meanSpeed < 2, b == null ? "Bach fehlt" : b.describe());
        Vegetation v = new Vegetation(t);
        check(v.reedShare() > 0, String.format(Locale.GERMAN, "Schilfgürtel am Ufer (%.1f %% der Fläche)", v.reedShare() * 100));
        check(v.at(300, -300, Reed.Kind.SCHILF) == 0, "Kein Schilf im tiefen Noor");
        int ok = 0, ready = 0;
        for (Ansichten.Ansicht a : Ansichten.ALLE) {
            // „Im Haus“ hängt am Versammlungshaus und wird in Phase 11 geprüft
            if (!Ansichten.ready(a) || a.name().equals("Im Haus")) continue;
            ready++;
            if (a.orbit() || t.height(a.x(), a.z()) > -0.3 || a.name().equals("Hafen")) ok++;
        }
        check(ok == ready, ok + " von " + ready + " Ansichten stehen auf Land (der Hafen seit Phase 8 auf der Plattform über dem Wasser; „Im Haus“ prüft Phase 11)");
        wald(t, v);
        hoefe(t, v);
    }

    static void hoefe(Terrain t, Vegetation v) {
        System.out.println("Die Häuser am Ufer (Phase 5)");
        long t0 = System.nanoTime();
        com.dan.haithabu.scene.Siedlung s = com.dan.haithabu.scene.Siedlung.haithabu(t);
        double ms = (System.nanoTime() - t0) / 1e6;
        v.siedlung = s;
        long named = s.haeuser.stream().filter(h -> h.museum() && h.house().type() != com.dan.timber.HouseType.SCHUPPEN).count();
        check(named == 7, named + " Häuser am Bach: " + s.haeuser.stream().map(com.dan.haithabu.scene.Siedlung.Haus::name).limit(7).collect(java.util.stream.Collectors.joining(", ")));
        boolean dry = true, flat = true, apart = true, inWall = true;
        for (com.dan.haithabu.scene.Siedlung.Haus h : s.haeuser) {
            com.dan.timber.House hs = h.house();
            com.dan.timber.Timber.Box b = com.dan.timber.Timber.box(hs);
            double lo = 99, hi = -99;
            for (int i = -2; i <= 2; i++)
                for (int j = -2; j <= 2; j++) {
                    double[] p = hs.toWorld(i * hs.length() / 4, 0, j * hs.width() / 4);
                    double y = t.height(p[0], p[2]);
                    lo = Math.min(lo, y); hi = Math.max(hi, y);
                    if (t.sourceAt(p[0], p[2]) == Terrain.BACH || y < 0.4) dry = false;
                }
            if (hi - lo > (hs.type() == com.dan.timber.HouseType.GRUBENHAUS ? 1.6 : 1.2) || hs.y() < lo - 0.1 || hs.y() > hi + 0.05) flat = false;
            if (!s.insideWall(hs.x(), hs.z(), 0)) inWall = false;
            for (com.dan.haithabu.scene.Siedlung.Haus o : s.haeuser)
                if (o != h && Math.hypot(o.house().x() - hs.x(), o.house().z() - hs.z()) < hs.radius() * 0.75 + o.house().radius() * 0.75 - 1) apart = false;
        }
        check(dry, "Kein Haus im Bach oder am nassen Ufer");
        check(flat, "Häuser stehen auf dem Gelände (Hang unter einem Haus höchstens 1,2 m, Grubenhaus 1,6 m)");
        check(apart, "Die Häuser stehen einander nicht im Weg");
        check(inWall, "Alle Häuser innerhalb des Halbkreiswalls");
        com.dan.timber.House first = s.houses.get(0);
        check(s.blocked(first.x(), first.z()) && v.at(first.x(), first.z(), Reed.Kind.GRAS) == 0 && s.yard(first.x() + first.width(), first.z()) > 0.2,
                "Kein Gras im Versammlungshaus, zertretener Boden davor");
        check(s.bauwerke.tiles().size() > 0 && s.bauwerke.triangles(false) > 10_000 && s.bauwerke.triangles(true) < s.bauwerke.triangles(false),
                String.format(Locale.GERMAN, "Wege, Brücke, Zäune, Brunnen, Fischgestelle, Boote: %,d Dreiecke fein, %,d grob", s.bauwerke.triangles(false), s.bauwerke.triangles(true)));
        Ansichten.Ansicht bach = Ansichten.byName("Am Bach");
        double hd = Math.toRadians(bach.heading());
        int seen = 0;
        for (com.dan.timber.House hs : s.houses) {
            double dx = hs.x() - bach.x(), dz = hs.z() - bach.z(), d = Math.hypot(dx, dz);
            double c = (dx * Math.sin(hd) - dz * Math.cos(hd)) / d;
            if (c > Math.cos(Math.toRadians(40)) && d < 200) seen++;
        }
        check(seen >= 4, seen + " Häuser im Blick der Ansicht „Am Bach“");
        siedlung(t, s, ms);
        wall(t, s);
        hafen(t, s, v);
        schiffe(t, s);
        feuer(t, s);
        haus(t, s);
        tiere(t, s);
        klang(t, s);
        regie(t, s);
        try { PruefungDaten.alles(t, s); } catch (Exception e) { e.printStackTrace(); check(false, "Datenseite: " + e); }
        try { PruefungSchliff.alles(t); } catch (Exception e) { e.printStackTrace(); check(false, "Schliff: " + e); }
        v.siedlung = null;
    }

    static void siedlung(Terrain t, com.dan.haithabu.scene.Siedlung s, double ms) {
        System.out.println("Die Siedlung (Phase 6)");
        long more = s.haeuser.stream().filter(h -> !h.museum()).count();
        check(more >= 250 && more <= 900, String.format(Locale.GERMAN, "%d Häuser im Wall außer den Höfen am Bach, %d Gassen, gebaut in %.0f ms: %s", more, s.gassen.size(), ms, s.roles()));
        double rmin = 999, rmax = 0;
        for (double r : s.wallR) { rmin = Math.min(rmin, r); rmax = Math.max(rmax, r); }
        check(rmin > 200 && rmax < 445, String.format(Locale.GERMAN, "Wallkamm aus der gemessenen Kammlinie (Phase 7; Halbmesser %.0f … %.0f m, der Nordabschnitt liegt näher an der Mitte)", rmin, rmax));
        // Ordnung, aber kein Raster: Firstrichtungen streuen, Abstände zum nächsten Nachbarn streuen
        double[] nn = new double[(int) more];
        int k = 0;
        java.util.Set<Long> dirs = new java.util.HashSet<>();
        for (com.dan.haithabu.scene.Siedlung.Haus h : s.haeuser) {
            if (h.museum()) continue;
            double best = 1e9;
            for (com.dan.haithabu.scene.Siedlung.Haus o : s.haeuser) if (o != h) best = Math.min(best, Math.hypot(o.house().x() - h.house().x(), o.house().z() - h.house().z()));
            nn[k++] = best;
            dirs.add(Math.round(((h.house().headingDeg() % 180) + 180) % 180 / 5));
        }
        double mean = java.util.Arrays.stream(nn).average().orElse(0), sd = Math.sqrt(java.util.Arrays.stream(nn).map(x -> (x - mean) * (x - mean)).average().orElse(0));
        check(mean > 7 && mean < 25 && sd / mean > 0.15 && dirs.size() >= 12,
                String.format(Locale.GERMAN, "Dicht wie eine Stadt, nicht im Raster: nächster Nachbar %.1f ± %.1f m, %d Firstrichtungen (5°)", mean, sd, dirs.size()));
        // Ufer leicht, Hang eingetieft, Feuer abseits
        int ufer = 0, uferLeicht = 0, feuer = 0, feuerFern = 0;
        for (com.dan.haithabu.scene.Siedlung.Haus h : s.haeuser) {
            if (h.museum()) continue;
            com.dan.timber.House o = h.house();
            if (o.y() < 2.2 && o.x() > -140) { ufer++; if (o.type() != com.dan.timber.HouseType.GRUBENHAUS && o.type() != com.dan.timber.HouseType.HALLE) uferLeicht++; }
            if (h.rolle().equals("Schmiede") || h.rolle().equals("Glasmacher") || h.rolle().equals("Bronzegießer")) { feuer++; if (o.x() < -300 && Math.hypot(o.x() + 101, o.z() - 0) > 250) feuerFern++; }
        }
        check(ufer > 0 && uferLeicht == ufer && feuer > 3 && feuer < 80 && feuerFern == feuer, ufer + " Häuser am Ufer leicht gebaut, " + feuer + " Feuerwerkstätten im Westen abseits");
        boolean gardens = false;
        for (int i = 0; i < s.garden.length && !gardens; i++) gardens = s.garden[i] != 0;
        check(gardens, "Gärten hinter den Häusern");
        com.dan.haithabu.scene.Siedlung same = com.dan.haithabu.scene.Siedlung.haithabu(t, s.seed), other = com.dan.haithabu.scene.Siedlung.haithabu(t, s.seed + 1);
        check(same.haeuser.size() == s.haeuser.size() && same.houses.get(same.houses.size() - 1).x() == s.houses.get(s.houses.size() - 1).x() && other.houses.get(other.houses.size() - 1).x() != s.houses.get(s.houses.size() - 1).x(),
                "Gleicher Startwert, gleiche Siedlung; anderer Startwert, andere (" + other.haeuser.size() + " Häuser)");
        try {
            java.io.File f = java.io.File.createTempFile("siedlung", ".csv");
            s.save(f);
            com.dan.haithabu.scene.Siedlung back = com.dan.haithabu.scene.Siedlung.load(t, f);
            f.delete();
            check(back.haeuser.size() == s.haeuser.size() && back.seed == s.seed && Math.abs(back.houses.get(9).z() - s.houses.get(9).z()) < 0.01, "Speichern und Laden (CSV, " + back.haeuser.size() + " Häuser)");
        } catch (java.io.IOException e) { check(false, "Speichern: " + e); }
    }


    static void wall(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Wall, Tore, Hochburg (Phase 7)");
        com.dan.haithabu.scene.Befestigung b = t.befestigung;
        check(b != null, b == null ? "Keine Befestigung im Gelände" : b.describe());
        if (b == null) return;
        int n = b.x.length;
        check(b.length > 1300 && b.length < 1500 && b.gemessen > 0.8,
                String.format(Locale.GERMAN, "Kammlinie %,.0f m, davon %.0f %% im DGM gemessen (Werkbuch: rund 1,3 km [G]), geformt in %.0f ms", b.length, b.gemessen * 100, b.ms));
        check(t.height(b.x[0], b.z[0]) < 2.5 && t.height(b.x[n - 1], b.z[n - 1]) < 2.5,
                String.format(Locale.GERMAN, "Beide Enden reichen an das Ufer von 950 (%.1f und %.1f m über dem Noor)", t.height(b.x[0], b.z[0]), t.height(b.x[n - 1], b.z[n - 1])));
        int meas = 0, ridge = 0;
        for (int i = 0; i < n; i++) {
            if (b.art[i] != 0) continue;
            meas++;
            double side = 0.5 * (t.height(b.x[i] + b.nx[i] * 9, b.z[i] + b.nz[i] * 9) + t.height(b.x[i] - b.nx[i] * 9, b.z[i] - b.nz[i] * 9));
            if (t.height(b.x[i], b.z[i]) > side + 1.5) ridge++;
        }
        check(ridge > meas * 0.92, String.format(Locale.GERMAN, "Die Kammlinie liegt auf dem Wall: %d von %d gemessenen Proben über ihren Flanken", ridge, meas));
        check(b.grabenBisKamm > 7.5 && b.grabenBisKamm < 10.5 && b.erhebung > 4 && b.erhebung < 8,
                String.format(Locale.GERMAN, "Höhe: Kamm %.1f m über dem Gelände, %.1f m über der Grabensohle (Werkbuch: rund 9 m)", b.erhebung, b.grabenBisKamm));
        // Graben: Tiefe gegen seine Ränder, wo er voll ausgebildet ist
        java.util.List<Double> dep = new java.util.ArrayList<>();
        for (int i = 0; i < n; i += 4) {
            double c = com.dan.haithabu.scene.Befestigung.GRABEN_MITTE, hw = com.dan.haithabu.scene.Befestigung.GRABEN_HALB;
            if (b.grabenFadeAt(b.s[i]) < 0.99) continue;
            double bottom = t.height(b.x[i] + b.nx[i] * c, b.z[i] + b.nz[i] * c);
            double edges = 0.5 * (t.height(b.x[i] + b.nx[i] * (c - hw - 1), b.z[i] + b.nz[i] * (c - hw - 1)) + t.height(b.x[i] + b.nx[i] * (c + hw + 1), b.z[i] + b.nz[i] * (c + hw + 1)));
            dep.add(edges - bottom);
        }
        java.util.Collections.sort(dep);
        double med = dep.isEmpty() ? 0 : dep.get(dep.size() / 2);
        check(dep.size() > 100 && med > 1.4 && med < 2.8, String.format(Locale.GERMAN, "Graben vor dem Wall: %d Proben, Tiefe im Mittel %.1f m [G]", dep.size(), med));
        // Tore
        java.util.Map<String, com.dan.haithabu.scene.Befestigung.Tor> tore = new java.util.HashMap<>();
        for (com.dan.haithabu.scene.Befestigung.Tor tr : b.tore) tore.put(tr.name(), tr);
        check(tore.containsKey("Nordtor") && tore.containsKey("Westtor") && tore.containsKey("Südtor") && tore.containsKey("Bachdurchlass"), "Drei Tore und der Durchlass des Bachs: " + String.join(", ", tore.keySet()));
        boolean flatOk = true, clearOk = true;
        StringBuilder gi = new StringBuilder();
        for (com.dan.haithabu.scene.Befestigung.Tor tr : b.tore) {
            com.dan.timber.Fortification.Gate g = tr.gate();
            if (!tr.bach()) {
                for (double sl = -g.depth() / 2 + 1; sl <= g.depth() / 2 - 1; sl += 1) {
                    double[] p = g.at(sl, 0, 0);
                    if (Math.abs(t.height(p[0], p[2]) - g.floor(sl)) > 0.25) flatOk = false;
                }
                if (g.clearance() < 2.6) clearOk = false;
            }
            gi.append(String.format(Locale.GERMAN, "%s%s %.1f m", gi.length() > 0 ? ", " : "", tr.name(), g.clearance()));
        }
        check(flatOk, "Die Torgassen sind frei und eben (Boden höchstens 0,25 m neben ihrer Sohle)");
        check(clearOk, "Lichte Höhe unter den Plattformen: " + gi);
        com.dan.haithabu.scene.Befestigung.Tor bach = tore.get("Bachdurchlass"), west = tore.get("Westtor"), nord = tore.get("Nordtor");
        double lv = bach == null ? 0 : t.brookLevel(bach.gate().x(), bach.gate().z());
        check(bach != null && t.height(bach.gate().x(), bach.gate().z()) < lv + 0.05,
                String.format(Locale.GERMAN, "Der Bach fließt durch den Wall (Sohle %.2f m unter seinem Spiegel %.2f m)", bach == null ? 0 : lv - t.height(bach.gate().x(), bach.gate().z()), lv));
        check(west != null && bach != null && Math.abs(west.s() - bach.s()) < 15 && nord != null && b.art[b.index(nord.s())] == 1,
                "Westtor neben dem Bach, Nordtor im ergänzten Bogen im Nordwesten [G]");
        // Häuser
        boolean clear = true;
        for (com.dan.haithabu.scene.Siedlung.Haus h : s.haeuser) if (b.distance(h.house().x(), h.house().z()) < 12 + h.house().radius() * 0.5 && !h.museum()) clear = false;
        check(clear, "Kein Haus auf dem Wall oder im Graben (mindestens 12 m vom Kamm)");
        com.dan.timber.Structures.Set ws = new com.dan.timber.Structures.Set();
        b.bauwerke(ws, (x, z) -> Math.max(t.height(x, z), -0.2));
        check(ws.triangles(false) > 60_000 && ws.triangles(true) < ws.triangles(false) / 5,
                String.format(Locale.GERMAN, "Palisade %.1f m, Wehrgang, Torbauten: %,d Dreiecke fein, %,d grob", com.dan.haithabu.scene.Befestigung.PAL_H, ws.triangles(false), ws.triangles(true)));
        // Hochburg
        double a = Math.toRadians(com.dan.haithabu.scene.Befestigung.HB_HEADING);
        Ansichten.Ansicht hb = Ansichten.byName("Hochburg");
        double lu = (hb.x() - com.dan.haithabu.scene.Befestigung.HB_X) * Math.sin(a) - (hb.z() - com.dan.haithabu.scene.Befestigung.HB_Z) * Math.cos(a);
        double lw = (hb.x() - com.dan.haithabu.scene.Befestigung.HB_X) * Math.cos(a) + (hb.z() - com.dan.haithabu.scene.Befestigung.HB_Z) * Math.sin(a);
        check(b.kuppen.size() >= 70 && b.kuppen.size() <= 110 && Math.abs(lu) < 120 && Math.abs(lw) < 36,
                String.format(Locale.GERMAN, "Hochburg: %d Grabhügel an den Kuppen des DGM (KuLaDig: über 70), die Ansicht steht darin", b.kuppen.size()));
        double ringUp = 0;
        int rc = 0;
        for (double u = -100; u <= 100; u += 25) {
            double cx = com.dan.haithabu.scene.Befestigung.HB_X + Math.sin(a) * u + Math.cos(a) * (com.dan.haithabu.scene.Befestigung.HB_W / 2 + 3);
            double cz = com.dan.haithabu.scene.Befestigung.HB_Z - Math.cos(a) * u + Math.sin(a) * (com.dan.haithabu.scene.Befestigung.HB_W / 2 + 3);
            double inner = t.height(cx - Math.cos(a) * 8, cz - Math.sin(a) * 8), outer = t.height(cx + Math.cos(a) * 8, cz + Math.sin(a) * 8);
            ringUp += t.height(cx, cz) - 0.5 * (inner + outer);
            rc++;
        }
        com.dan.timber.Fortification.Gate ht = b.hochburgTor();
        check(ringUp / rc > 1.2 && ringUp / rc < 3 && ht.clearance() > 2.2,
                String.format(Locale.GERMAN, "Hochburg: Wall %.1f m über dem Gelände daneben [G], Tor im Nordosten (lichte Höhe %.1f m)", ringUp / rc, ht.clearance()));
        check(b.verbindungRest < 0.8, String.format(Locale.GERMAN, "F24 A: der Verbindungswall (um 968) ist für 950 eingeebnet (Rest %.1f m)", b.verbindungRest));
        // Fahrt „Über den Wall“
        com.dan.haithabu.camera.Fahrt f = new com.dan.haithabu.camera.Fahrt("Über den Wall", b.fahrt(), 150, 32, 5);
        double lo = 99, hi = -99;
        for (double sm = 0; sm <= f.length; sm += 1) {
            double[] p = f.at(sm);
            double above = p[1] - Math.max(0, t.height(p[0], p[2]));
            lo = Math.min(lo, above);
            boolean overGate = false;
            for (com.dan.haithabu.scene.Befestigung.Tor tr : b.tore) overGate |= Math.hypot(p[0] - tr.gate().x(), p[2] - tr.gate().z()) < tr.gate().width() / 2 + 3;
            if (!overGate) hi = Math.max(hi, above);
        }
        double turn = f.maxTurnPerMeter();
        check(f.length > 1300 && lo > 1.5 && hi < 9 && turn < 6,
                String.format(Locale.GERMAN, "Fahrt „Über den Wall“: %,.0f m in %.0f s (%.1f m/s), Auge %.1f bis %.1f m über dem Boden (außer über den Torgassen), Blick dreht höchstens %.1f°/m", f.length, f.duration, f.speed(), lo, hi, turn));
        f.start();
        double[] p0 = f.pose(0);
        for (int i = 0; i < 151 * 60 && f.running; i++) f.advance(1 / 60.0);
        double[] p1 = f.pose(f.u);
        check(!f.running && f.u == 1 && p0[2] > 150 && p1[2] < -300, String.format(Locale.GERMAN, "Die Fahrt beginnt am Südende (z %.0f) und endet im Norden (z %.0f)", p0[2], p1[2]));
        Ansichten.Ansicht vw = Ansichten.byName("Vom Wall");
        check(b.distance(vw.x(), vw.z()) < 3, String.format(Locale.GERMAN, "Ansicht „Vom Wall“ steht auf dem Wehrgang (%.1f m von der Kammlinie)", b.distance(vw.x(), vw.z())));
        // gleiches Gelände bei gleichem Laden
        Terrain t2 = Terrain.load(Terrain.defaultDir());
        check(java.util.Arrays.equals(t.h, t2.h), "Gleiche Höhendaten, gleiche Formung");
    }

    /** Phase 10: Herde, Essen, Fackeln, Feuerstelle; Tagesgang, Abendinversion, Aufwand des Rauchs. */
    static void feuer(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Feuer und Rauch (Phase 10)");
        com.dan.haithabu.scene.Feuer f = com.dan.haithabu.scene.Feuer.of(t, s);
        int land = 0, n = 0;
        f.step(400, 18.5, -3);
        for (com.dan.smoke.Source src : f.sources()) { n++; if (t.height(src.x(), src.z()) > -0.2 && src.y() > t.height(src.x(), src.z()) + 0.5) land++; }
        check(f.herdCount() > 300 && f.torchCount() == 10 && land == n,
                String.format(Locale.GERMAN, "%d Herde unter Rauchlöchern (davon Essen der Gewerbe), %d Fackeln an Toren und Brückenköpfen; alle %d Fahnen steigen über Land auf (aus Rauchlöchern und der Feuerstelle)", f.herdCount(), f.torchCount(), n));
        int[] cnt = new int[4];
        double[] hours = {3, 7.5, 12.5, 18.5};
        for (int i = 0; i < 4; i++) { f.step(400, hours[i], hours[i] > 7 && hours[i] < 17 ? 20 : -5); cnt[i] = f.sources().size(); }
        check(cnt[0] < 40 && cnt[1] > 100 && cnt[2] < cnt[3] && cnt[3] >= 100 && cnt[3] < 220,
                String.format(Locale.GERMAN, "Tagesgang der Herde: nachts %d Fahnen, morgens %d, mittags %d, abends %d (hundert Rauchsäulen)", cnt[0], cnt[1], cnt[2], cnt[3]));
        f.step(400, 18.5, -3);
        boolean night = f.torchesLit() == f.torchCount() && f.beachLit();
        f.step(400, 12, 22);
        boolean day = f.torchesLit() == 0 && !f.beachLit() && f.workshopsBurning() > 4;
        check(night && day, String.format(Locale.GERMAN, "Fackeln und Feuerstelle brennen am Abend, am Mittag nicht; am Tag arbeiten %d Essen", f.workshopsBurning()));
        com.dan.smoke.Smoke sm = new com.dan.smoke.Smoke();
        sm.windSpeed = 1.5;
        sm.stability = com.dan.smoke.Smoke.stability(-3, 1.5, 0.1);
        double eve = sm.finalRise(com.dan.smoke.Source.hearth(0, 5, 0, 1));
        sm.windSpeed = 4;
        sm.stability = com.dan.smoke.Smoke.stability(25, 4, 0.3);
        double day2 = sm.finalRise(com.dan.smoke.Source.hearth(0, 5, 0, 1));
        check(eve > 5 && eve < 13 && day2 > 20, String.format(Locale.GERMAN, "Abends bei 1,5 m/s und klarem Himmel steigt der Herdrauch %.0f m über das Dach und legt sich (Inversion), mittags bei 4 m/s %.0f m", eve, day2));
        f.step(400, 18.5, -3);
        sm.setSources(f.sources());
        sm.windSpeed = 1.5;
        sm.stability = 0.9;
        Ansichten.Ansicht vw = Ansichten.byName("Vom Wall");
        sm.select(vw.x(), t.height(vw.x(), vw.z()) + vw.eyeAboveGround(), vw.z());
        check(sm.nearCount() == sm.quality.near && sm.balls() < 6000,
                String.format(Locale.GERMAN, "Aufwand vom Wall am Abend: %d Fahnen nah, %d fern, %,d Bälle (Stufe Mittel)", sm.nearCount(), sm.farCount(), sm.balls()));
        java.util.List<double[]> l = f.lights(6, 2.6, -80.5, 8, 900);
        double torch = 0;
        for (double[] x : l) torch = Math.max(torch, x[5]);
        check(l.size() == 8 && torch > 50, String.format(Locale.GERMAN, "Am Abend leuchten am Hafen 8 Feuer auf Häuser, Boden und Rauch (das hellste mit %.0f cd im Grün)", torch));
    }

    /** Phase 11: das Versammlungshaus innen, ohne Grafikkarte nachgerechnet. */
    /** Phase 13: Vögel und Haustiere in der Siedlung. */
    static void tiere(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Tiere (Phase 13)");
        com.dan.haithabu.scene.Leben l = com.dan.haithabu.scene.Leben.of(t, s);
        int goats = 0, yards = 0, dogs = 0, pigs = 0;
        for (com.dan.herd.Herd.Pen p : l.herd.pens) switch (p.kind()) { case ZIEGE -> goats++; case HUHN -> yards++; case HUND -> dogs++; case SCHWEIN -> pigs++; }
        double[] wall = {-560.5, -102.8};
        double dx = l.pasture[0] - wall[0], dz = l.pasture[2] - wall[1], bearing = (Math.toDegrees(Math.atan2(dx, -dz)) + 360) % 360, dist = Math.hypot(dx, dz);
        check(goats >= 2 && yards >= 6 && dogs == 2 && pigs == 2 && dist > 20 && dist < 140 && Math.abs(bearing - 95) < 35,
                String.format(Locale.GERMAN, "Gehege: %d Ziegenweiden, %d Hühnerhöfe, %d Pferche, %d Hunde; die Weide am Hang %.0f m vor „Vom Wall“ in Richtung %03.0f°", goats, yards, pigs, dogs, dist, bearing));
        double[] eye = {6, 3.5, -80.5};
        int inHouse = 0, inWater = 0, swimLand = 0;
        for (int i = 0; i < 9000; i++) {
            l.step(0.1, eye, 25, 30_000, 4, 260, 0, 0, 289, 0, 0, null);
            if (i % 50 != 0) continue;
            for (com.dan.herd.Herd.Animal a : l.herd.animals()) {
                if (a.state == com.dan.herd.Herd.State.AWAY) continue;
                if (l.blockedForTest(a.pos[0], a.pos[2])) inHouse++;
                if (t.height(a.pos[0], a.pos[2]) < 0.1 && a.pos[1] < 0.5) inWater++;
            }
            for (com.dan.flock.Flock.Gull g : l.flock.gulls()) if (g.state == com.dan.flock.Flock.State.SWIM && t.height(g.pos[0], g.pos[2]) > -0.2) swimLand++;
        }
        check(inHouse == 0 && inWater == 0 && swimLand == 0, String.format(Locale.GERMAN, "15 min: kein Tier in einem Haus oder im Wasser, kein Vogel schwimmt über Land · %s", l.animalLine()));
        int swim = 0, perch = 0, pal = 0;
        for (com.dan.flock.Flock.Gull g : l.flock.gulls()) {
            if (g.state == com.dan.flock.Flock.State.AWAY || Math.hypot(g.pos[0] - eye[0], g.pos[2] - eye[2]) > 160) continue;
            if (g.state == com.dan.flock.Flock.State.SWIM) swim++;
            if (g.state == com.dan.flock.Flock.State.PERCH) { perch++; if (g.pos[1] > 1) pal++; }
        }
        check(swim >= 5 && perch >= 1 && pal >= 1, String.format(Locale.GERMAN, "Hafen am Vormittag: in 160 m %d Vögel auf dem Wasser, %d auf Pfählen und Brücken · %s", swim, perch, l.birdLine()));
        for (int i = 0; i < 1200; i++) l.step(0.5, eye, -12, 1, 2, 260, 0, 0, 289, 0, 0, null);
        check(l.herd.outside(com.dan.herd.Herd.Kind.HUHN) == 0 && l.flock.present(com.dan.flock.Species.KRAEHE) == 0,
                "Nachts: Hühner im Stall, Krähen beim Schlafplatz; " + l.animalLine());
        for (int i = 0; i < 1200; i++) l.step(0.5, eye, 10, 20_000, 3, 260, 0, 0.3, 16, 0, 6, null);
        check(l.flock.present(com.dan.flock.Species.ENTE) == 0 && l.flock.present(com.dan.flock.Species.SCHWALBE) == 0 && l.herd.outside(com.dan.herd.Herd.Kind.ZIEGE) == 0,
                "Im Januar mit Eis bis 6 m Wassertiefe und 30 cm Schnee: keine Enten und Schwalben, Ziegen im Stall; " + l.birdLine());
    }

    static void klang(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Klang (Phase 14)");
        com.dan.haithabu.scene.Vegetation v = new com.dan.haithabu.scene.Vegetation(t);
        v.siedlung = s;
        java.time.LocalDate tag = java.time.LocalDate.of(950, 10, 16);
        com.dan.haithabu.tools.Hoerproben.Stage g = new com.dan.haithabu.tools.Hoerproben.Stage(t, s, v, tag, 11.5, 3, 245, 0);
        com.dan.haithabu.scene.Klang k = g.klang;
        com.dan.soundscape.Soundscape sc = k.scape;
        int smith = 0, kamm = 0;
        for (com.dan.soundscape.Workshop w : sc.workshops) { if (w.craft == com.dan.soundscape.Workshop.Craft.SCHMIED) smith++; if (w.craft == com.dan.soundscape.Workshop.Craft.KAMMMACHER) kamm++; }
        double mDist = s.hafen != null ? Math.hypot(k.markt.x - s.hafen.durchfahrt[0], k.markt.z - s.hafen.durchfahrt[1]) : 0;
        check(smith >= 3 && kamm == 1 && sc.workshops.size() >= 8 && sc.pilings.size() > 50 && mDist < 250,
                String.format(Locale.GERMAN, "Werkstätten %s; %d Pfähle im Wasser; Markt am Umschlagplatz %.0f m von der Durchfahrt", k.workshops(), sc.pilings.size(), mDist));
        g.eye = com.dan.haithabu.tools.Hoerproben.gassePunkt(t, s, g.feuer.hall);
        g.yaw = 88;
        com.dan.haithabu.tools.Hoerproben.Probe p = g.record("gasse", "Gasse", 10, 20);
        long strikes = 0;
        for (com.dan.soundscape.Workshop w : sc.workshops) strikes += w.strikes();
        double[] lv = sc.levels();
        double all = 0;
        for (int i = 0; i < p.audio().length; i++) all += p.audio()[i] * p.audio()[i];
        all = com.dan.soundscape.Dsp.db(Math.sqrt(all / p.audio().length));
        check(k.calls > 3 && strikes > 20 && k.markt.people > 120 && lv[com.dan.soundscape.Soundscape.PARTS.length - 1] > 35 && all < 100,
                String.format(Locale.GERMAN, "Gasse um 11:30 (30 s): %d Rufe, %d Schläge und Striche, Markt %.0f Leute · %s", k.calls, strikes, k.markt.people, sc.describe()));
        // im Haus am Abend: drinnen, der Herd knistert nah
        com.dan.haithabu.tools.Hoerproben.Stage h = new com.dan.haithabu.tools.Hoerproben.Stage(t, s, v, tag, 19, 4, 250, 1.5);
        double[] q = h.feuer.hall.imHaus();
        h.eye = new double[]{q[0], q[1], q[2]};
        h.yaw = q[3];
        h.inHall = true;
        h.feuer.hall.herdMode = 1;
        h.record("haus", "Haus", 6, 6);
        double[] hl = h.klang.scape.levels();
        check(h.klang.scape.inside > 0.99 && hl[7] > 35 && h.klang.describe().contains("im Langhaus"),
                String.format(Locale.GERMAN, "Im Versammlungshaus um 19 Uhr: Raum Langhaus, Herd %.0f dB · %s", hl[7], h.klang.scape.describe()));
        // nachts: Werkstätten und Markt still, keine Rufe außer dem Hund
        com.dan.haithabu.tools.Hoerproben.Stage n = new com.dan.haithabu.tools.Hoerproben.Stage(t, s, v, tag, 1.5, 2, 245, 0);
        n.eye = g.eye.clone();
        n.yaw = 88;
        n.record("nacht", "Nacht", 4, 10);
        long ns = 0;
        int act = 0;
        for (com.dan.soundscape.Workshop w : n.klang.scape.workshops) { ns += w.strikes(); if (w.active) act++; }
        check(act == 0 && ns == 0 && n.klang.markt.people < 1, String.format(Locale.GERMAN, "Um 1:30 Uhr: keine Werkstatt, kein Markt · %s", n.klang.scape.describe()));
        // Ruderschlag: die einlaufende Knorr rudert durch die Durchfahrt
        com.dan.haithabu.tools.Hoerproben.Stage r = new com.dan.haithabu.tools.Hoerproben.Stage(t, s, v, tag, 8, 2, 230, 0);
        com.dan.haithabu.camera.Ansichten.Ansicht a = com.dan.haithabu.camera.Ansichten.byName("Hafen");
        r.eye = new double[]{a.x(), 3.5, a.z()};
        r.yaw = a.heading();
        r.flotte.einlaufen(230, 3);
        for (int i = 0; i < 9000 && !r.flotte.einlaeufer.rowing(); i++) { r.ocean.step(0.2); r.flotte.step(0.2, r.ocean, 230, 3); }
        r.record("hafen", "Hafen", 2, 20);
        check(r.klang.strokes >= 5, String.format(Locale.GERMAN, "Hafen: die Knorr rudert ein, %d Ruderschläge in 22 s hörbar · %s", r.klang.strokes, r.klang.scape.describe()));
    }

    static void regie(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Regiebücher (Phase 15)");
        com.dan.haithabu.scene.Flotte fl = com.dan.haithabu.scene.Flotte.of(t, s.hafen);
        com.dan.haithabu.scene.Feuer fe = com.dan.haithabu.scene.Feuer.of(t, s);
        com.dan.ocean.Ocean o = com.dan.ocean.Ocean.noor(4);
        java.util.List<String> caps = new java.util.ArrayList<>(), views = new java.util.ArrayList<>();
        String[] sheet = {null};
        double[] wind = {80, com.dan.haithabu.wiring.Beaufort.mid(4) * com.dan.haithabu.wiring.Wiring.LAND_WIND};
        int[] coll = {0};
        com.dan.haithabu.scene.Regie.Ctx c = new com.dan.haithabu.scene.Regie.Ctx() {
            public void time(java.time.LocalDate d, double h) { }
            public void lapse(double x) { }
            public void weather(com.dan.weather.Scenario sc) { }
            public void weatherFree(com.dan.weather.Weather.Phase p, double b, double f) { }
            public void view(String n) { views.add(n); }
            public void fahrt(String n) { }
            public void einlaufen() { fl.einlaufen(wind[0], wind[1]); fl.knorrAway = false; }
            public void auslaufen() { fl.auslaufen(wind[0], wind[1]); }
            public void brander() { fe.brand = com.dan.haithabu.scene.Brand.of(s, fl, 1050); fe.brand.onCollapse = (h, x, y, z) -> coll[0]++; fl.branderStart(); }
            public void igniteNearBrander() { if (fe.brand != null) fe.brand.igniteNear(fl.brander.x, fl.brander.z, 3); }
            public void capture(String x) { caps.add(x); }
            public void sheet(String n) { sheet[0] = n; }
            public void say(String x) { }
        };
        com.dan.haithabu.scene.Regie r = new com.dan.haithabu.scene.Regie();
        r.start(com.dan.haithabu.scene.Regie.nacht1050(), c);
        boolean through = false;
        double dt = 0.1;
        for (int i = 0; i < 3600; i++) {
            r.step(dt, c);
            o.step(dt);
            fl.step(dt, o, wind[0], wind[1]);
            if (fe.brand != null) fe.brand.step(dt, wind[0], wind[1], 0);
            // durch die Durchfahrt: auf der Innenseite der Palisade
            double ix = fl.brander.x - fl.lucke[0], iz = fl.brander.z - fl.lucke[1];
            if (fl.branderOn && ix * fl.aussen[0] + iz * fl.aussen[1] < -10) through = true;
        }
        com.dan.haithabu.scene.Brand b = fe.brand;
        check(b != null && through && fl.branderAdrift && !Double.isNaN(b.firstIgnition) && b.touched() >= 10 && b.collapsed() >= 1 && coll[0] >= 1,
                String.format(Locale.GERMAN, "Die Nacht von 1050 läuft durch: der Brander kommt durch die Durchfahrt und treibt; %s", b == null ? "kein Brand" : b.describe()));
        int burnt = 0;
        for (com.dan.timber.House h : b.houses) if (b.burnOf(h) > 1) burnt++;
        check(caps.size() == 5 && "Die Nacht von 1050".equals(sheet[0]) && !r.running() && r.describe().contains("zu Ende") && views.contains("Hochburg") && burnt == b.collapsed() && fe.flames().size() > 20,
                String.format(Locale.GERMAN, "Fünf Bilder und ein Blatt, %d Ansichten; %d Häuser als schwarzer Haufen, %d Flammen · %s", views.size(), burnt, fe.flames().size(), r.describe()));
        // Ein Handelstag und ein Nebelmorgen: alle Stichworte, die Knorr läuft aus und ein
        com.dan.haithabu.scene.Flotte f2 = com.dan.haithabu.scene.Flotte.of(t, s.hafen);
        int[] ein = {0}, aus = {0}, shots = {0};
        com.dan.haithabu.scene.Regie.Ctx c2 = new com.dan.haithabu.scene.Regie.Ctx() {
            public void time(java.time.LocalDate d, double h) { }
            public void lapse(double x) { }
            public void weather(com.dan.weather.Scenario sc) { }
            public void weatherFree(com.dan.weather.Weather.Phase p, double b2, double f) { }
            public void view(String n) { }
            public void fahrt(String n) { }
            public void einlaufen() { ein[0]++; }
            public void auslaufen() { aus[0]++; f2.auslaufen(245, 3); }
            public void brander() { }
            public void igniteNearBrander() { }
            public void capture(String x) { shots[0]++; }
            public void sheet(String n) { }
            public void say(String x) { }
        };
        int cues = 0;
        for (com.dan.haithabu.scene.Regie.Book bk : new com.dan.haithabu.scene.Regie.Book[]{com.dan.haithabu.scene.Regie.handelstag(), com.dan.haithabu.scene.Regie.nebelmorgen()}) {
            com.dan.haithabu.scene.Regie rr = new com.dan.haithabu.scene.Regie();
            rr.start(bk, c2);
            for (int i = 0; i < (int) (bk.length() + 2); i++) rr.step(1, c2);
            cues += rr.fired();
            if (rr.running() || rr.fired() != bk.cues().size()) cues = -999;
        }
        double[] home = {f2.einlaeufer.x, f2.einlaeufer.z};
        for (int i = 0; i < 3000; i++) { o.step(0.1); f2.step(0.1, o, 245, 3); }
        double out = Math.hypot(f2.einlaeufer.x - home[0], f2.einlaeufer.z - home[1]);
        double ox = f2.einlaeufer.x - f2.lucke[0], oz = f2.einlaeufer.z - f2.lucke[1];
        boolean outside = ox * f2.aussen[0] + oz * f2.aussen[1] > 20;
        check(cues > 20 && ein[0] == 2 && aus[0] == 1 && shots[0] == 12 && out > 100 && outside,
                String.format(Locale.GERMAN, "Ein Handelstag und ein Nebelmorgen: %d Stichworte, 12 Bilder; die Knorr läuft aus und ist nach 5 min %.0f m weit draußen vor der Palisade", cues, out));
        // Tagesregie: um 15:30 aus, um 8 Uhr wieder ein
        com.dan.haithabu.scene.Flotte f3 = com.dan.haithabu.scene.Flotte.of(t, s.hafen);
        int[] e3 = {0}, a3 = {0};
        com.dan.haithabu.scene.Regie.Ctx c3 = new com.dan.haithabu.scene.Regie.Ctx() {
            public void time(java.time.LocalDate d, double h) { }
            public void lapse(double x) { }
            public void weather(com.dan.weather.Scenario sc) { }
            public void weatherFree(com.dan.weather.Weather.Phase p, double b2, double f) { }
            public void view(String n) { }
            public void fahrt(String n) { }
            public void einlaufen() { e3[0]++; f3.knorrAway = false; }
            public void auslaufen() { a3[0]++; f3.auslaufen(245, 3); }
            public void brander() { }
            public void igniteNearBrander() { }
            public void capture(String x) { }
            public void sheet(String n) { }
            public void say(String x) { }
        };
        com.dan.haithabu.scene.Regie.tagesregie(9.9, 10.0, f3, c3);
        com.dan.haithabu.scene.Regie.tagesregie(15.45, 15.55, f3, c3);
        f3.einlaeufer.commands.clear();
        com.dan.haithabu.scene.Regie.tagesregie(7.95, 8.05, f3, c3);
        check(a3[0] == 1 && e3[0] == 1, "Tagesregie: die Knorr läuft um 15:30 aus und am nächsten Morgen um 8 Uhr ein");
    }

    static void haus(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Das Versammlungshaus innen (Phase 11)");
        com.dan.haithabu.scene.Feuer f = com.dan.haithabu.scene.Feuer.of(t, s);
        com.dan.haithabu.scene.Versammlungshaus h = f.hall;
        if (h == null) { check(false, "kein Versammlungshaus in der Siedlung"); return; }
        com.dan.timber.Interior.Room r = h.room;
        int doors = 0, holes = 0;
        for (com.dan.timber.Interior.Opening o : r.openings()) if (o.triangle()) holes++; else doors++;
        check(doors == 2 && holes == 2 && h.mesh.triangles() > 3000,
                r.describe() + String.format(Locale.GERMAN, " · Hülle und Einrichtung %,d Dreiecke", h.mesh.triangles()));
        // die Fahnen kommen aus den Rauchlöchern dieses Hauses, nicht doppelt aus einem zweiten Herd
        java.util.List<double[]> holesW = com.dan.timber.Timber.smokeHoles(h.house);
        int fromHall = 0;
        for (com.dan.smoke.Source src : f.sources())
            for (double[] p : holesW) if (Math.hypot(src.x() - p[0], src.z() - p[2]) < 0.1) fromHall++;
        h.settle(8, 8);
        check(fromHall == 2 && f.herdCount() > 300, String.format(Locale.GERMAN, "Der Herd des Hauses raucht durch beide Rauchlöcher (%d Fahnen), keine zweite Herdstelle in der Liste der Siedlung", fromHall));
        // Morgen und Nacht
        double z8 = h.smoke.layerBottom(), s8 = h.smoke.sigma();
        boolean burns8 = h.herd.level > 0.9;
        String d8 = h.describe();
        h.settle(2, -40);
        double s2 = h.smoke.sigma(), glow2 = h.herd.glow;
        boolean dark2 = h.herd.level == 0 && h.flames().stream().allMatch(fl -> fl.kind() == com.dan.hearth.Flame.EMBER);
        String d2 = h.describe();
        check(burns8 && z8 > 1.7 && z8 < 3.5 && s8 > 0.05 && s8 < 1.5, "Morgens um 8: " + d8);
        check(dark2 && glow2 > 0.1 && glow2 < 0.6 && s2 < s8 * 0.15, "Nachts um 2 nur Glut: " + d2);
        // Morgensonne durch die Osttür: Lichtfleck auf dem Boden und ein Strahl durch den Raum
        SceneClock clk = new SceneClock();
        clk.setHour(9.0);
        double[] sp = clk.sun(), sd = com.dan.haithabu.scene.Sun.direction(sp[0], sp[1]), sl = r.dirToLocal(sd);
        double lit = 0, shaft = 0;
        com.dan.timber.Interior.Opening door = h.frontDoor();
        for (double x = -r.hx() + 0.1; x < r.hx(); x += 0.2)
            for (double z = -r.hz() + 0.1; z < r.hz(); z += 0.2) {
                if (r.through(new double[]{x, 0.04, z}, sl) == door) lit += 0.04;
                for (double y = 0.3; y < r.roofY(z); y += 0.3) if (r.through(new double[]{x, y, z}, sl) != null) shaft += 0.012;
            }
        check(sp[0] > 3 && lit > 0.2 && lit < 8 && shaft > 0.5,
                String.format(Locale.GERMAN, "16.10.950 9:00, Sonne %.1f° hoch aus %03.0f°: durch die Osttür %.1f m² Licht auf dem Boden, %.1f m³ Strahl im Raum", sp[0], sp[1], lit, shaft));
        clk.setHour(12.4);
        sp = clk.sun();
        sl = r.dirToLocal(com.dan.haithabu.scene.Sun.direction(sp[0], sp[1]));
        double viaHole = 0;
        for (double x = -r.hx() + 0.1; x < r.hx(); x += 0.25)
            for (double z = -r.hz() + 0.1; z < r.hz(); z += 0.25)
                for (double y = 2.5; y < r.roofY(z); y += 0.25) {
                    com.dan.timber.Interior.Opening o = r.through(new double[]{x, y, z}, sl);
                    if (o != null && o.triangle()) viaHole += 0.25 * 0.25 * 0.25;
                }
        check(viaHole > 0.2, String.format(Locale.GERMAN, "Mittags (Sonne %.1f° aus %03.0f°) fällt ein Strahl durch das Rauchloch im Südgiebel unter das Dach (%.1f m³)", sp[0], sp[1], viaHole));
        // Licht nach draußen nur aus den Türen; im Haus der Herd
        h.settle(19, -15);
        java.util.List<double[]> in = h.lights(0), out = h.doorLights(0);
        double herdCd = in.isEmpty() ? 0 : in.get(0)[5], doorCd = out.isEmpty() ? 0 : out.get(0)[5];
        boolean doorsOutside = true;
        for (double[] d : out) doorsOutside &= !r.contains(d[0], d[1], d[2]);
        check(in.size() == 3 && out.size() == 2 && doorsOutside && doorCd < herdCd * 0.1,
                String.format(Locale.GERMAN, "Abends: Herd und zwei Lampen leuchten im Haus (Herd %.0f cd im Grün), draußen nur die beiden Türen (je %.1f cd)", herdCd, doorCd));
        double lumFire = h.interiorLuminance(0, com.dan.sky.Sky.CD_PER_UNIT, 0);
        h.settle(2, -40);
        double lumGlow = h.interiorLuminance(0, com.dan.sky.Sky.CD_PER_UNIT, 0);
        check(lumFire > lumGlow * 20 && lumGlow > 0, String.format(Locale.GERMAN, "Augenanpassung im Haus: am Herdfeuer %.3g cd/m², bei Glut %.3g cd/m²",
                lumFire * com.dan.sky.Sky.CD_PER_UNIT, lumGlow * com.dan.sky.Sky.CD_PER_UNIT));
        // Ansicht und Fahrt
        double[] v = h.imHaus();
        check(r.contains(v[0], v[1], v[2]), String.format(Locale.GERMAN, "Ansicht „Im Haus“ steht im Haus, %.1f m über dem Lehmboden, Blick %03.0f°", v[1] - h.house.y(), v[3]));
        com.dan.haithabu.camera.Fahrt g = new com.dan.haithabu.camera.Fahrt("Durch die Gasse", h.gasse(s, t), 75, 0, 3);
        g.endHeading = v[3];
        double[] end = g.pose(1), start = g.pose(0);
        boolean through = false, otherHouse = false;
        for (double u = 0; u <= 1; u += 0.002) {
            double[] q = g.pose(u);
            if (r.contains(q[0], q[1], q[2])) through = true;
            for (com.dan.haithabu.scene.Siedlung.Haus x : s.haeuser)
                if (!x.house().equals(h.house) && com.dan.timber.Timber.box(x.house()).contains(q[0], q[1], q[2])) otherHouse = true;
        }
        check(through && !otherHouse && r.contains(end[0], end[1], end[2]) && !r.contains(start[0], start[1], start[2]) && Math.abs(((end[3] - v[3] + 540) % 360) - 180) < 1
                        && g.length > 60 && g.length < 160,
                String.format(Locale.GERMAN, "Fahrt „Durch die Gasse“: %.0f m vom Bohlenweg durch die Osttür bis ans Südende, durch kein anderes Haus, am Ende Blick wie Taste 7", g.length));
    }

    /** Phase 9: Schiffe am Liegeplatz und die Einfahrt der Knorr, ohne Grafikkarte nachgerechnet. */
    static void schiffe(Terrain t, com.dan.haithabu.scene.Siedlung s) {
        System.out.println("Die Schiffe (Phase 9)");
        com.dan.haithabu.scene.Hafen h = s.hafen;
        com.dan.haithabu.scene.Flotte f = com.dan.haithabu.scene.Flotte.of(t, h);
        check(f != null && f.ships.size() == 7 && f.fischer.size() == 3, f == null ? "Keine Flotte" : String.format(Locale.GERMAN, "%d Schiffe: %s", f.ships.size(),
                String.join(", ", f.ships.stream().map(x -> x.name + " (" + x.type.label + ")").toList())));
        if (f == null) return;
        // Liegeplätze: Wasser unter dem Kiel, kein Pfahl im Rumpf, kein Schiff im anderen
        double keel = 1e9, clr = 1e9, apart = 1e9;
        for (com.dan.longship.Longship sh : f.ships) {
            keel = Math.min(keel, keelClearance(t, sh));
            clr = Math.min(clr, pileClearance(h, sh));
            for (com.dan.longship.Longship o : f.ships)
                if (o != sh) for (double u = -1; u <= 1; u += 0.1) { double[] p = o.toWorld(u * o.hull.halfLength * 0.97, 0, 0); apart = Math.min(apart, com.dan.haithabu.scene.Flotte.mask(sh).distance(p[0], p[2])); }
        }
        check(keel > 0.3 && clr > 0.05 && apart > 0.5, String.format(Locale.GERMAN, "Liegeplätze: bei Mittelwasser %.2f m Wasser unter dem Kiel (Windstau −0,3 m geht), %.2f m bis zum nächsten Pfahl, Schiffe %.1f m auseinander", keel, clr, apart));
        // Umriss in der Wasserlinie: nie breiter als der Rumpf (sonst Spalt zum Wasser), höchstens 15 cm schmaler
        double over = 0, under = 0;
        for (com.dan.longship.ShipType ty : com.dan.longship.ShipType.values()) {
            com.dan.longship.Longship sh = new com.dan.longship.Longship(ty, "x");
            com.dan.ocean.HullMask m = com.dan.haithabu.scene.Flotte.mask(sh);
            for (double u = -0.95; u <= 0.95; u += 0.05) {
                double act = sh.hull.halfBreadthAt(u * sh.hull.halfLength, 0), lens = m.halfWidth(u * sh.hull.halfLength / m.halfLength());
                over = Math.max(over, lens - act);
                under = Math.max(under, act - lens);
            }
        }
        check(over < 0.015 && under < 0.15, String.format(Locale.GERMAN, "Umriss für das Wasser: höchstens %.0f mm über dem Rumpf, %.0f mm darunter (kein Spalt außen, kaum Wasser im Boot)", over * 1000, under * 1000));
        // Schwimmen: auf ruhigem Wasser auf der Konstruktionswasserlinie, gerade
        Ocean calm = Ocean.noor(1);
        for (int i = 0; i < 300; i++) { calm.step(0.05); f.step(0.05, calm, 255, 4); }
        double dy = 0, tilt = 0;
        for (com.dan.longship.Longship sh : f.ships) { dy = Math.max(dy, Math.abs(sh.y - calm.waterLevel)); tilt = Math.max(tilt, Math.max(Math.abs(sh.pitch), Math.abs(sh.roll))); }
        check(dy < 0.05 && Math.toDegrees(tilt) < 1, String.format(Locale.GERMAN, "Auf ruhigem Noor schwimmen alle auf ihrer Wasserlinie (± %.0f mm) und gerade (%.2f°), Masse aus den Säulen", dy * 1000, Math.toDegrees(tilt)));
        Ocean o4 = Ocean.noor(4);
        com.dan.longship.Longship lang = f.langschiff;
        double py = 0, pmax = 0;
        for (int i = 0; i < 400; i++) { o4.step(0.05); f.step(0.05, o4, 255, 6); if (i > 100) { py = Math.max(py, Math.abs(lang.y - o4.waterLevel)); pmax = Math.max(pmax, Math.abs(lang.roll)); } }
        check(py > 0.002 && py < 0.4 && Math.toDegrees(pmax) < 6, String.format(Locale.GERMAN, "Bei Bft 4 hebt und senkt sich das Langschiff am Liegeplatz um bis %.0f mm, rollt bis %.1f°", py * 1000, Math.toDegrees(pmax)));
        for (double wind : new double[]{255, 75}) einfahrt(t, h, f, wind);
        check(f.ships.get(0).onWake != null,
                "Kielwasser und Riemenschläge laufen als Ringwellen ins Noor, Riemen spritzen (spray, F22)");
    }

    static double keelClearance(Terrain t, com.dan.longship.Longship sh) {
        double m = 1e9;
        for (double ss = -sh.hull.halfLength; ss <= sh.hull.halfLength; ss += 1)
            for (double q : new double[]{-0.4, 0, 0.4}) {
                double[] w = sh.toWorld(ss, q * sh.type.beam / 2, 0);
                m = Math.min(m, -t.height(w[0], w[2]) + sh.hull.keel(ss));
            }
        return m;
    }

    static double pileClearance(com.dan.haithabu.scene.Hafen h, com.dan.longship.Longship sh) {
        com.dan.ocean.HullMask mk = com.dan.haithabu.scene.Flotte.mask(sh);
        double m = 1e9, r = sh.hull.halfLength + 2;
        for (double[] p : h.pfaehle) if (Math.abs(p[0] - sh.x) < r && Math.abs(p[1] - sh.z) < r) m = Math.min(m, mk.distance(p[0], p[1]) - p[2]);
        return m;
    }

    /** Die Knorr läuft ein: segelt (wenn der Wind es zulässt), birgt das Segel vor der Lücke, rudert hindurch, legt an. */
    static void einfahrt(Terrain t, com.dan.haithabu.scene.Hafen h, com.dan.haithabu.scene.Flotte f, double wind) {
        Ocean o = Ocean.noor(3);
        f.einlaufen(wind, 5);
        com.dan.longship.Longship k = f.einlaeufer;
        boolean sailed = false, struckBefore = true, through = false;
        double keel = 1e9, clr = 1e9, tt = 0, gapOff = 0;
        double[] g = f.lucke, n = f.aussen;
        double prevSide = (k.x - g[0]) * n[0] + (k.z - g[1]) * n[1];
        long splash0 = f.splashes;
        int impulses = 0;
        for (; tt < 900; tt += 0.1) {
            o.step(0.1);
            f.step(0.1, o, wind, 5);
            impulses = Math.max(impulses, o.impulses().size());
            if (k.mode == com.dan.longship.Longship.Mode.SEGELN) sailed = true;
            double side = (k.x - g[0]) * n[0] + (k.z - g[1]) * n[1];
            if (Math.hypot(k.x - g[0], k.z - g[1]) < 30 && k.sailSet > 0.05) struckBefore = false;
            if (prevSide > 0 && side <= 0) { through = true; gapOff = Math.abs(-(k.x - g[0]) * n[1] + (k.z - g[1]) * n[0]); }
            prevSide = side;
            if (((int) Math.round(tt * 10)) % 5 == 0) { keel = Math.min(keel, keelClearance(t, k)); clr = Math.min(clr, pileClearance(h, k)); }
            if (!f.arriving()) break;
        }
        for (int i = 0; i < 150; i++) { o.step(0.1); f.step(0.1, o, wind, 5); }
        double err = Math.hypot(k.x - f.platzEin.x(), k.z - f.platzEin.z()), herr = Math.abs(((k.heading - f.platzEin.heading()) % 360 + 540) % 360 - 180);
        boolean canSail = k.canSail(f.start[2]);
        check((sailed || !canSail) && struckBefore && through && gapOff < com.dan.haithabu.scene.Hafen.DURCHFAHRT / 2 - k.type.beam / 2 && err < 1 && herr < 10 && keel > 0.2 && clr > 0 && tt < 600
                        && f.splashes > splash0 && impulses > 0,
                String.format(Locale.GERMAN, "Wind aus %03.0f°: die Knorr %s, birgt das Segel vor der Durchfahrt, rudert %.1f m neben der Mitte hindurch und liegt nach %.0f s %.2f m und %.1f° vom Platz; Kiel nie unter %.2f m Wasser, Pfähle nie näher als %.2f m; %d Spritzer",
                        wind, canSail ? "segelt heran" : "rudert heran (das Segel zöge nicht)", gapOff, tt, err, herr, keel, clr, f.splashes - splash0));
    }

    static void hafen(Terrain t, com.dan.haithabu.scene.Siedlung s, Vegetation v) {
        System.out.println("Der Hafen (Phase 8)");
        com.dan.haithabu.scene.Hafen h = s.hafen;
        check(h != null, h == null ? "Kein Hafen" : h.describe() + String.format(Locale.GERMAN, " (%.0f ms)", h.ms));
        if (h == null) return;
        boolean inWall = true;
        for (double[] p : h.ufer) inWall &= t.befestigung.inside(p[0] - 3, p[1], 0) && Math.abs(t.height(p[0], p[1])) < 0.5;
        check(h.ufer.size() > 100 && inWall, String.format(Locale.GERMAN, "Ufer von 950 im Gelände gefunden: %d Punkte von z %.0f bis %.0f, alle im Wall und am Spiegel", h.ufer.size(), h.ufer.get(0)[1], h.ufer.get(h.ufer.size() - 1)[1]));
        check(h.flaecheHa >= 8 && h.flaecheHa <= 11, String.format(Locale.GERMAN, "Hafenbecken %.1f ha zwischen Ufer und Palisade (Werkbuch: 8 bis 11 ha)", h.flaecheHa));
        boolean deep = true, apart = true;
        double minL = 1e9;
        for (com.dan.haithabu.scene.Hafen.Bruecke b : h.bruecken) {
            deep &= t.height(b.x1(), b.z1()) < -com.dan.haithabu.scene.Hafen.TIEFE + 0.1;
            minL = Math.min(minL, b.length());
            for (com.dan.haithabu.scene.Hafen.Bruecke o : h.bruecken)
                if (o != b && Math.hypot((o.x0() + o.x1()) / 2 - (b.x0() + b.x1()) / 2, (o.z0() + o.z1()) / 2 - (b.z0() + b.z1()) / 2) < 12) apart = false;
        }
        check(h.bruecken.size() >= 6 && deep && apart, String.format(Locale.GERMAN, "%d Landebrücken bis 1,9 m Wassertiefe (Tiefgang 1,3 bis 1,5 m), die kürzeste %.0f m, nicht übereinander", h.bruecken.size(), minL));
        double beach = 1e9, mouth = 1e9;
        for (double[][] l : h.plattformen) for (double[] p : l) { if (p[1] > 8 && p[1] < 50) beach = 0; mouth = Math.min(mouth, Math.hypot(p[0], p[1])); }
        check(beach > 0 && mouth > 5, String.format(Locale.GERMAN, "Der Strand des Fischers bleibt frei, die Bachmündung auch (Plattform %.0f m entfernt)", mouth));
        check(com.dan.haithabu.scene.Hafen.DECK > 0.5 + 0.3, "Deck 0,9 m über dem Mittelwasser, über Windstau (± 0,5 m) und Seegang des Noors");
        boolean wet = true;
        int n = 0;
        for (double[][] l : h.palisade)
            for (double[] p : l) {
                double de = Math.min(Math.hypot(p[0] - h.ufer.get(0)[0], p[1] - h.ufer.get(0)[1]), Math.hypot(p[0] - h.ufer.get(h.ufer.size() - 1)[0], p[1] - h.ufer.get(h.ufer.size() - 1)[1]));
                if (de > 30 && t.height(p[0], p[1]) > -0.3) wet = false;
                n++;
            }
        double gapDepth = -t.height(h.durchfahrt[0], h.durchfahrt[1]);
        double brg = Math.toDegrees(Math.atan2(h.durchfahrt[0] - 0, -(h.durchfahrt[1] + 80)));
        check(h.palisade.size() == 2 && wet && gapDepth > 2 && brg > 10 && brg < 90,
                String.format(Locale.GERMAN, "Palisade im Wasser von Wallende zu Wallende, Durchfahrt %.0f m bei %.1f m Tiefe, nach %03.0f° (Nordost)", com.dan.haithabu.scene.Hafen.DURCHFAHRT, gapDepth, (brg + 360) % 360));
        com.dan.haithabu.scene.Hafen.Bruecke b0 = h.bruecken.get(0);
        double px = (b0.x0() + b0.x1()) / 2, pz = (b0.z0() + b0.z1()) / 2;
        check(v.at(px, pz, Reed.Kind.SCHILF) == 0 && s.blocked(b0.x0(), b0.z0()), "Kein Schilf unter Brücken und Plattform");
        double d0 = h.feld.distance(h.pfaehle.get(0)[0], h.pfaehle.get(0)[1]), d1 = h.feld.distance(h.pfaehle.get(0)[0] + 3, h.pfaehle.get(0)[1] + 3);
        Ocean o5 = Ocean.noor(5);
        double hs5 = o5.state().totalHs(), ring = 0, ringOld = 0;
        for (int i = 0; i < 64; i++) { ring += Ocean.surfRing(0.3, hs5, i * 1.37, i * 0.71, 0, o5.ringHsLow, o5.ringHsHigh) / 64; ringOld += Ocean.surfRing(0.3, hs5, i * 1.37, i * 0.71, 0) / 64; }
        check(d0 < 0.3 && d1 >= 0 && ring > 0.2 && ringOld < 0.05,
                String.format(Locale.GERMAN, "Brandungsring an den Pfählen: Abstandsraster %d × %d, bei Bft 5 (H_s %.2f m) Schaum %.0f %% 0,3 m vom Pfahl (mit der Schwelle der offenen See %.0f %%)", h.feld.w(), h.feld.h(), hs5, ring * 100, ringOld * 100));
        check(h.waren[0] > 5 && h.waren[1] > 5 && h.waren[2] > 3 && h.waren[3] > 3, "Waren auf den Brücken: Fässer, Ballen, Mühlsteine, Specksteintöpfe");
        Ansichten.Ansicht ha = Ansichten.byName("Hafen");
        double eye = Math.max(0, t.height(ha.x(), ha.z())) + ha.eyeAboveGround();
        double hd = Math.toRadians(ha.heading());
        int seen = 0;
        for (com.dan.haithabu.scene.Hafen.Bruecke b : h.bruecken) {
            double dx = b.x1() - ha.x(), dz = b.z1() - ha.z(), d = Math.hypot(dx, dz);
            if ((dx * Math.sin(hd) - dz * Math.cos(hd)) / d > Math.cos(Math.toRadians(45))) seen++;
        }
        check(s.blocked(ha.x(), ha.z()) && eye > com.dan.haithabu.scene.Hafen.DECK + 1.5 && seen >= 2,
                String.format(Locale.GERMAN, "Ansicht „Hafen“ steht auf der Plattform (Auge %.1f m), %d Brückenköpfe im Blick", eye, seen));
    }

    static void wald(Terrain t, Vegetation v) {
        System.out.println("Wald und Bodendecke (Phase 2b)");
        double[] sh = v.woodShare();
        check(sh[0] > 0.2 && sh[0] < 0.7 && sh[1] > 0.005, String.format(Locale.GERMAN, "Wald auf %.0f %% der Fläche, Erlenbruch auf %.1f %% [G]", sh[0] * 100, sh[1] * 100));
        double inside = 0, east = 0;
        int ni = 0, ne = 0;
        for (int i = 0; i < 40; i++)
            for (int j = 0; j < 40; j++) {
                double x = -560 + i * 14, z = -560 + j * 25;
                if (Math.hypot(x - Vegetation.WALL_X, z - Vegetation.WALL_Z) < Vegetation.WALL_R - 20 && x < 100 && t.height(x, z) > 0.5) { inside += v.wood(x, z) + v.alder(x, z); ni++; }
                double ex = 1300 + i * 15, ez = -1200 + j * 30;
                if (t.height(ex, ez) > 1) { east += v.wood(ex, ez); ne++; }
            }
        check(ni > 0 && inside == 0, "Im Halbkreiswall steht kein Baum (" + ni + " Proben)");
        check(ne > 0 && east / ne > 0.45, String.format(Locale.GERMAN, "Gegenufer bewaldet (im Mittel %.0f %%)", east / Math.max(1, ne) * 100));
        boolean free = true;
        for (Ansichten.Ansicht a : Ansichten.ALLE) if (Ansichten.ready(a) && !a.orbit()) free &= v.wood(a.x(), a.z()) + v.alder(a.x(), a.z()) < 0.02;
        check(free, "Kein Baum auf den Standpunkten der Ansichten");
        check(v.at(700, 60, Vegetation.BUCHE) == 0, "Uferwiese am Gegenufer frei (Blick über das Noor)");
        com.dan.forest.ForestField f = new com.dan.forest.ForestField(4, 4, v, v.forestGround(), 950);
        f.radius = 600;
        double[] eye = {1300, 30, 0};
        f.completeNow(eye);
        f.update(eye, null, 0);
        int[] lc = f.lodCounts();
        boolean onGround = true;
        for (int b = 0; b < f.buckets(); b++)
            for (int k = 0; k < f.count[b]; k++) {
                float[] o = f.bucket[b];
                if (Math.abs(o[8 * k + 1] - t.height(o[8 * k], o[8 * k + 2])) > 0.5) onGround = false;
            }
        check(f.shown > 1000 && onGround, String.format(Locale.GERMAN, "com.dan.forest am Gegenufer: %,d Bäume im Umkreis von 600 m (%d/%d/%d/%d/%d je Stufe), alle auf dem Boden", f.shown, lc[0], lc[1], lc[2], lc[3], lc[4]));
        com.dan.ground.Meadow m = new com.dan.ground.Meadow(com.dan.ground.Biome.schlei(), new com.dan.haithabu.scene.Bodendecke(t, v));
        m.radius = 20;
        m.setSeason(289, 0);
        m.update(0, 1000, -200);
        int nForest = m.batch.nt;
        m.update(0, 300, -300);
        check(nForest > 1000 && m.batch.nt == 0, String.format(Locale.GERMAN, "Bodendecke im Wald %,d Dreiecke, im Noor keine", nForest));
    }

    static void noor() {
        System.out.println("Noor (Phase 2)");
        double h3 = Ocean.noor(3).state().totalHs(), h6 = Ocean.noor(6).state().totalHs(), hSee = Ocean.beaufort(6).state().totalHs();
        check(h3 < 0.2 && h6 > h3 && h6 < 0.6, String.format(Locale.GERMAN, "Kurzer Seegang im Noor: Hs %.2f m bei Bft 3, %.2f m bei Bft 6", h3, h6));
        check(h6 < hSee / 3, String.format(Locale.GERMAN, "… weit unter offener See bei Bft 6 (%.1f m)", hSee));
    }

    static void halme() {
        System.out.println("Schilf und Gras (Phase 2)");
        check(Reed.lean(10, Reed.Kind.SCHILF.stiffness) > Reed.lean(5, Reed.Kind.SCHILF.stiffness)
                && Reed.lean(5, Reed.Kind.GRAS.stiffness) > Reed.lean(5, Reed.Kind.BINSE.stiffness), "Neigung wächst mit dem Wind, steife Binsen neigen sich weniger");
        Reed r = Reed.breeze();
        double a = r.sway(3, 4, 0.5, 0.55, 0)[0], b = r.sway(3, 4, 0.5, 0.55, 1.3)[0];
        check(Math.abs(a - b) > 1e-4, "Halme bewegen sich mit der Zeit (Böen laufen übers Schilf)");
    }

    static void himmel() {
        System.out.println("Himmel (Phase 3)");
        SceneClock c = new SceneClock();
        com.dan.sky.Sky sky = new com.dan.sky.Sky();
        Wiring w = new Wiring(c);
        w.feed(sky, 10);
        com.dan.sky.Sky.State st = sky.updateNow();
        double[] sp = c.sun();
        check(Math.abs(st.sunAlt - sp[0]) < 1.0, String.format(Locale.GERMAN, "com.dan.sky und die Uhr der App: Sonne am 16.10.950 17:30 %.2f° gegen %.2f° (com.dan.sky mit Brechung)", st.sunAlt, sp[0]));
        check(st.sunAlt < 0 && st.sunAlt > -4, "Start kurz nach Sonnenuntergang: Sonne " + String.format(Locale.GERMAN, "%.1f°", st.sunAlt));
        double ex = com.dan.sky.Sky.State.exposureFor(st.adaptation, 0.85);
        c.set(java.time.LocalDate.of(950, 10, 16), 23);
        w.feed(sky, 10);
        com.dan.sky.Sky.State night = sky.updateNow();
        check(com.dan.sky.Sky.State.exposureFor(night.adaptation, 0.85) > ex * 5 && night.scotopic() > 0.3,
                String.format(Locale.GERMAN, "Nacht: das Auge passt sich an (Belichtung %.0f-fach), sieht mit den Stäbchen (%.0f %%)", com.dan.sky.Sky.State.exposureFor(night.adaptation, 0.85) / ex, night.scotopic() * 100));
    }

    static void wetter() {
        System.out.println("Wetter (Phase 3)");
        SceneClock c = new SceneClock(java.time.LocalDate.of(950, 10, 17), 5.0);
        Wiring w = new Wiring(c);
        w.regie = true;
        w.start(com.dan.weather.Scenario.autumnFogMorning());
        com.dan.fog.Fog fog = new com.dan.fog.Fog();
        c.setHour(6.0);
        w.feedWeather(0);
        com.dan.weather.Weather.Snapshot s6 = w.weather.snapshot();
        w.feed(fog, -6);
        fog.step(0);
        double dense = fog.density(0, 2, 0) + fog.density(200, 2, -200) + fog.density(-300, 2, 300);
        check(w.fogAmount > 0.75 && fog.amount > 0.9 && fog.base == 0 && dense > 0 && fog.top < 26,
                String.format(Locale.GERMAN, "Nebelmorgen 06:00: Nebel %.0f %%, am Wasser dicht, Obergrenze %.0f m (die Hochburg ragt heraus)", w.fogAmount * 100, fog.top));
        check(Math.abs(w.wind.speed() - s6.wind() * Wiring.LAND_WIND) < 1e-9, String.format(Locale.GERMAN, "Wind der Regie über Land: %.1f statt %.1f m/s", w.wind.speed(), s6.wind()));
        c.setHour(9.0);
        w.feedWeather(0);
        w.feed(fog, 12);
        fog.step(0);
        check(fog.base > 5 && fog.density(0, 0.5, 0) == 0, String.format(Locale.GERMAN, "09:00, Sonne 12°: der Nebel hebt sich (Untergrenze %.0f m, Obergrenze %.0f m), am Wasser klar", fog.base, fog.top));
        c.setHour(13.0);
        w.feedWeather(0);
        w.feed(fog, 25);
        fog.step(0);
        check(!fog.snapshot().any() || fog.amount < 0.02, String.format(Locale.GERMAN, "13:00: der Nebel ist fort (%.0f %%)", w.fogAmount * 100));
        w.hand(com.dan.weather.Weather.Var.RAIN, 5);
        check(Math.abs(w.rainRate - 5) < 1e-9, "Handregler überschreibt die Regie (Regen 5 mm/h)");
        w.resumeRegie();
        check(w.weather.overrides() == 0, "„Regie weiter“ löst alle Handregler");
    }

    static void symbol() {
        System.out.println("Programmsymbol");
        boolean all = true;
        for (int s : AppIcon.SIZES) {
            java.awt.image.BufferedImage b = AppIcon.paint(s);
            all &= b.getWidth() == s && (b.getRGB(s / 2, s / 2) >>> 24) == 255 && (b.getRGB(0, 0) >>> 24) < 255;
        }
        check(all, "Symbol in " + AppIcon.SIZES.length + " Größen gemalt, deckend in der Mitte, runde Ecken");
    }

    /** Die kopierten Element-Packages stehen im Quellordner, jedes mit README. */
    static void pakete() throws Exception {
        System.out.println("Packages");
        File base = new File("src/com/dan");
        if (!base.isDirectory()) { System.out.println("  (Quellordner nicht gefunden, übersprungen)"); return; }
        String[] wanted = {"sky", "cloud", "weather", "rain", "fog", "ocean", "weathering", "buoyancy", "flock", "lightning", "soundscape", "muster", "reed", "river", "ground", "forest", "road", "timber", "spray", "longship", "smoke", "hearth", "kino"};
        int n = 0;
        for (String w : wanted) if (new File(base, w + "/README.md").isFile()) n++;
        check(n == wanted.length, n + " von " + wanted.length + " Packages (Lighthouse, Geyser, neu) mit README im Build");
    }

    /** Kein Element-Package kennt die App (die volle Prüfung macht check-packages). */
    static void isolation() throws Exception {
        System.out.println("Isolation");
        File base = new File("src/com/dan");
        if (!base.isDirectory()) { System.out.println("  (Quellordner nicht gefunden, übersprungen)"); return; }
        Pattern p = Pattern.compile("com\\.dan\\.haithabu");
        int bad = 0, files = 0;
        File[] dirs = base.listFiles(f -> f.isDirectory() && !f.getName().equals("haithabu"));
        if (dirs != null) for (File d : dirs) {
            try (Stream<Path> s = Files.walk(d.toPath())) {
                for (Path f : (Iterable<Path>) s.filter(x -> x.toString().endsWith(".java"))::iterator) {
                    files++;
                    Matcher m = p.matcher(Files.readString(f, StandardCharsets.UTF_8));
                    if (m.find()) { bad++; System.out.println("    " + f); }
                }
            }
        }
        check(bad == 0, files + " Dateien in " + (dirs == null ? 0 : dirs.length) + " Packages, keine nennt com.dan.haithabu");
    }

    static double hourOf(double epochMs) {
        var z = Instant.ofEpochMilli((long) epochMs).atZone(SceneClock.ZONE);
        return z.getHour() + z.getMinute() / 60.0 + z.getSecond() / 3600.0;
    }

    static String hm(double h) { return String.format("%02d:%02d", (int) h, (int) Math.round((h - (int) h) * 60) % 60); }

    private Pruefung() { }
}
