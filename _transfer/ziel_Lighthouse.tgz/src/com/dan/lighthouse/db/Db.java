package com.dan.lighthouse.db;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

/**
 * Zugang zur Oracle-Datenbank (Schema LIGHTHOUSE, Dienst PDBORCL), nach dem Vorbild von Heidelberg, Kneiphof und
 * Kīlauea. Die Zugangsdaten stehen in {@code db/db.properties} (Schlüssel url, user, password); die Datei steht in
 * .gitignore. Ist password leer, wird die Umgebungsvariable {@code Lighthouse_DB_PASSWORD} gelesen, sonst fragt das
 * Startbild und trägt es nach dem ersten erfolgreichen Verbinden ein. Phase 1 prüft nur die Verbindung; Tabellen
 * kommen in Phase 15. Ohne Datenbank läuft alles weiter.
 */
public final class Db {
    private Db() { }

    public static final String STANDARD_URL = "jdbc:oracle:thin:@//localhost:1521/PDBORCL";
    public static final String ENV = "Lighthouse_DB_PASSWORD";
    /** Zeitlimit für den Verbindungsaufbau in Sekunden (das Startbild wartet nicht länger). */
    public static final int VERBINDEN_S = 3;

    public static final class Konfig {
        public final String url, user;
        public final File datei;
        private final char[] passwort;
        Konfig(String url, String user, char[] passwort, File datei) { this.url = url; this.user = user; this.passwort = passwort; this.datei = datei; }
        public boolean hatPasswort() { return passwort != null && passwort.length > 0; }
        public Konfig mitPasswort(char[] pw) { return new Konfig(url, user, pw, datei); }
        char[] passwort() { return passwort; }
        /** Kurzform für Anzeigen, ohne Passwort. */
        public String kurz() { return user + "@" + url.replaceFirst("^jdbc:oracle:thin:@/{0,2}", ""); }
    }

    /** Der Ordner db: -Dlighthouse.db.dir, sonst ./db, sonst db neben dem Jar oder bis zu zwei Ebenen darüber. */
    public static File ordner() {
        String p = System.getProperty("lighthouse.db.dir");
        if (p != null && !p.isEmpty()) return new File(p);
        File d = new File("db");
        if (d.isDirectory()) return d;
        try {
            File jar = new File(Db.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            File base = jar.isFile() ? jar.getParentFile() : jar;
            for (int i = 0; i < 3 && base != null; i++, base = base.getParentFile()) {
                File c = new File(base, "db");
                if (c.isDirectory()) return c;
            }
        } catch (Exception e) { /* weiter */ }
        return d;
    }

    /** Liest db/db.properties; wirft FileNotFoundException mit einer lesbaren Meldung, wenn es die Datei nicht gibt. */
    public static Konfig konfig() throws IOException { return konfig(new File(ordner(), "db.properties")); }

    public static Konfig konfig(File f) throws IOException {
        if (!f.isFile()) throw new FileNotFoundException("db/db.properties fehlt (Vorlage: db/db.properties.example)");
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f.toPath())) { p.load(new java.io.InputStreamReader(in, StandardCharsets.UTF_8)); }
        String url = p.getProperty("url", STANDARD_URL).trim();
        String user = p.getProperty("user", "Lighthouse").trim();
        String pw = p.getProperty("password", "").trim();
        if (pw.isEmpty()) {
            String env = System.getenv(ENV);
            if (env != null) pw = env;
        }
        return new Konfig(url, user, pw.toCharArray(), f);
    }

    /** Öffnet eine Verbindung mit kurzen Zeitgrenzen (3 s Verbindungsaufbau, 30 s je Antwort). */
    public static Connection oeffnen(Konfig k) throws SQLException {
        Properties p = new Properties();
        p.setProperty("user", k.user);
        p.setProperty("password", new String(k.passwort()));
        p.setProperty("oracle.net.CONNECT_TIMEOUT", Integer.toString(VERBINDEN_S * 1000));
        p.setProperty("oracle.jdbc.ReadTimeout", "30000");
        DriverManager.setLoginTimeout(VERBINDEN_S + 1);
        Connection c = DriverManager.getConnection(k.url, p);
        c.setAutoCommit(true);
        return c;
    }

    /** Verbinden und fragen, wer man ist: „LIGHTHOUSE auf PDBORCL · Oracle 21“. */
    public static String pruefen(Konfig k) throws SQLException {
        try (Connection c = oeffnen(k); Statement s = c.createStatement();
             ResultSet r = s.executeQuery("select user, sys_context('USERENV','CON_NAME') from dual")) {
            r.next();
            return r.getString(1) + " auf " + r.getString(2) + " · Oracle " + c.getMetaData().getDatabaseMajorVersion();
        }
    }

    /** Schreibt das Passwort in die Zeile {@code password=} von db.properties; alle anderen Zeilen und Kommentare bleiben. */
    public static void passwortSpeichern(Konfig k, char[] pw) throws IOException {
        File f = k.datei;
        List<String> zeilen = Files.readAllLines(f.toPath(), StandardCharsets.UTF_8);
        String neu = "password=" + new String(pw).replace("\\", "\\\\");
        boolean gefunden = false;
        for (int i = 0; i < zeilen.size(); i++) {
            String t = zeilen.get(i).trim();
            if (t.startsWith("password") && t.substring(8).trim().startsWith("=")) { zeilen.set(i, neu); gefunden = true; }
        }
        if (!gefunden) zeilen.add(neu);
        Files.write(f.toPath(), zeilen, StandardCharsets.UTF_8);
    }
}
